package com.novamind.game.android;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.novamind.game.NovaMindGame;

public class AndroidLauncher extends AndroidApplication {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Install before the libGDX view and game are initialized.
        CrashReporter.install(this);
        CrashReporter.markStage("AndroidLauncher.onCreate başladı");
        super.onCreate(savedInstanceState);
        CrashReporter.markStage("Android Activity super.onCreate tamamlandı");

        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.useAccelerometer = false;
        config.useCompass = false;
        config.useImmersiveMode = true;

        // Disable multisampling for broader Android GPU compatibility.
        config.numSamples = 0;
        CrashReporter.markStage("Android grafik ayarları hazırlandı");

        initialize(new NovaMindGame(stageName -> {
            CrashReporter.markStage(stageName);
            if ("İlk render() karesi tamamlandı".equals(stageName)) {
                CrashReporter.markStartupComplete();
            }
        }), config);
        CrashReporter.markStage("libGDX initialize() çağrıldı");

        // Run after AndroidApplication has attached the libGDX view to the window.
        getWindow().getDecorView().post(this::showPendingCrashReport);
    }

    private void showPendingCrashReport() {
        if (isFinishing() || isDestroyed()) return;
        String report = CrashReporter.readPendingReport(this);
        if (report == null) return;

        new AlertDialog.Builder(this)
                .setTitle("HATA RAPORU HAZIR")
                .setMessage("NOVA MIND önceki açılışta beklenmeyen bir hatayla kapandı.\n\n"
                        + CrashReporter.getReportSummary(report)
                        + "\n\nJava hata izi ve açılış aşamaları rapora eklendi.")
                .setCancelable(true)
                .setPositiveButton("RAPORU PAYLAŞ", (dialog, which) -> shareCrashReport(report))
                .setNegativeButton("DAHA SONRA", (dialog, which) -> {
                    // Keep the report pending so it is offered again on the next launch.
                })
                .show();
    }

    private void shareCrashReport(String report) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "NOVA MIND - Hata Raporu");
        shareIntent.putExtra(Intent.EXTRA_TEXT, report);
        try {
            startActivity(Intent.createChooser(shareIntent, "NOVA MIND hata raporunu paylaş"));
            CrashReporter.markReportShared(this);
            Toast.makeText(this, "Hata raporu paylaşım menüsüne gönderildi.", Toast.LENGTH_SHORT).show();
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Bu raporu paylaşabilecek bir uygulama bulunamadı.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        CrashReporter.markStage("AndroidLauncher.onResume");
    }

    @Override
    protected void onPause() {
        CrashReporter.markStage("AndroidLauncher.onPause");
        super.onPause();
    }
}
