# Android açılış hata yakalama sistemi

Android başlatıcısına libGDX başlatılmadan önce kurulan bir Java `UncaughtExceptionHandler` eklendi.

- Beklenmeyen Java hatalarında cihaz/Android bilgisi ve tam stack trace uygulamanın özel dosya alanına `last_startup_crash.txt` olarak yazılır.
- Uygulama tekrar açıldığında önceki çökme raporu tam metin olarak gösterilir.
- `AndroidLauncher.onCreate()` ve libGDX `initialize()` sırasında senkron oluşan hatalar doğrudan tanılama ekranında gösterilir.
- Rapor ekrandan panoya kopyalanabilir.
- Başlangıç raporu, libGDX'nin GL iş parçacığında oyunu kurması için 10 saniyelik başlangıç penceresi geçmeden silinmez.

Not: Android işletim sisteminin uygulamayı hiç başlatmaması, APK/manifest yükleme sorunları ve Java dışı bazı yerel (native) çökmeler Java hata yakalayıcısına ulaşmayabilir. Bunlar için ayrıca `adb logcat` veya Play Console native crash kayıtları gerekir.
