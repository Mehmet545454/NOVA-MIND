#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle bulunamadi. Gradle 9.6 ve JDK 17 kurulu olmali." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Android SDK bulunamadi. ANDROID_HOME veya ANDROID_SDK_ROOT ayarla." >&2
  exit 1
fi
gradle --no-daemon :android:assembleDebug
APK="android/build/outputs/apk/debug/android-debug.apk"
if [[ ! -s "$APK" ]]; then
  APK="$(find android/build/outputs/apk/debug -maxdepth 1 -type f -name '*.apk' -print -quit)"
fi
if [[ -z "$APK" || ! -s "$APK" ]]; then
  echo "APK olusmadi." >&2
  exit 1
fi
echo "APK hazir: $APK"
