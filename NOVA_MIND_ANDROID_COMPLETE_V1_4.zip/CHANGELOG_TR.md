# NOVA MIND — Degisiklik Gunlugu

## Android Edition 1.4.0

- Java 17 + libGDX 1.14.2 ile Android yerel 3D oyun altyapisi.
- 8 departman, kesit gorunumlu binalar ve her bolume ozel ekipmanlar.
- Genel merkez anteni, cati gunes panelleri, veri heykeli, donen holografik paneller ve detayli cepheler.
- Kampus yolu, giris aniti, su alani, agaclar, aydinlatma, park yerleri ve 3D araclar.
- Parca tabanli karakterler ve yurume animasyonu; dusuk/orta seviye telefonlar icin 24 gorunur karakter siniri.
- Tek parmak kamera, iki parmak zoom ve 3D binaya dokunarak secim.
- Genel, Departman, Ar-Ge, Urunler, Sozlesmeler ve Finans yonetim sayfalari.
- Departman gelistirme, personel alim, CPU/GPU/RAM yatirimlari.
- Model kalitesinin urun geliri ve kullanici buyumesine etkisi.
- Nova Chat, Nova Vision, Nova Code urun lansmanlari.
- Startup, Kurumsal ve Kuresel sozlesmeler; sureli aylik gelir.
- Reklam kampanyasi, aylik gelir/gider, kullanici buyumesi, rastgele olaylar ve basarim odulleri.
- Rastgele aylik olaylarin finans hesabina ayni donemde uygulanmasi.
- x1/x2/x4 zaman, duraklatma, kamera sifirlama, otomatik kayit ve onayli yeni oyun/kayit sifirlama.
- Prosedurel cam, metal, beton ve asfalt dokulari.
- Model cache, Android uygulama ikonu ve GitHub Actions APK derleme/yukleme akisi.
- ARMv7, ARM64, x86 ve x86_64 libGDX yerel kitapliklarini APK icine otomatik cikaran Gradle gorevi.
- Departmanlarda 12 seviye limiti, ilk dort fiziksel ek modul ve sonraki seviyelerde cati gelisimleri.


## 1.4.0 iyilestirmeleri

- Android grafik baglami kaybolup yeniden olusturuldugunda prosedurel dokularin yeniden yuklenebilmesi icin Pixmap kaynaklari kontrollu yasam dongusune alindi.
- Android derleme zinciri AGP 9.5.0, Gradle 9.6.0 ve SDK 37 ile guncellendi.
- APK hedef API seviyesi 36'ya, uygulama surumu 1.4.0'a yukseltilip GitHub derleme kontrolleri buna gore guncellendi.
- APK dogrulama adimina Build Tools 36.0.0 ve yeni target SDK kontrolu eklendi.
- Donen holografik veri panelleri ve Finans ekraninda guvenli kayit sifirlama/yeni oyun secenegi eklendi.
