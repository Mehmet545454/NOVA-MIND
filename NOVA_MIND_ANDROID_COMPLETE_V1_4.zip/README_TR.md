# NOVA MIND — Android 3D Campus Tycoon

**Motor:** Java 17 + libGDX 1.14.2 + OpenGL ES 2.0  
**Oyun surumu:** 1.4.0  
**Platform:** Android 6.0+ (API 23+)  
**Orientation:** Landscape  
**Package:** `com.novamind.game.debug` (debug APK)

Bu depo, NOVA MIND kampus yonetim oyununun Android icin gelistirilmis kaynak projesidir. Godot veya Unity kullanmaz. Kampus, binalar, ekipmanlar, agaclar, lambalar, araclar ve calisan karakterleri oyun acilirken Java koduyla 3D olarak olusturulur.

## GitHub'dan APK alma

1. ZIP'i bilgisayara/telefona indirip tamamen cikart.
2. `NOVA_MIND_Android_LibGDX` klasorunun icindeki **tum dosya ve klasorleri** GitHub deposunun kokune yukle. `.github` klasorunu mutlaka dahil et.
3. Depoda **Actions** sekmesine gir.
4. `NOVA MIND - Android APK` is akisini ac. Ilk push ile otomatik baslar; istersen **Run workflow** ile yeniden baslat.
5. Islem yesil tik ile bitince calismanin detayina gir.
6. **Artifacts** bolumunden `NOVA-MIND-Android-APK` dosyasini indir.
7. ZIP'i ac, icindeki APK'yi Android telefona aktar ve yukle. Android, GitHub disindan indirilen APK icin yukleme izni isteyebilir.

Workflow JDK 17, Android SDK Platform 37, Android Build Tools 36.0.0 ve Gradle 9.6 kurar; libGDX'in ARMv7, ARM64, x86 ve x86_64 yerel kutuphanelerini APK'ya hazirlar, `:android:assembleDebug` gorevini calistirir, APK'nin paket bilgisini kontrol eder ve 30 gun saklanan artifact olarak yukler.

> Bu proje depoda kaynak kod olarak bulunur. APK, GitHub Actions calismasi basariyla tamamlandiginda olusur. Bu ortamda Android SDK/Gradle olmadigi icin yerel APK derlemesi yapilmis degildir.

## Oyun ozellikleri

### 3D kampus
- Iki siraya yerlestirilmis 8 ayri departman binasi.
- Her departmana ozgu ic ekipman ve renk kimligi.
- Merkezi yonetim binasi, giris aniti, su havuzu ve kampus yollari.
- Agaclar, peyzaj saksilari, aydinlatma direkleri ve park alani.
- Kampus icinde iki arac.
- Dusuk poligonlu 3D calisan karakterleri; govde, bas, sac, kol ve bacak animasyonlari.
- Mobil performans icin ayni anda en fazla 24 calisan modeli cizilir; tum ise alimlar ekonomi ve personel sayisina tam yansir.
- Cam, metal, beton ve asfalt icin uygulama acilisinda uretilen prosedurel yuzey dokulari.
- Model cache kullanimi ile tekrar eden 3D geometrilerinde bellek tuketimini azaltma.
- Departman gelistirmelerinde gorunur fiziksel ek bina.
- Genel merkezde cati anteni, gunes panelleri, veri heykeli, kendi ekseninde donen holografik veri panelleri ve ek cephe detaylari.

### Yonetim ve ilerleme
- 8 departman: AI egitim, veri merkezi, sogutma, arsiv, robotik, urun, yonetim ve guvenlik.
- Departman gelistirme (seviye 12'ye kadar), personel kapasitesi ve ise alim. Ilk gelistirmelerde fiziksel ek moduller, ileri seviyelerde cati katmanlari gorunur.
- Aylik gelir/gider, kasa, itibar, kullanici ve hizmet alan kullanici sayisi.
- CPU, GPU ve RAM altyapi gelistirmeleri; ucunun de gelir, arastirma veya hizmet kapasitesine etkisi vardir.
- Ar-Ge puani ve model kalitesi gelistirmesi; model kalitesi urun gelirini ve kullanici buyumesini de etkiler.
- NOVA CHAT, NOVA VISION ve NOVA CODE urunlerini pazara sunma.
- STARTUP, KURUMSAL ve KURESEL musteri sozlesmeleri.
- Reklam kampanyasi ve kullanici buyumesi.
- Rastgele aylik olaylar ve odullu basarimlar; olaylar ilgili ayin finans hesabina dogru uygulanir.
- x1 / x2 / x4 zaman hizi ve duraklatma.
- Android Preferences ile otomatik kayit, manuel kayit ve yeniden acilista devam etme.
- Finans ekranindan onay penceresiyle kaydi temizleyip yeni oyuna baslama.

### Android kontrolleri
- Tek parmak: bos 3D alanda surukleyerek kamerayi dondur.
- Iki parmak: yakinlastir / uzaklastir.
- 3D binaya dokun: departmani sec.
- Sol panel: departman secimi.
- Sag panel: secili bolum ve aktif yonetim sayfasi.
- Alt menu: Genel, Departman, Ar-Ge, Urunler, Sozlesmeler ve Finans.
- Ust menu: tarih, kasa, itibar, kullanici, Ar-Ge, hiz ve kaydet.

## Proje yapisi

```text
NOVA_MIND_Android_LibGDX/
├── .github/workflows/android-apk.yml
├── android/
│   ├── src/main/AndroidManifest.xml
│   ├── src/main/java/com/novamind/game/android/AndroidLauncher.java
│   ├── src/main/res/drawable/novamind_icon.xml
│   └── build.gradle
├── core/
│   ├── src/main/java/com/novamind/game/NovaMindGame.java
│   └── build.gradle
├── build.gradle
├── settings.gradle
├── gradle.properties
├── build-apk.sh / build-apk.bat
├── scripts/check-project.sh
├── GITHUB_YUKLE_TR.md
├── CHANGELOG_TR.md
└── README_TR.md
```

## Teknik surumler

| Bilesen | Surum |
|---|---:|
| Java | 17 |
| libGDX | 1.14.2 |
| Android Gradle Plugin | 9.5.0 |
| Gradle | 9.6.0 |
| compileSdk / targetSdk | 37 / 36 |
| minSdk | 23 |
| OpenGL ES | 2.0 |

## Yerel derleme

Gerekenler: JDK 17, Android SDK Platform 37, Build Tools 36.0.0 ve Gradle 9.6.0.

Proje kokunde:

```bash
gradle --no-daemon :android:assembleDebug
```

APK:

`android/build/outputs/apk/debug/android-debug.apk`

Windows icin `build-apk.bat`, Linux/macOS/Termux icin `./build-apk.sh` yardimci betikleri bulunur.

## Bilinen sinirlar

- Bu surum stilize/low-poly bir tycoon oyunudur; gercekci taranmis insan veya otomobil assetleri kullanmaz. Karakterler ve araclar kodla olusturulan 3D modellerdir. Yuksek poligonlu harici FBX/GLB model veya fotograf gercekliginde kaplama paketi bu ZIP'e dahil degildir; geometri oyun icinde kodla uretilir.
- Golgeler gercek zamanli shadow-map degil; aydinlatma ve zemin golgesi gorunumu geometriyle taklit edilir.
- Oyun cevrimdisi tek oyunculudur. Sunucu, cok oyunculu mod, reklam SDK'si ve uygulama ici satin alma yoktur.
- APK, GitHub Actions derlemesi basarili olana kadar olusmus sayilmaz. Gercek telefon performansi cihazda test edilmelidir.
- Uretilen APK debug imzalidir; Play Store yayini icin ayri release imzalama/keystore yapilandirmasi gerekir.
