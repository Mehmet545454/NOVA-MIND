#!/usr/bin/env bash
set -euo pipefail

required_files=(
  "settings.gradle"
  "build.gradle"
  "gradle.properties"
  "README_TR.md"
  "GITHUB_YUKLE_TR.md"
  "CHANGELOG_TR.md"
  "core/build.gradle"
  "core/src/main/java/com/novamind/game/NovaMindGame.java"
  "android/build.gradle"
  "android/src/main/AndroidManifest.xml"
  "android/src/main/java/com/novamind/game/android/AndroidLauncher.java"
  "android/src/main/res/drawable/novamind_icon.xml"
  ".github/workflows/android-apk.yml"
  "build-apk.sh"
  "build-apk.bat"
)
for file in "${required_files[@]}"; do
  if [[ ! -s "$file" ]]; then
    echo "Missing or empty project file: $file" >&2
    exit 1
  fi
done

grep -q "gdx:1.14.2" core/build.gradle
grep -q "gdx-backend-android:1.14.2" android/build.gradle
grep -q "natives-arm64-v8a" android/build.gradle
grep -q "copyAndroidNatives" android/build.gradle
grep -q "lib/\$ABI/libgdx.so" .github/workflows/android-apk.yml
grep -q "versionCode 4" android/build.gradle
grep -q "versionName '1.4.0'" android/build.gradle
grep -q "minSdk 23" android/build.gradle
grep -q "targetSdk 36" android/build.gradle
grep -q "assembleDebug" .github/workflows/android-apk.yml
grep -q "upload-artifact@v7" .github/workflows/android-apk.yml
grep -q "MAX_VISIBLE_STAFF" core/src/main/java/com/novamind/game/NovaMindGame.java
grep -q "ownedPixmaps" core/src/main/java/com/novamind/game/NovaMindGame.java
grep -q "compileSdk 37" android/build.gradle
grep -Fq "version '9.5.0'" build.gradle
grep -q "ownedPixmaps.add(pixmap)" core/src/main/java/com/novamind/game/NovaMindGame.java
grep -q "showResetConfirmation" core/src/main/java/com/novamind/game/NovaMindGame.java
grep -q "rotatingProps.add(finLeft)" core/src/main/java/com/novamind/game/NovaMindGame.java
grep -q "compileSdk 37" android/build.gradle
grep -q "gradle-version: '9.6.0'" .github/workflows/android-apk.yml
grep -q "android-37 build-tools;36.0.0" .github/workflows/android-apk.yml
grep -q "targetSdkVersion:'36'" .github/workflows/android-apk.yml

echo "NOVA MIND 1.4.0 project and Android APK workflow checks passed."
