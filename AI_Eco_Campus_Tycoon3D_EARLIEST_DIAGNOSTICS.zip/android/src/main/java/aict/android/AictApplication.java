package aict.android;

import android.app.Application;
import android.content.Context;

public final class AictApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        // Earliest point available to application code in this process.
        AictDiagnostics.install(this);
        AictDiagnostics.recordStage("APPLICATION_ATTACH_COMPLETE");
    }

    @Override
    public void onCreate() {
        AictDiagnostics.recordStage("APPLICATION_ON_CREATE");
        AictDiagnostics.collectSystemExitInfo(this);
        super.onCreate();
    }
}
