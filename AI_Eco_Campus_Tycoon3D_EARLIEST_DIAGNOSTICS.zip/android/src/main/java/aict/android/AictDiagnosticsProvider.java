package aict.android;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

/** Runs during provider installation, before Application.onCreate and before the launcher Activity. */
public final class AictDiagnosticsProvider extends ContentProvider {
    @Override public boolean onCreate() {
        if (getContext() != null) {
            AictDiagnostics.install(getContext());
            AictDiagnostics.recordStage("CONTENT_PROVIDER_ON_CREATE_BEFORE_ACTIVITY");
        }
        return true;
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
