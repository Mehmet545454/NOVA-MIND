package aict.android;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import aict.core.AictGame;

/**
 * Android entry point with diagnostics that are installed before libGDX starts.
 * A fatal crash is persisted and shown on the next launch; exceptions thrown
 * while creating the game are shown immediately instead of silently closing.
 */
public final class AndroidLauncher extends AndroidApplication {
    private static final String CRASH_FILE = "last_startup_crash.txt";
    private boolean gameStarted;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        AictDiagnostics.recordStage("LAUNCHER_ATTACH_BASE_CONTEXT");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AictDiagnostics.recordStage("LAUNCHER_ON_CREATE");

        String previousCrash = readCrashReport();
        if (!TextUtils.isEmpty(previousCrash)) {
            showDiagnostic("Önceki açılışta hata oluştu", previousCrash,
                    () -> startGame(savedInstanceState), true);
        } else {
            startGame(savedInstanceState);
        }
    }

    private void startGame(Bundle savedInstanceState) {
        if (gameStarted || isFinishing()) return;
        try {
            AictDiagnostics.recordStage("GAME_CONFIGURATION_BEGIN");
            AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
            config.useImmersiveMode = true;
            config.useAccelerometer = false;
            config.useCompass = false;
            config.numSamples = 2;
            AictDiagnostics.recordStage("LIBGDX_INITIALIZE_CALL");
            initialize(new AictGame(), config);
            gameStarted = true;
            AictDiagnostics.recordStage("LIBGDX_INITIALIZE_RETURNED_WAITING_FOR_GL_THREAD");
            // Do not delete crash evidence automatically. It remains available for diagnosis.
        } catch (Throwable error) {
            AictDiagnostics.recordStage("SYNCHRONOUS_GAME_START_FAILURE");
            String report = formatError("Oyun başlatılırken hata oluştu", error);
            writeCrashReport(report);
            showDiagnostic("Oyun başlatılamadı", report, () -> finish(), false);
        }
    }

    private String formatError(String heading, Throwable error) {
        StringWriter buffer = new StringWriter();
        PrintWriter writer = new PrintWriter(buffer);
        error.printStackTrace(writer);
        writer.flush();
        return heading + "\nTarih: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date())
                + "\nAndroid: " + android.os.Build.VERSION.RELEASE
                + " (API " + android.os.Build.VERSION.SDK_INT + ")"
                + "\nCihaz: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                + "\n\n" + buffer;
    }

    private void writeCrashReport(String report) {
        writeCrashReport(this, report);
    }

    private static void writeCrashReport(Context context, String report) {
        File target = new File(context.getFilesDir(), CRASH_FILE);
        File temp = new File(context.getFilesDir(), CRASH_FILE + ".tmp");
        byte[] bytes = report.getBytes(StandardCharsets.UTF_8);
        try (FileOutputStream output = new FileOutputStream(temp)) {
            output.write(bytes);
            output.getFD().sync();
        } catch (Exception ignored) {
            return;
        }
        if (!temp.renameTo(target)) {
            try (FileOutputStream output = new FileOutputStream(target)) {
                output.write(bytes);
                output.getFD().sync();
            } catch (Exception ignored) {
                // Best effort only; preserve the original crash behavior.
            }
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }
    }

    private String readCrashReport() {
        File file = new File(getFilesDir(), CRASH_FILE);
        if (!file.isFile()) return null;
        try {
            byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception error) {
            return "Önceki hata kaydı okunamadı: " + error;
        }
    }

    private void clearCrashReport() {
        // Keep the previous report until the next game launch succeeds.
        //noinspection ResultOfMethodCallIgnored
        new File(getFilesDir(), CRASH_FILE).delete();
    }

    private void showDiagnostic(String title, String report, Runnable positiveAction, boolean hasContinue) {
        AictDiagnostics.recordStage("DIAGNOSTIC_SCREEN_SHOWN");
        runOnUiThread(() -> {
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(18), dp(18), dp(18), dp(14));
            root.setBackgroundColor(0xFF101820);

            TextView heading = new TextView(this);
            heading.setText(title);
            heading.setTextColor(0xFFFFFFFF);
            heading.setTextSize(21);
            heading.setGravity(Gravity.CENTER_VERTICAL);
            heading.setPadding(0, 0, 0, dp(12));
            root.addView(heading, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView details = new TextView(this);
            details.setText(report);
            details.setTextColor(0xFFE8EDF2);
            details.setTextSize(12);
            details.setTextIsSelectable(true);
            details.setPadding(dp(10), dp(10), dp(10), dp(10));
            details.setBackgroundColor(0xFF1D2935);
            ScrollView scroll = new ScrollView(this);
            scroll.addView(details);
            root.addView(scroll, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setGravity(Gravity.END);
            actions.setPadding(0, dp(12), 0, 0);
            Button copy = new Button(this);
            copy.setText("Hata raporunu kopyala");
            copy.setOnClickListener(view -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                String fullReport = AictDiagnostics.readAllDiagnostics(this);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("AI Eco Campus tüm tanılama kayıtları", fullReport));
                copy.setText("Tüm kayıtlar kopyalandı");
            });
            actions.addView(copy);
            if (hasContinue) {
                Button proceed = new Button(this);
                proceed.setText("Oyunu başlatmayı dene");
                proceed.setOnClickListener(view -> {
                    setContentView(new android.view.View(this));
                    positiveAction.run();
                });
                actions.addView(proceed);
            } else {
                Button close = new Button(this);
                close.setText("Kapat");
                close.setOnClickListener(view -> finish());
                actions.addView(close);
            }
            root.addView(actions);
            setContentView(root);
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
