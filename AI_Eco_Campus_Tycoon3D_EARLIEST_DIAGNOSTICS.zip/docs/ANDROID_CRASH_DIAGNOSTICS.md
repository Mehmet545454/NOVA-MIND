# Android en erken açılış ve çökme tanılama sistemi

Tanılama, uygulama kodunun çalışabildiği en erken Android noktasında başlar:

1. `AictApplication.attachBaseContext()` içinde global Java `UncaughtExceptionHandler` kurulur. Bu, Android `Application.onCreate()`, ContentProvider ve Activity'den önceki uygulama-kodu aşamasıdır.
2. `AictDiagnosticsProvider.onCreate()` uygulama sağlayıcılarının kurulumu sırasında, launcher Activity'den önce ayrı bir başlangıç işareti yazar.
3. `Application.onCreate()`, `AndroidLauncher.attachBaseContext()`, `AndroidLauncher.onCreate()` ve LibGDX başlatma çağrıları ayrı ayrı kaydedilir.
4. Java iş parçacıklarında yakalanmamış hatalar; aşama, iş parçacığı, cihaz/Android bilgisi ve tam stack trace ile diske senkron yazılır.
5. Android 11+ cihazlarda sonraki açılışta sistemin sunduğu geçmiş süreç çıkış nedenleri (Java crash, native crash, ANR ve sistem tarafından sonlandırılma bilgileri) okunup geçmişe eklenir.
6. Önceki hata raporu otomatik silinmez. Tanılama ekranındaki kopyalama düğmesi tüm raporları ve başlangıç izini panoya kopyalar.

## Kayıt dosyaları

Uygulamanın özel dahili dosya alanında:
- `last_startup_crash.txt`: son yakalanan Java çökmesi
- `startup_trace.log`: açılış aşamalarının zaman çizelgesi
- `diagnostics_history.log`: hata geçmişi ve Android süreç çıkış bilgileri

## Sınırlar

Bu, uygulama süreci başlatıldıktan sonra uygulama kodunun çalışabildiği en erken noktadır. Android uygulama sürecini hiç oluşturamazsa (ör. bozuk APK/manifest, yükleme/doğrulama hatası), uygulama içindeki hiçbir Java kodu kayıt yazamaz. Native crash ve ANR için Android'in geçmiş çıkış bilgisi cihaz/API sürümüne bağlıdır; tüm cihazlarda tam native stack trace garanti edilemez. Bu tür durumlarda `adb logcat` ayrıca gerekir.
