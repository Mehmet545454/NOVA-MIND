@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle bulunamadi. Gradle 9.6 ve JDK 17 kurulu olmali.
  exit /b 1
)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (
  echo Android SDK bulunamadi. ANDROID_HOME veya ANDROID_SDK_ROOT ayarla.
  exit /b 1
)
gradle --no-daemon --stacktrace :android:assembleDebug
if errorlevel 1 exit /b 1
set "APK_PATH="
for /r android\build\outputs\apk\debug %%F in (*.apk) do set "APK_PATH=%%F"
if "%APK_PATH%"=="" (
  echo APK olusmadi. android\build\outputs\apk\debug klasorunu kontrol et.
  exit /b 1
)
echo APK hazir: %APK_PATH%
endlocal
