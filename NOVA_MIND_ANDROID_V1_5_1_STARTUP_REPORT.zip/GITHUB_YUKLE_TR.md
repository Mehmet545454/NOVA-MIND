# GitHub'a yukleme — Android telefon / Termux

Bu arşiv proje kokunu dogrudan icerir; icinden `NOVA_MIND_Android_LibGDX` adinda ikinci bir klasor aramana gerek yok.

## Termux ile gonderme

1. ZIP'i telefonun `Download` klasorune indir.
2. GitHub'da bos bir repository olustur. Ornek isim: `nova-mind-android`.
3. Termux'ta asagidaki komutlari calistir. `KULLANICI` ve `DEPO` kisimlarini kendi GitHub hesabina gore degistir.

```bash
pkg update -y
pkg install git unzip -y
termux-setup-storage
cd ~/storage/downloads
unzip -o NOVA_MIND_ANDROID_COMPLETE_V1_5_CRASH_REPORT.zip -d NOVA_MIND_ANDROID
cd NOVA_MIND_ANDROID
git init
git branch -M main
git config user.name "GitHub Kullanici Adin"
git config user.email "GitHub hesabindaki e-posta"
git remote add origin https://github.com/KULLANICI/DEPO.git
git add .
git commit -m "NOVA MIND Android 3D game"
git push -u origin main
```

`user.name` ve `user.email` satirlarindaki degerleri kendi bilgilerinle degistir. GitHub parola ile HTTPS push kabul etmiyorsa, GitHub'in Personal Access Token / kimlik dogrulama adimini kullan. Token'i oyun dosyalarina veya ZIP'e yazma.

## APK indirme

1. GitHub repository → **Actions**.
2. `NOVA MIND - Android APK` calismasini ac.
3. Yesil tik olusunca calismanin sayfasina gir.
4. **Artifacts** → `NOVA-MIND-Android-APK` ZIP'ini indir.
5. ZIP'i acip `.apk` dosyasini kur.

Ilk push ile workflow otomatik baslar. Sonraki kod guncellemelerinde de APK kendiliginden yeniden olusturulur. Kaynak ZIP'in icinde hazir APK yoktur; APK Actions derlemesi basarili oldugunda artifact olarak uretilir. Workflow kirmizi hata verirse **Actions → ilgili calisma → Build and verify Android APK** adimindaki hata metnini incele.


## 1.5.1 açılış raporu düzeltmesi

Uygulama artık önce ReportActivity ekranını açar. Önceki oturumun tamamlanmamış açılışı varsa libGDX başlatılmadan hata raporu gösterilir. Rapor paylaşılabilir, panoya kopyalanabilir veya Android dosya seçicisiyle TXT olarak kaydedilebilir. Rapor yoksa oyun motoru başlatılır.
