package com.novamind.game.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.AtomicFile;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Captures uncaught Java exceptions and keeps a small, persistent startup trace.
 * All data is stored in the application's private files directory.
 */
public final class CrashReporter {
    private static final String TAG = "NovaMindCrashReporter";
    private static final String PREFS_NAME = "nova_mind_crash_reporter";
    private static final String PREF_REPORT_PENDING = "report_pending";
    private static final String PREF_STARTUP_FINISHED = "startup_finished";
    private static final String PREF_LAST_STAGE = "last_stage";
    private static final String REPORT_FILE_NAME = "nova_mind_crash_report.txt";
    private static final String STARTUP_LOG_FILE_NAME = "nova_mind_startup.log";
    private static final String OLD_STARTUP_LOG_FILE_NAME = "nova_mind_startup.previous.log";
    private static final int MAX_STARTUP_LOG_BYTES = 256 * 1024;
    private static final int MAX_LOG_BYTES_IN_REPORT = 64 * 1024;

    private static final Object LOCK = new Object();
    private static volatile Context appContext;
    private static volatile String currentStage = "Başlatma aşaması henüz kaydedilmedi";
    private static volatile Thread.UncaughtExceptionHandler previousHandler;
    private static volatile boolean installed;

    private CrashReporter() {
    }

    /** Install before the Android activity initializes libGDX. Safe to call more than once. */
    public static void install(Context context) {
        if (context == null) return;
        synchronized (LOCK) {
            appContext = context.getApplicationContext();
            if (installed) {
                markStage("Android etkinliği yeniden oluşturuldu");
                return;
            }

            previousHandler = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread thread, Throwable error) {
                    try {
                        saveCrashReport(thread, error);
                    } catch (Throwable reporterError) {
                        Log.e(TAG, "Hata raporu kaydedilemedi", reporterError);
                    }

                    Thread.UncaughtExceptionHandler delegate = previousHandler;
                    if (delegate != null && delegate != this) {
                        delegate.uncaughtException(thread, error);
                    } else {
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(10);
                    }
                }
            });
            installed = true;

            SharedPreferences preferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean previousStartupFinished = preferences.getBoolean(PREF_STARTUP_FINISHED, true);
            boolean existingReportPending = preferences.getBoolean(PREF_REPORT_PENDING, false);
            String previousStage = preferences.getString(PREF_LAST_STAGE, "Son aşama kaydedilemedi");
            if (!previousStartupFinished && !existingReportPending) {
                try {
                    saveIncompleteStartupReport(appContext, previousStage);
                } catch (Throwable reportError) {
                    Log.e(TAG, "Tamamlanamayan açılış raporu kaydedilemedi", reportError);
                }
            }
            preferences.edit().putBoolean(PREF_STARTUP_FINISHED, false).commit();

            currentStage = "Java hata yakalama sistemi etkinleştirildi";
            appendStartupLog("\n========== YENİ NOVA MIND OTURUMU ==========");
            appendStartupLog("Zaman: " + now());
            appendStartupLog("Cihaz: " + Build.MANUFACTURER + " " + Build.MODEL);
            appendStartupLog("Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            appendStartupLog("Paket: " + appContext.getPackageName());
            appendStartupLog("Aşama: " + currentStage);
        }
    }

    /** Record a named startup/lifecycle checkpoint. Logging must never interrupt the game. */
    public static void markStage(String stage) {
        if (stage == null || stage.trim().isEmpty()) return;
        currentStage = stage;
        try {
            Context context = appContext;
            if (context != null) {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putString(PREF_LAST_STAGE, stage).apply();
            }
            appendStartupLog("[" + now() + "] " + stage);
        } catch (Throwable logError) {
            Log.w(TAG, "Açılış aşaması günlüğe yazılamadı", logError);
        }
    }

    public static boolean hasPendingReport(Context context) {
        if (context == null) return false;
        File report = new File(context.getApplicationContext().getFilesDir(), REPORT_FILE_NAME);
        if (!report.isFile() || report.length() == 0L) return false;
        return context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(PREF_REPORT_PENDING, true);
    }

    /** Returns the pending report as UTF-8 text, or null if there is no pending report. */
    public static String readPendingReport(Context context) {
        if (!hasPendingReport(context)) return null;
        File report = new File(context.getApplicationContext().getFilesDir(), REPORT_FILE_NAME);
        try (FileInputStream input = new FileInputStream(report);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return output.toString("UTF-8");
        } catch (IOException error) {
            Log.e(TAG, "Kaydedilmiş hata raporu okunamadı", error);
            return "NOVA MIND hata raporu dosyası bulundu ancak okunamadı.\n" + error;
        }
    }

    /** Mark the first fully rendered frame so an interrupted startup can be distinguished next time. */
    public static void markStartupComplete() {
        Context context = appContext;
        if (context == null) return;
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(PREF_STARTUP_FINISHED, true).apply();
    }

    /** Mark the report as handled after it has been shared or exported to a user-selected file. */
    public static void markReportHandled(Context context) {
        if (context == null) return;
        context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_REPORT_PENDING, false)
                .apply();
    }

    /** Backwards-compatible alias for older callers. */
    public static void markReportShared(Context context) {
        markReportHandled(context);
    }

    public static String getReportSummary(String report) {
        if (report == null || report.trim().isEmpty()) return "Önceki oturumda bir hata oluştu.";
        String[] lines = report.split("\\r?\\n");
        for (String line : lines) {
            if (line.startsWith("Hata:")) return line;
        }
        return "Önceki oturumda bir Java hatası yakalandı.";
    }

    private static void saveCrashReport(Thread thread, Throwable error) throws IOException {
        Context context = appContext;
        if (context == null) return;

        StringWriter stackWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stackWriter);
        error.printStackTrace(printWriter);
        printWriter.flush();

        StringBuilder report = new StringBuilder(16 * 1024);
        report.append("NOVA MIND - JAVA HATA RAPORU\n");
        report.append("========================================\n");
        report.append("Zaman: ").append(now()).append('\n');
        report.append("Uygulama: ").append(context.getPackageName()).append('\n');
        report.append("Cihaz: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        report.append("Android: ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        report.append("İş parçacığı: ").append(thread == null ? "bilinmiyor" : thread.getName()).append('\n');
        report.append("Son açılış aşaması: ").append(currentStage).append('\n');
        report.append("Hata: ").append(error.getClass().getName()).append(": ")
                .append(error.getMessage() == null ? "(hata mesajı yok)" : error.getMessage()).append('\n');
        report.append("\nJAVA STACK TRACE\n");
        report.append("-----------------\n");
        report.append(stackWriter);
        report.append("\nSON AÇILIŞ / ÇALIŞMA AŞAMALARI\n");
        report.append("-----------------------------\n");
        report.append(readStartupLogTail(context));

        writeReportFile(context, report.toString());
    }

    private static void saveIncompleteStartupReport(Context context, String previousStage) throws IOException {
        StringBuilder report = new StringBuilder(12 * 1024);
        report.append("NOVA MIND - TAMAMLANAMAYAN AÇILIŞ RAPORU\n");
        report.append("========================================\n");
        report.append("Zaman: ").append(now()).append('\n');
        report.append("Uygulama: ").append(context.getPackageName()).append('\n');
        report.append("Cihaz: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        report.append("Android: ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        report.append("Hata: Java hatası yakalanmadı; önceki açılış ilk render karesi tamamlanmadan sona erdi.\n");
        report.append("Son kaydedilen aşama: ").append(previousStage).append("\n\n");
        report.append("ÖNEMLİ: Bu raporda Java stack trace bulunmaz. Olası nedenler native/GPU sürücüsü kaynaklı kapanma, işletim sistemi tarafından durdurulma veya açılış sırasında uygulamanın kapatılmasıdır.\n\n");
        report.append("SON AÇILIŞ AŞAMALARI\n");
        report.append("--------------------\n");
        report.append(readStartupLogTail(context));
        writeReportFile(context, report.toString());
    }

    private static void writeReportFile(Context context, String reportText) throws IOException {
        File target = new File(context.getFilesDir(), REPORT_FILE_NAME);
        AtomicFile atomicFile = new AtomicFile(target);
        FileOutputStream output = null;
        try {
            output = atomicFile.startWrite();
            output.write(reportText.getBytes(StandardCharsets.UTF_8));
            output.flush();
            output.getFD().sync();
            atomicFile.finishWrite(output);
            output = null;
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean(PREF_REPORT_PENDING, true)
                    .commit();
        } catch (IOException writeError) {
            if (output != null) atomicFile.failWrite(output);
            throw writeError;
        }
    }

    private static String readStartupLogTail(Context context) {
        File log = new File(context.getFilesDir(), STARTUP_LOG_FILE_NAME);
        if (!log.isFile()) return "Açılış günlüğü bulunamadı.\n";
        try (FileInputStream input = new FileInputStream(log);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            long length = log.length();
            long skip = Math.max(0L, length - MAX_LOG_BYTES_IN_REPORT);
            while (skip > 0L) {
                long skipped = input.skip(skip);
                if (skipped <= 0L) break;
                skip -= skipped;
            }
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return output.toString("UTF-8");
        } catch (IOException error) {
            return "Açılış günlüğü okunamadı: " + error + "\n";
        }
    }

    private static void appendStartupLog(String line) {
        Context context = appContext;
        if (context == null) return;
        synchronized (LOCK) {
            File log = new File(context.getFilesDir(), STARTUP_LOG_FILE_NAME);
            if (log.exists() && log.length() > MAX_STARTUP_LOG_BYTES) {
                File previous = new File(context.getFilesDir(), OLD_STARTUP_LOG_FILE_NAME);
                if (previous.exists()) previous.delete();
                if (!log.renameTo(previous)) {
                    // If rotation fails, truncate the current log rather than growing without limit.
                    try (FileOutputStream truncate = new FileOutputStream(log, false)) {
                        truncate.write(("[" + now() + "] Önceki günlük boyut sınırı nedeniyle temizlendi.\n")
                                .getBytes(StandardCharsets.UTF_8));
                    } catch (IOException ignored) {
                        Log.w(TAG, "Açılış günlüğü döndürülemedi");
                    }
                }
            }
            try (FileOutputStream output = new FileOutputStream(log, true)) {
                output.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                output.flush();
                output.getFD().sync();
            } catch (IOException error) {
                Log.w(TAG, "Açılış günlüğü yazılamadı", error);
            }
        }
    }

    private static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
    }
}
