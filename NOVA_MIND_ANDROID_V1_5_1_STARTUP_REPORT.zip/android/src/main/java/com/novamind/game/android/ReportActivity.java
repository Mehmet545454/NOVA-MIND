package com.novamind.game.android;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Runs before libGDX so a previous startup failure can be inspected even if the game crashes. */
public class ReportActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 7101;
    private static final int REQUEST_SAVE_REPORT = 7102;
    private static final String CHANNEL_ID = "nova_mind_crash_reports";
    private String reportToSave;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CrashReporter.install(this);
        CrashReporter.markStage("ReportActivity açıldı; oyun motorundan önce rapor kontrol ediliyor");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        } else {
            continueStartup();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_NOTIFICATIONS) continueStartup();
    }

    private void continueStartup() {
        String report = CrashReporter.readPendingReport(this);
        if (report == null) {
            launchGame();
            return;
        }
        CrashReporter.markStage("Önceki açılış raporu oyun başlamadan gösteriliyor");
        postReportNotification();
        showReport(report);
    }

    private void launchGame() {
        startActivity(new Intent(this, AndroidLauncher.class));
        finish();
    }

    private void showReport(String report) {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.rgb(8, 22, 34));

        TextView title = new TextView(this);
        title.setText("NOVA MIND  •  HATA RAPORU HAZIR");
        title.setTextColor(Color.rgb(88, 220, 211));
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Oyun motoru başlatılmadan önceki açılış hatası yakalandı. Raporu paylaşabilir veya kaydedebilirsin.");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(14);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        TextView body = new TextView(this);
        body.setText(report);
        body.setTextColor(Color.rgb(225, 235, 241));
        body.setTextSize(12);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(12), dp(10), dp(12));
        scroll.addView(body);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(12);
        scrollParams.bottomMargin = dp(12);
        root.addView(scroll, scrollParams);

        root.addView(makeButton("RAPORU PAYLAŞ", v -> share(report)));
        root.addView(makeButton("KOPYALA", v -> copy(report)));
        root.addView(makeButton("TXT OLARAK KAYDET", v -> save(report)));
        root.addView(makeButton("OYUNU BAŞLAT", v -> launchGame()));
        setContentView(root);
    }

    private Button makeButton(String label, View.OnClickListener click) {
        Button button = new Button(this);
        button.setText(label);
        button.setOnClickListener(click);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(5);
        button.setLayoutParams(params);
        return button;
    }

    private void share(String report) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "NOVA MIND hata raporu");
        send.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(send, "Hata raporunu paylaş"));
        CrashReporter.markReportHandled(this);
        cancelNotification();
    }

    private void copy(String report) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("NOVA MIND hata raporu", report));
        Toast.makeText(this, "Rapor panoya kopyalandı.", Toast.LENGTH_LONG).show();
    }

    private void save(String report) {
        reportToSave = report;
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType("text/plain");
        create.putExtra(Intent.EXTRA_TITLE, "NOVA_MIND_HATA_RAPORU.txt");
        startActivityForResult(create, REQUEST_SAVE_REPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SAVE_REPORT) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null || reportToSave == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
            if (out == null) throw new java.io.IOException("Dosya açılamadı");
            out.write(reportToSave.getBytes(StandardCharsets.UTF_8));
            CrashReporter.markReportHandled(this);
            cancelNotification();
            Toast.makeText(this, "Rapor kaydedildi.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Kaydetme hatası: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        reportToSave = null;
    }

    private void postReportNotification() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "NOVA MIND Hata Raporları", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(this, ReportActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        android.app.PendingIntent pending = android.app.PendingIntent.getActivity(this, 7103, open, android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH);
        manager.notify(5150, builder.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle("NOVA MIND hata raporu hazır").setContentText("Raporu görüntülemek için dokun.").setContentIntent(pending).setAutoCancel(true).build());
    }

    private void cancelNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(5150);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
