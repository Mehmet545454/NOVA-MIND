package com.novamind.game.android;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.novamind.game.NovaMindGame;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class AndroidLauncher extends AndroidApplication {
    private static final int REQUEST_POST_NOTIFICATIONS = 5101;
    private static final int REQUEST_SAVE_REPORT = 5102;
    private static final int NOTIFICATION_ID_CRASH_REPORT = 5150;
    private static final String NOTIFICATION_CHANNEL_ID = "nova_mind_crash_reports";

    private boolean reportDialogShown;
    private String reportBeingSaved;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Install before the libGDX view and game are initialized.
        CrashReporter.install(this);
        CrashReporter.markStage("AndroidLauncher.onCreate başladı");
        super.onCreate(savedInstanceState);
        CrashReporter.markStage("Android Activity super.onCreate tamamlandı");

        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.useAccelerometer = false;
        config.useCompass = false;
        config.useImmersiveMode = true;
        config.numSamples = 0;
        CrashReporter.markStage("Android grafik ayarları hazırlandı");

        initialize(new NovaMindGame(stageName -> {
            CrashReporter.markStage(stageName);
            if ("İlk render() karesi tamamlandı".equals(stageName)) {
                CrashReporter.markStartupComplete();
            }
        }), config);
        CrashReporter.markStage("libGDX initialize() çağrıldı");

        // ReportActivity handles notification permission and pending reports before the game starts.
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            CrashReporter.markStage("Bildirim izni isteniyor");
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_POST_NOTIFICATIONS
            );
            return;
        }
        showPendingCrashReport();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                CrashReporter.markStage("Bildirim izni verildi");
                showPendingCrashReport();
            } else {
                CrashReporter.markStage("Bildirim izni verilmedi");
                showPendingCrashReport();
                Toast.makeText(this,
                        "Bildirim izni verilmedi. Hata raporunu uygulama içinden yine paylaşabilir veya kaydedebilirsin.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showPendingCrashReport() {
        if (isFinishing() || isDestroyed()) return;
        String report = CrashReporter.readPendingReport(this);
        if (report == null) return;

        showCrashReportNotification();
        if (reportDialogShown) return;
        reportDialogShown = true;

        new AlertDialog.Builder(this)
                .setTitle("HATA RAPORU HAZIR")
                .setMessage("NOVA MIND önceki açılışta beklenmeyen bir hatayla kapandı.\n\n"
                        + CrashReporter.getReportSummary(report)
                        + "\n\nJava hata izi ve açılış aşamaları rapora eklendi.")
                .setPositiveButton("RAPORU PAYLAŞ", (dialog, which) -> shareCrashReport(report))
                .setNeutralButton("DOSYAYA KAYDET", (dialog, which) -> saveCrashReportToDocument(report))
                .setNegativeButton("DAHA SONRA", (dialog, which) -> {
                    // Keep the report pending so it can be opened again later.
                })
                .show();
    }

    private void showCrashReportNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "NOVA MIND Hata Raporları",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Uygulama beklenmeyen şekilde kapandığında hata raporu bildirimi gösterir.");
            channel.enableVibration(true);
            manager.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(this, AndroidLauncher.class);
        openApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                NOTIFICATION_ID_CRASH_REPORT,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, NOTIFICATION_CHANNEL_ID)
                : new Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH);
        Notification notification = builder
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("NOVA MIND: Hata raporu hazır")
                .setContentText("Önceki oturumun hata raporunu açmak için dokun.")
                .setStyle(new Notification.BigTextStyle().bigText(
                        "Önceki oturumda bir hata veya beklenmeyen kapanma algılandı. "
                                + "Raporu açıp paylaşabilir ya da telefonuna TXT dosyası olarak kaydedebilirsin."
                ))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();
        manager.notify(NOTIFICATION_ID_CRASH_REPORT, notification);
    }

    private void shareCrashReport(String report) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "NOVA MIND - Hata Raporu");
        shareIntent.putExtra(Intent.EXTRA_TEXT, report);
        try {
            startActivity(Intent.createChooser(shareIntent, "NOVA MIND hata raporunu paylaş"));
            CrashReporter.markReportHandled(this);
            cancelCrashReportNotification();
            Toast.makeText(this, "Hata raporu paylaşım menüsüne gönderildi.", Toast.LENGTH_SHORT).show();
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Bu raporu paylaşabilecek bir uygulama bulunamadı.", Toast.LENGTH_LONG).show();
        }
    }

    private void saveCrashReportToDocument(String report) {
        reportBeingSaved = report;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "NOVA_MIND_HATA_RAPORU.txt");
        try {
            startActivityForResult(intent, REQUEST_SAVE_REPORT);
        } catch (ActivityNotFoundException error) {
            reportBeingSaved = null;
            Toast.makeText(this, "Dosya kaydetme ekranı açılamadı.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SAVE_REPORT) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null || reportBeingSaved == null) {
            reportBeingSaved = null;
            Toast.makeText(this, "Dosya kaydetme iptal edildi. Rapor uygulamada tutuluyor.", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri destination = data.getData();
        String report = reportBeingSaved;
        reportBeingSaved = null;
        try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
            if (output == null) throw new java.io.IOException("Dosya akışı açılamadı.");
            output.write(report.getBytes(StandardCharsets.UTF_8));
            output.flush();
            CrashReporter.markReportHandled(this);
            cancelCrashReportNotification();
            Toast.makeText(this, "Hata raporu TXT dosyası olarak kaydedildi.", Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            Toast.makeText(this, "Hata raporu kaydedilemedi: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void cancelCrashReportNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(NOTIFICATION_ID_CRASH_REPORT);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        reportDialogShown = false;
        getWindow().getDecorView().post(this::showPendingCrashReport);
    }

    @Override
    protected void onResume() {
        super.onResume();
        CrashReporter.markStage("AndroidLauncher.onResume");
    }

    @Override
    protected void onPause() {
        CrashReporter.markStage("AndroidLauncher.onPause");
        super.onPause();
    }
}
