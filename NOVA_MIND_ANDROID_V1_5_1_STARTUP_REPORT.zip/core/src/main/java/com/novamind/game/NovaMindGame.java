package com.novamind.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.FloatAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.badlogic.gdx.math.collision.Ray;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * NOVA MIND — Android campus management game.
 * Built with Java + libGDX. All campus geometry is generated at runtime.
 */
public class NovaMindGame extends ApplicationAdapter {
    private static final float WORLD_W = 1280f;
    private static final float WORLD_H = 720f;
    private static final float MONTH_SECONDS = 24f;
    // Keep animated character draw calls within a mobile-friendly budget.
    private static final int MAX_VISIBLE_STAFF = 24;

    public interface StartupStageLogger {
        void onStage(String stageName);
    }

    private final StartupStageLogger startupStageLogger;
    private boolean firstFrameStarted;
    private boolean firstFrameLogged;

    public NovaMindGame() {
        this(null);
    }

    public NovaMindGame(StartupStageLogger startupStageLogger) {
        this.startupStageLogger = startupStageLogger;
    }

    private void logStartupStage(String stageName) {
        if (startupStageLogger == null) return;
        try {
            startupStageLogger.onStage(stageName);
        } catch (Throwable ignored) {
            // Diagnostics must never prevent the game from starting.
        }
    }

    private ModelBatch modelBatch;
    private ModelBuilder modelBuilder;
    private Environment environment;
    private PerspectiveCamera camera;
    private Viewport uiViewport;
    private Stage stage;
    private Skin skin;
    private Texture whiteTexture;
    private Texture concreteTexture;
    private Texture glassTexture;
    private Texture metalTexture;
    private Texture asphaltTexture;

    private final Array<Texture> ownedTextures = new Array<>();
    // Keep source Pixmaps for managed-texture recovery after Android GL context loss.
    private final Array<Pixmap> ownedPixmaps = new Array<>();
    private final Array<Model> ownedModels = new Array<>();
    private final Array<ModelInstance> world = new Array<>();
    private final Array<Staff> staff = new Array<>();
    private final Array<ModelInstance> rotatingProps = new Array<>();
    private final ModelInstance[] selectionMarker = new ModelInstance[4];
    private final Map<String, Model> modelCache = new HashMap<>();

    private Table root;
    private Table departmentButtons;
    private Table rightContent;
    private Table rightPanel;
    private ScrollPane departmentScroll;
    private ScrollPane rightScroll;
    private Label cashLabel, dateLabel, repLabel, usersLabel, researchLabel;
    private Label newsLabel;
    private TextButton speedButton;
    private TextButton pauseButton;
    private final Array<TextButton> tabButtons = new Array<>();

    private final String[] roomNames = {
            "AI EGITIM LABORATUVARI", "VERI MERKEZI", "SOGUTMA TESISI", "VERI ARSIVI",
            "ROBOTIK ATOLYESI", "URUN STUDYOSU", "YONETIM OFISI", "GUVENLIK MERKEZI"
    };
    private final String[] roomDescriptions = {
            "Model egitimi, deneyler ve yeni algoritmalar",
            "GPU sunuculari, bulut isleme ve veri trafigi",
            "Sivi sogutma, enerji dagitimi ve isi kontrolu",
            "Veri kalitesi, arsivleme ve yedekleme",
            "Robot prototipleri, otomasyon ve donanim",
            "Urun tasarimi, test ve kullanici deneyimi",
            "Strateji, finans, insan kaynaklari ve planlama",
            "Siber guvenlik, erisim kontrolu ve denetim"
    };
    private final String[] monthNames = {
            "OCAK", "SUBAT", "MART", "NISAN", "MAYIS", "HAZIRAN",
            "TEMMUZ", "AGUSTOS", "EYLUL", "EKIM", "KASIM", "ARALIK"
    };
    private final Color[] roomAccents = {
            hex("4389C5"), hex("64D8D1"), hex("75C79F"), hex("AD98DF"),
            hex("EFA77C"), hex("D9B45D"), hex("DCE8E3"), hex("36566B")
    };
    private final Vector3[] roomPositions = new Vector3[8];
    private final int[] roomLevels = {1, 1, 2, 1, 1, 1, 1, 1};
    private final int[] roomWorkers = {2, 0, 1, 0, 1, 2, 2, 1};
    private final int[] roomCaps = {6, 6, 8, 6, 6, 8, 8, 6};
    private final long[] roomUpgradeCosts = {210000, 310000, 271300, 160000, 240000, 190000, 175000, 225000};

    private final String[] productNames = {"NOVA CHAT", "NOVA VISION", "NOVA CODE"};
    private final String[] productDescriptions = {
            "Kurumsal sohbet ve asistan platformu",
            "Goruntu analizi ve uretken tasarim araci",
            "Yazilim gelistirme ve kod yardimcisi"
    };
    private final long[] productCosts = {800000, 1400000, 1900000};
    private final long[] productMonthlyRevenue = {70000, 145000, 280000};
    private final int[] productResearchRequirement = {0, 250, 520};
    private final boolean[] productLaunched = new boolean[3];

    private final String[] contractNames = {"STARTUP", "KURUMSAL", "KURESEL"};
    private final long[] contractCosts = {450000, 1200000, 2600000};
    private final long[] contractMonthlyRevenue = {95000, 250000, 620000};
    private final int[] contractDuration = {6, 8, 12};
    private final int[] activeContractMonths = new int[3];

    private final String[] achievementNames = {
            "ILK YATIRIM", "EKIP 25", "BIR MILYON KULLANICI", "URUN AILESI"
    };
    private final boolean[] achievements = new boolean[4];
    private final long[] achievementRewards = {100000, 150000, 300000, 250000};

    private int selectedRoom = 0;
    private String activeTab = "GENEL";
    private int month = 12;
    private int year = 2026;
    private int reputation = 48;
    private int users = 125000;
    private int servedUsers = 98000;
    private int researchPoints = 420;
    private int modelQuality = 68;
    private int cpuLevel = 2;
    private int gpuLevel = 1;
    private int ramLevel = 2;
    private long cash = 4_300_000L;
    private long lastIncome = 420000L;
    private long lastCosts = 176000L;
    private int speed = 1;
    private int marketingCooldown = 0;
    private int totalMonths = 0;
    private boolean paused = false;
    private boolean skipSaveOnDispose = false;
    private float monthClock = 0f;
    private float autosaveClock = 0f;
    private float yaw = 0f;
    private float pitch = 43f;
    private float cameraDistance = 39f;
    private boolean cameraDragging = false;
    private boolean dragMoved = false;
    private float dragStartX, dragStartY, previousX, previousY;
    private float previousPinchDistance = -1f;
    private int activePointers = 0;
    private final Vector3 cameraTarget = new Vector3(0f, .45f, 0f);
    private final Vector3 pickPoint = new Vector3();
    private final Vector3 temp = new Vector3();
    private final float[] monthlyEventCost = {0f};

    private static Color hex(String value) {
        return Color.valueOf(value);
    }

    @Override
    public void create() {
        logStartupStage("NOVA_MIND create() başladı");
        Gdx.graphics.setForegroundFPS(60);
        logStartupStage("FPS sınırı ayarlandı");

        modelBatch = new ModelBatch();
        modelBuilder = new ModelBuilder();
        logStartupStage("3D model oluşturucular hazırlandı");
        createProceduralTextures();
        logStartupStage("Prosedürel dokular oluşturuldu");
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, .76f, .80f, .82f, 1f));
        environment.add(new DirectionalLight().set(1f, .96f, .88f, -.55f, -1f, -.38f));
        environment.add(new DirectionalLight().set(.28f, .38f, .46f, .55f, -.28f, .55f));
        logStartupStage("Işık ve sahne ortamı hazırlandı");

        camera = new PerspectiveCamera(48f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.near = .1f;
        camera.far = 220f;
        updateCamera();
        logStartupStage("3D kamera hazırlandı");

        loadGame();
        logStartupStage("Kayıtlı oyun verisi yüklendi");
        buildCampus();
        logStartupStage("Kampüs 3D nesneleri oluşturuldu");
        buildInitialStaff();
        logStartupStage("Başlangıç personeli oluşturuldu");
        buildSelectionMarker();
        logStartupStage("Seçim işaretçisi oluşturuldu");
        buildUi();
        logStartupStage("Kullanıcı arayüzü oluşturuldu");
        refreshAllUi();
        logStartupStage("Arayüz verileri yenilendi");
        Gdx.input.setInputProcessor(new InputMultiplexer(new WorldTouchInput(), stage));
        logStartupStage("Girdi sistemi bağlandı; oyun başlangıcı tamamlandı");
    }

    // ---------- Procedural surface textures ----------

    private Texture createSurfaceTexture(int type, long seed) {
        final int size = 128;
        Pixmap pixmap = new Pixmap(size, size, Pixmap.Format.RGBA8888);
        if (type == 0) pixmap.setColor(.94f, .96f, .93f, 1f);       // architectural concrete
        else if (type == 1) pixmap.setColor(.88f, .96f, .97f, 1f);  // glass
        else if (type == 2) pixmap.setColor(.78f, .84f, .86f, 1f);  // brushed metal
        else pixmap.setColor(.48f, .56f, .59f, 1f);                 // asphalt
        pixmap.fill();

        Random random = new Random(seed);
        if (type == 0) {
            for (int i = 0; i < 780; i++) {
                float shade = .84f + random.nextFloat() * .14f;
                pixmap.setColor(shade, shade * 1.015f, shade * .98f, 1f);
                pixmap.drawPixel(random.nextInt(size), random.nextInt(size));
            }
            pixmap.setColor(.80f, .86f, .83f, 1f);
            for (int y = 0; y < size; y += 32) pixmap.drawLine(0, y, size - 1, y);
            for (int x = 0; x < size; x += 32) pixmap.drawLine(x, 0, x, size - 1);
        } else if (type == 1) {
            pixmap.setColor(1f, 1f, 1f, 1f);
            for (int y = 12; y < size; y += 32) pixmap.drawLine(0, y, size - 1, y + 3);
            pixmap.setColor(.77f, .91f, .93f, 1f);
            for (int x = 18; x < size; x += 48) pixmap.drawLine(x, 0, x, size - 1);
        } else if (type == 2) {
            pixmap.setColor(.66f, .74f, .77f, 1f);
            for (int y = 0; y < size; y += 8) pixmap.drawLine(0, y, size - 1, y);
            pixmap.setColor(.92f, .96f, .96f, 1f);
            for (int y = 3; y < size; y += 16) pixmap.drawLine(0, y, size - 1, y);
        } else {
            for (int i = 0; i < 1550; i++) {
                float shade = .42f + random.nextFloat() * .20f;
                pixmap.setColor(shade, shade * 1.04f, shade * 1.08f, 1f);
                pixmap.drawPixel(random.nextInt(size), random.nextInt(size));
            }
            pixmap.setColor(.68f, .73f, .72f, 1f);
            for (int y = 16; y < size; y += 32) pixmap.drawLine(0, y, size - 1, y);
        }

        Texture texture = new Texture(pixmap);
        texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        texture.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat);
        // Texture(Pixmap) retains PixmapTextureData for context-loss recovery.
        // Dispose the backing Pixmap together with the game, not immediately.
        ownedPixmaps.add(pixmap);
        ownedTextures.add(texture);
        return texture;
    }

    private void createProceduralTextures() {
        concreteTexture = createSurfaceTexture(0, 1201L);
        glassTexture = createSurfaceTexture(1, 1202L);
        metalTexture = createSurfaceTexture(2, 1203L);
        asphaltTexture = createSurfaceTexture(3, 1204L);
    }

    private Texture textureFor(Color tint) {
        float brightness = (tint.r + tint.g + tint.b) / 3f;
        if (tint.b > tint.r * 1.22f && tint.g > tint.r * 1.15f) return glassTexture;
        if (brightness < .25f) return metalTexture;
        if (brightness < .52f && Math.abs(tint.r - tint.g) < .15f && Math.abs(tint.g - tint.b) < .18f) return asphaltTexture;
        if (brightness > .78f) return concreteTexture;
        return metalTexture;
    }

    // ---------- 3D model cache and geometry ----------

    private String colorKey(Color c) {
        return Integer.toHexString(Float.floatToIntBits(c.r)) + Integer.toHexString(Float.floatToIntBits(c.g))
                + Integer.toHexString(Float.floatToIntBits(c.b)) + Integer.toHexString(Float.floatToIntBits(c.a));
    }

    private Model getBoxModel(float sx, float sy, float sz, Color tint) {
        String key = "B" + sx + ":" + sy + ":" + sz + ":" + colorKey(tint);
        Model model = modelCache.get(key);
        if (model == null) {
            Material material = new Material(
                    TextureAttribute.createDiffuse(textureFor(tint)),
                    ColorAttribute.createDiffuse(new Color(tint)),
                    FloatAttribute.createShininess(28f));
            model = modelBuilder.createBox(sx, sy, sz, material, Usage.Position | Usage.Normal | Usage.TextureCoordinates);
            modelCache.put(key, model);
            ownedModels.add(model);
        }
        return model;
    }

    private Model getSphereModel(float sx, float sy, float sz, Color tint) {
        String key = "S" + sx + ":" + sy + ":" + sz + ":" + colorKey(tint);
        Model model = modelCache.get(key);
        if (model == null) {
            Material material = new Material(ColorAttribute.createDiffuse(new Color(tint)), FloatAttribute.createShininess(38f));
            model = modelBuilder.createSphere(sx, sy, sz, 16, 12, material, Usage.Position | Usage.Normal);
            modelCache.put(key, model);
            ownedModels.add(model);
        }
        return model;
    }

    private Model getCylinderModel(float diameter, float height, Color tint) {
        String key = "C" + diameter + ":" + height + ":" + colorKey(tint);
        Model model = modelCache.get(key);
        if (model == null) {
            Material material = new Material(TextureAttribute.createDiffuse(textureFor(tint)), ColorAttribute.createDiffuse(new Color(tint)));
            model = modelBuilder.createCylinder(diameter, height, diameter, 18, material, Usage.Position | Usage.Normal | Usage.TextureCoordinates);
            modelCache.put(key, model);
            ownedModels.add(model);
        }
        return model;
    }

    private ModelInstance box(float x, float y, float z, float sx, float sy, float sz, Color tint) {
        ModelInstance instance = new ModelInstance(getBoxModel(sx, sy, sz, tint), x, y, z);
        world.add(instance);
        return instance;
    }

    private ModelInstance sphere(float x, float y, float z, float sx, float sy, float sz, Color tint) {
        ModelInstance instance = new ModelInstance(getSphereModel(sx, sy, sz, tint), x, y, z);
        world.add(instance);
        return instance;
    }

    private ModelInstance cylinder(float x, float y, float z, float diameter, float height, Color tint) {
        ModelInstance instance = new ModelInstance(getCylinderModel(diameter, height, tint), x, y, z);
        world.add(instance);
        return instance;
    }

    private void buildCampus() {
        Color concrete = hex("C8D8D1");
        Color floor = hex("E2EBE7");
        Color wall = hex("F4F8F5");
        Color sideWall = hex("C8DAD3");
        Color navy = hex("1B3040");
        Color glass = hex("86C9C9");
        Color metal = hex("758B91");

        // Foundation, landscaped border and the entry boulevard.
        box(0f, -.48f, 0f, 34f, .48f, 28f, concrete);
        box(0f, -.20f, 0f, 33f, .10f, 27f, floor);
        box(0f, -.08f, -13.1f, 33f, .10f, 3.1f, hex("53636B"));
        for (int x = -15; x <= 15; x += 2) box(x, -.015f, -13.1f, .82f, .025f, .055f, hex("F0F1E8"));
        box(0f, -.035f, -10.65f, 30f, .07f, 1.25f, hex("C2D4CC"));
        box(0f, -.02f, .45f, 31f, .08f, 1.25f, hex("C1D5CC"));
        box(-15.8f, .02f, 0f, .10f, .10f, 24f, hex("70CFCB"));
        box(15.8f, .02f, 0f, .10f, .10f, 24f, hex("70CFCB"));

        // Main entrance monument and water feature.
        box(0f, 1.18f, -14.95f, 8.4f, 2.4f, .48f, navy);
        box(0f, 1.35f, -14.68f, 7.7f, .06f, .04f, hex("73E1DC"));
        box(0f, .24f, -11.15f, 5.6f, .34f, 1.5f, hex("AFC5BE"));
        box(0f, .43f, -11.15f, 4.8f, .08f, 1.1f, hex("6AC7CA"));
        for (int i = 0; i < 5; i++) {
            cylinder(-1.6f + i * .8f, .55f, -11.15f, .08f, .35f, hex("C4F3E9"));
        }

        // Eight department buildings in two rows.
        for (int i = 0; i < 8; i++) {
            float x = -10.5f + (i % 4) * 7f;
            float z = i < 4 ? 5.1f : -5.4f;
            roomPositions[i] = new Vector3(x, 0f, z);
            buildDepartment(i, x, z, wall, sideWall, glass, navy, metal);
        }

        // Central head office tower.
        box(0f, .12f, .0f, 4.25f, .24f, 3.0f, hex("B8CBC5"));
        box(0f, 1.95f, .0f, 3.35f, 3.55f, 2.35f, hex("C2E0DF"));
        box(0f, 3.88f, .0f, 3.75f, .20f, 2.75f, navy);
        box(0f, 2.05f, -1.20f, 2.85f, 2.75f, .055f, hex("76C9D0"));
        box(0f, 2.02f, 1.20f, 2.85f, 2.75f, .055f, hex("9FCAC8"));
        for (float y : new float[]{.85f, 1.65f, 2.45f, 3.25f}) {
            box(-1.70f, y, .0f, .08f, .055f, 2.35f, hex("F1F7F3"));
            box(1.70f, y, .0f, .08f, .055f, 2.35f, hex("F1F7F3"));
        }
        box(0f, 4.02f, .0f, 4.0f, .12f, 2.95f, hex("70D5D1"));
        // Roof antenna and rooftop solar arrays give the headquarters a clear silhouette.
        cylinder(0f, 4.48f, 0f, .11f, .82f, metal);
        sphere(0f, 4.94f, 0f, .22f, .22f, .22f, hex("76F2E5"));
        for (float sx : new float[]{-1.05f, 1.05f}) {
            ModelInstance solar = box(sx, 4.22f, .12f, 1.25f, .055f, .82f, hex("244F6B"));
            solar.transform.rotate(Vector3.X, -12f);
            box(sx, 4.27f, .12f, 1.17f, .018f, .045f, hex("72D6D2"));
        }
        // A small data sculpture anchors the central plaza.
        cylinder(0f, .28f, -2.45f, 1.35f, .18f, hex("718A91"));
        sphere(0f, 1.12f, -2.45f, .62f, .62f, .62f, hex("60CFCB"));
        for (int i = 0; i < 4; i++) {
            double a = i * Math.PI / 2.0;
            float px = (float) Math.cos(a) * 1.0f;
            float pz = -2.45f + (float) Math.sin(a) * 1.0f;
            cylinder(px, .70f, pz, .10f, .82f, hex("C4E6E0"));
            sphere(px, 1.18f, pz, .18f, .18f, .18f, hex("E3F6F0"));
        }
        // Floating data fins rotate slowly around the central AI sculpture.
        ModelInstance finLeft = box(-1.72f, 1.20f, -2.45f, .13f, .92f, .18f, hex("66D9D3"));
        finLeft.transform.rotate(Vector3.Y, 24f);
        rotatingProps.add(finLeft);
        ModelInstance finRight = box(1.72f, 1.20f, -2.45f, .13f, .92f, .18f, hex("6FA7D4"));
        finRight.transform.rotate(Vector3.Y, -24f);
        rotatingProps.add(finRight);
        ModelInstance finFront = box(0f, 1.20f, -4.15f, .13f, .92f, .18f, hex("B39BE4"));
        finFront.transform.rotate(Vector3.Y, 90f);
        rotatingProps.add(finFront);

        // Trees, planters, light poles and parking bays.
        for (int x : new int[]{-14, 14}) {
            for (int z : new int[]{-8, -2, 5, 10}) buildTree(x, z);
        }
        for (int x : new int[]{-12, -8, -4, 4, 8, 12}) {
            buildLamp(x, -9.9f);
        }
        for (int x : new int[]{-12, -8, -4, 4, 8, 12}) {
            box(x, .035f, -12.0f, 2.6f, .025f, .035f, hex("E9EFE9"));
        }
        buildVehicle(-8.6f, .30f, -11.1f, hex("397DAA"));
        buildVehicle(8.7f, .30f, -11.1f, hex("D6A66B"));
        buildPlanter(-12.0f, -10.3f);
        buildPlanter(12.0f, -10.3f);

        // Small campus signposts and pathway markings.
        for (int x : new int[]{-6, 0, 6}) {
            box(x, .12f, -8.9f, .65f, .22f, .20f, navy);
            box(x, .25f, -8.78f, .48f, .035f, .025f, hex("6ADAD5"));
        }

        for (int i = 0; i < 8; i++) {
            for (int level = 2; level <= roomLevels[i]; level++) addUpgradeGeometry(i, level);
        }
    }

    private void buildDepartment(int id, float x, float z, Color wall, Color sideWall, Color glass, Color navy, Color metal) {
        Color accent = roomAccents[id];
        box(x, .02f, z, 6.35f, .20f, 7.35f, hex("FAFCF9"));
        // Rear and side walls; the front stays open for a readable cutaway view.
        box(x, 1.35f, z + 3.55f, 6.35f, 2.55f, .20f, wall);
        box(x - 3.10f, 1.35f, z, .20f, 2.55f, 7.05f, wall);
        box(x + 3.10f, 1.35f, z, .20f, 2.55f, 7.05f, sideWall);
        box(x, 2.70f, z + 3.55f, 6.55f, .12f, .38f, navy);
        box(x, .22f, z - 3.62f, 6.10f, .14f, .18f, accent);
        // Back-wall glass windows and mullions.
        for (float wx : new float[]{-2.25f, -.75f, .75f, 2.25f}) {
            box(x + wx, 1.50f, z + 3.43f, .98f, 1.18f, .045f, glass);
            box(x + wx, 2.13f, z + 3.39f, 1.02f, .055f, .08f, metal);
        }
        // Entrance portal and side columns.
        box(x - .98f, 1.15f, z - 3.48f, .14f, 2.25f, .16f, accent);
        box(x + .98f, 1.15f, z - 3.48f, .14f, 2.25f, .16f, accent);
        box(x, 2.25f, z - 3.48f, 2.1f, .14f, .16f, accent);
        // Vertical facade fins and a lit threshold add depth to the open-front architecture.
        for (float fx : new float[]{-2.72f, -2.36f, 2.36f, 2.72f}) {
            box(x + fx, 1.32f, z - 3.60f, .055f, 2.28f, .08f, metal);
        }
        box(x, .16f, z - 3.78f, 2.15f, .055f, .18f, accent);
        for (float lx : new float[]{-1.8f, 0f, 1.8f}) {
            box(x + lx, 2.54f, z - .15f, .85f, .045f, .12f, hex("FFF7DF"));
        }
        // Department identity panel.
        box(x, 2.45f, z - 3.82f, 3.7f, .48f, .14f, navy);
        box(x, 2.45f, z - 3.90f, 3.05f, .075f, .035f, accent);
        buildEquipment(id, x, z, accent, navy, metal);
    }

    private void buildEquipment(int id, float x, float z, Color accent, Color navy, Color metal) {
        Color white = hex("F5F8F5");
        Color cyan = hex("70E3DC");
        if (id == 0) {
            for (float dx : new float[]{-1.9f, 0f, 1.9f}) {
                box(x + dx, .58f, z + .60f, 1.45f, .13f, 1.0f, metal);
                box(x + dx, .98f, z + .48f, 1.13f, .62f, .075f, navy);
                box(x + dx, .99f, z + .43f, .98f, .43f, .022f, cyan);
                box(x + dx, .28f, z + .60f, .11f, .48f, .12f, navy);
            }
        } else if (id == 1) {
            for (float dx : new float[]{-2.1f, -.7f, .7f, 2.1f}) {
                box(x + dx, 1.05f, z + .65f, .78f, 1.85f, 1.2f, navy);
                box(x + dx, 1.05f, z + .025f, .59f, 1.55f, .035f, hex("4389C5"));
                for (float yy : new float[]{.43f, .78f, 1.13f, 1.48f}) {
                    box(x + dx, yy, z - .005f, .45f, .035f, .035f, cyan);
                    sphere(x + dx + .20f, yy + .08f, z - .045f, .07f, .07f, .07f, hex("8BE8B3"));
                }
            }
            // Raised cable trays above the server racks.
            box(x, 2.12f, z + .55f, 5.0f, .07f, .14f, metal);
        } else if (id == 2) {
            for (float dx : new float[]{-1.85f, 0f, 1.85f}) {
                box(x + dx, .67f, z + .58f, 1.15f, 1.12f, 1.0f, white);
                box(x + dx, .68f, z + .055f, .83f, .78f, .055f, cyan);
                cylinder(x + dx, 1.28f, z + .03f, .48f, .06f, metal);
            }
        } else if (id == 3) {
            for (float dx : new float[]{-2.15f, -.72f, .72f, 2.15f}) {
                box(x + dx, .95f, z + .65f, .78f, 1.70f, 1.0f, metal);
                for (float yy : new float[]{.42f, .88f, 1.34f}) {
                    box(x + dx, yy, z + .10f, .66f, .07f, 1.03f, accent);
                    for (int j = 0; j < 3; j++) box(x + dx - .18f + j * .18f, yy + .12f, z + .08f, .12f, .15f, .48f, white);
                }
            }
        } else if (id == 4) {
            for (float dx : new float[]{-1.55f, 1.55f}) {
                box(x + dx, .58f, z + .70f, 1.45f, .14f, 1.45f, metal);
                box(x + dx, .88f, z + .48f, .52f, .58f, .40f, white);
                sphere(x + dx, 1.28f, z + .48f, .42f, .35f, .35f, white);
                sphere(x + dx - .11f, 1.29f, z + .29f, .08f, .08f, .06f, cyan);
                sphere(x + dx + .11f, 1.29f, z + .29f, .08f, .08f, .06f, cyan);
                cylinder(x + dx, 1.58f, z + .48f, .08f, .30f, accent);
            }
        } else if (id == 5) {
            for (float dx : new float[]{-1.85f, 0f, 1.85f}) {
                box(x + dx, .55f, z + .64f, 1.45f, .13f, .90f, metal);
                box(x + dx, .98f, z + .62f, .92f, .60f, .065f, navy);
                box(x + dx, 1.00f, z + .575f, .79f, .43f, .025f, accent);
                box(x + dx, .28f, z + .64f, .12f, .46f, .12f, navy);
            }
        } else if (id == 6) {
            box(x, .60f, z + .70f, 3.6f, .16f, 1.65f, metal);
            for (float dx : new float[]{-1.25f, -.42f, .42f, 1.25f}) {
                box(x + dx, .90f, z + .70f, .48f, .48f, .43f, white);
                box(x + dx, .65f, z - .20f, .42f, .08f, .38f, accent);
            }
            box(x, 1.05f, z + .70f, .68f, .42f, .07f, navy);
        } else {
            for (float dx : new float[]{-1.45f, 0f, 1.45f}) {
                box(x + dx, 1.40f, z + 2.0f, 1.05f, .62f, .08f, navy);
                box(x + dx, 1.40f, z + 1.94f, .91f, .46f, .025f, cyan);
                box(x + dx, .55f, z + .60f, 1.35f, .13f, .78f, metal);
                box(x + dx, .92f, z + .60f, .88f, .56f, .055f, navy);
            }
        }
    }

    private void buildTree(float x, float z) {
        box(x, .18f, z, 1.45f, .36f, 1.45f, hex("B5C9C0"));
        cylinder(x, .95f, z, .20f, 1.55f, hex("927052"));
        sphere(x, 1.95f, z, 1.55f, 1.75f, 1.55f, hex("9FD0B1"));
        sphere(x - .42f, 1.72f, z + .10f, .78f, .90f, .78f, hex("A9DABC"));
    }

    private void buildLamp(float x, float z) {
        cylinder(x, 1.22f, z, .085f, 2.45f, hex("51636A"));
        box(x, 2.47f, z, .38f, .13f, .30f, hex("DAE8E1"));
        sphere(x, 2.52f, z, .23f, .18f, .23f, hex("C5F5E8"));
    }

    private void buildPlanter(float x, float z) {
        box(x, .20f, z, 1.75f, .40f, 1.10f, hex("B6C9C1"));
        for (float dx : new float[]{-.50f, 0f, .50f}) sphere(x + dx, .65f, z, .62f, .74f, .62f, hex("8FC6A4"));
    }

    private void buildVehicle(float x, float y, float z, Color bodyColor) {
        box(x, y + .28f, z, 2.35f, .52f, 1.08f, bodyColor);
        box(x, y + .66f, z + .04f, 1.25f, .42f, .88f, hex("A8D1D2"));
        box(x - .91f, y + .48f, z - .56f, .32f, .16f, .08f, hex("FFF2C6"));
        box(x + .91f, y + .48f, z - .56f, .32f, .16f, .08f, hex("FFF2C6"));
        box(x - .91f, y + .47f, z + .56f, .30f, .14f, .07f, hex("D95B55"));
        box(x + .91f, y + .47f, z + .56f, .30f, .14f, .07f, hex("D95B55"));
        for (float wx : new float[]{-.72f, .72f}) {
            ModelInstance frontWheel = cylinder(x + wx, y + .13f, z - .43f, .43f, .20f, hex("28343C"));
            ModelInstance rearWheel = cylinder(x + wx, y + .13f, z + .43f, .43f, .20f, hex("28343C"));
            frontWheel.transform.rotate(Vector3.X, 90f);
            rearWheel.transform.rotate(Vector3.X, 90f);
        }
    }

    private void addUpgradeGeometry(int room, int level) {
        Vector3 p = roomPositions[room];
        float outward = room < 4 ? 1f : -1f;
        Color accent = roomAccents[room];

        // The first four upgrades create a row of attached modular annexes.
        // Later upgrades add visible rooftop tiers instead of expanding beyond the map.
        if (level >= 2 && level <= 5) {
            float[] slots = {-2.1f, -.7f, .7f, 2.1f};
            float annexX = p.x + slots[level - 2];
            float annexZ = p.z + outward * 4.45f;
            box(annexX, .86f, annexZ, 1.22f, 1.48f, 1.18f, hex("DCEBE5"));
            box(annexX, 1.02f, annexZ - outward * .60f, 1.02f, .92f, .045f, hex("77C9CE"));
            box(annexX, 1.65f, annexZ, 1.30f, .10f, 1.26f, accent);
            box(annexX, .18f, annexZ - outward * .64f, .94f, .07f, .07f, accent);
        } else if (level >= 6) {
            float tierY = 2.82f + (level - 6) * .34f;
            box(p.x, tierY, p.z + outward * 2.72f, 5.75f, .11f, .42f, accent);
            for (float dx : new float[]{-2.35f, -1.15f, 0f, 1.15f, 2.35f}) {
                box(p.x + dx, tierY + .14f, p.z + outward * 2.72f, .075f, .25f, .40f, hex("EAF4EF"));
            }
        }
    }

    private void buildSelectionMarker() {
        // Marker is repositioned around the selected department.
        for (int i = 0; i < 4; i++) {
            selectionMarker[i] = box(0f, .15f, 0f, i < 2 ? 6.65f : .08f, .045f,
                    i < 2 ? .08f : 7.65f, hex("35BDB8"));
        }
        updateSelectionMarker();
    }

    private void updateSelectionMarker() {
        Vector3 p = roomPositions[selectedRoom];
        if (selectionMarker[0] == null) return;
        selectionMarker[0].transform.setToTranslation(p.x, .15f, p.z - 3.78f);
        selectionMarker[1].transform.setToTranslation(p.x, .15f, p.z + 3.78f);
        selectionMarker[2].transform.setToTranslation(p.x - 3.28f, .15f, p.z);
        selectionMarker[3].transform.setToTranslation(p.x + 3.28f, .15f, p.z);
    }

    // ---------- Animated staff ----------

    private void buildInitialStaff() {
        Random random = new Random(27);
        for (int room = 0; room < 8; room++) {
            for (int n = 0; n < roomWorkers[room]; n++) {
                float x = roomPositions[room].x - 1.85f + (n % 3) * 1.25f;
                float z = roomPositions[room].z - 1.40f + (n / 3) * .75f;
                Color shirt = new Color[]{hex("4389C5"), hex("75C79F"), hex("AD98DF"), hex("EFA77C"), hex("36566B")}[random.nextInt(5)];
                spawnStaff(room, x, z, shirt, random.nextFloat() * MathUtils.PI2);
            }
        }
    }

    private void spawnStaff(int room, float x, float z, Color shirt, float phase) {
        if (staff.size >= MAX_VISIBLE_STAFF) return;
        ModelInstance shadow = sphere(x, .12f, z, .48f, .035f, .31f, hex("C4D4CE"));
        ModelInstance body = box(x, .75f, z, .34f, .62f, .23f, shirt);
        ModelInstance head = sphere(x, 1.22f, z, .25f, .27f, .25f, hex("E8C5A7"));
        ModelInstance hair = sphere(x, 1.33f, z - .015f, .255f, .13f, .255f, hex("54443D"));
        ModelInstance armL = box(x - .25f, .75f, z, .12f, .48f, .14f, shirt);
        ModelInstance armR = box(x + .25f, .75f, z, .12f, .48f, .14f, shirt);
        ModelInstance legL = box(x - .10f, .30f, z, .12f, .48f, .14f, hex("293F50"));
        ModelInstance legR = box(x + .10f, .30f, z, .12f, .48f, .14f, hex("293F50"));
        staff.add(new Staff(room, x, z, phase, shadow, body, head, hair, armL, armR, legL, legR));
    }

    private void updateStaff(float delta) {
        for (Staff person : staff) {
            person.phase += delta * (1.1f + speed * .18f);
            float walkX = (float) Math.sin(person.phase) * .22f;
            float walkZ = (float) Math.cos(person.phase * .7f) * .13f;
            float x = person.homeX + walkX;
            float z = person.homeZ + walkZ;
            float leftStep = (float) Math.sin(person.phase * 2f) * .10f;
            float rightStep = (float) Math.sin(person.phase * 2f + MathUtils.PI) * .10f;
            person.shadow.transform.setToTranslation(x, .12f, z);
            person.body.transform.setToTranslation(x, .75f, z);
            person.head.transform.setToTranslation(x, 1.22f, z);
            person.hair.transform.setToTranslation(x, 1.33f, z - .015f);
            person.armLeft.transform.setToTranslation(x - .25f, .75f + rightStep, z);
            person.armRight.transform.setToTranslation(x + .25f, .75f + leftStep, z);
            person.legLeft.transform.setToTranslation(x - .10f, .30f + Math.max(0f, leftStep), z);
            person.legRight.transform.setToTranslation(x + .10f, .30f + Math.max(0f, rightStep), z);
        }
        for (ModelInstance prop : rotatingProps) prop.transform.rotate(Vector3.Y, delta * 45f);
    }

    // ---------- Game simulation ----------

    private int totalStaff() {
        int result = 0;
        for (int value : roomWorkers) result += value;
        return result;
    }

    private int totalLevels() {
        int result = 0;
        for (int value : roomLevels) result += value;
        return result;
    }

    private long productRevenue() {
        long base = 0;
        for (int i = 0; i < productLaunched.length; i++) if (productLaunched[i]) base += productMonthlyRevenue[i];
        // Better model quality improves retention and the monthly revenue of launched products.
        double qualityMultiplier = .75 + modelQuality / 200.0;
        return Math.round(base * qualityMultiplier);
    }

    private long contractRevenue() {
        long result = 0;
        for (int i = 0; i < activeContractMonths.length; i++) if (activeContractMonths[i] > 0) result += contractMonthlyRevenue[i];
        return result;
    }

    private long calculateMonthlyIncome() {
        return 150000L + Math.round(users * 1.40) + totalLevels() * 11500L
                + cpuLevel * 18000L + ramLevel * 9000L + reputation * 1800L
                + productRevenue() + contractRevenue();
    }

    private long calculateMonthlyCosts() {
        return 80000L + totalStaff() * 5400L + totalLevels() * 4800L
                + (cpuLevel * 3200L) + (gpuLevel * 6500L) + (ramLevel * 4500L) + (int) monthlyEventCost[0];
    }

    private void advanceMonth() {
        month++;
        if (month > 12) {
            month = 1;
            year++;
        }
        totalMonths++;
        if (marketingCooldown > 0) marketingCooldown--;

        // Roll this month's event before closing the books so its effects land in the correct month.
        randomMonthlyEvent();
        long income = calculateMonthlyIncome();
        long costs = calculateMonthlyCosts();
        cash += income - costs;
        for (int i = 0; i < activeContractMonths.length; i++) {
            if (activeContractMonths[i] > 0) activeContractMonths[i]--;
        }
        lastIncome = income;
        lastCosts = costs;

        double userGrowth = 1.014 + (productLaunched[0] ? .002 : 0) + (productLaunched[1] ? .002 : 0)
                + Math.max(0, modelQuality - 60) * .00004;
        users = Math.max(1000, (int) Math.min(25_000_000L, Math.round(users * userGrowth)));
        double capacityGrowth = 1.018 + ramLevel * .0007;
        servedUsers = Math.min(users, (int) (servedUsers * capacityGrowth + totalLevels() * 115));
        researchPoints += 18 + roomLevels[0] * 7 + gpuLevel * 4;

        checkAchievements();
        updateHud();
        updateSelectionMarker();
        rebuildRightPanel();
        saveGame();
    }

    private void randomMonthlyEvent() {
        monthlyEventCost[0] = 0f;
        if (MathUtils.random() > .32f) return;
        String[] events = {
                "YATIRIMCI DESTEgi: Sirket kasasina 220.000$ girdi.",
                "MODEL ATILIMI: Arastirma ekibi 85 puan kazandi.",
                "VIRAL BUYUME: Kullanici sayisi hizla artti.",
                "GPU TEDARIKI: Bu ay ek 45.000$ gider olustu.",
                "KURUMSAL TALEP: Itibar 2 puan yukseldi.",
                "GUVENLIK DENETIMI: Sistem kalitesi gelisti."
        };
        int event = MathUtils.random(events.length - 1);
        switch (event) {
            case 0: cash += 220000; break;
            case 1: researchPoints += 85; break;
            case 2: users = (int) Math.min(25_000_000L, users * 1.07); break;
            case 3: monthlyEventCost[0] = 45000f; break;
            case 4: reputation = Math.min(100, reputation + 2); break;
            case 5: modelQuality = Math.min(100, modelQuality + 1); break;
        }
        newsLabel.setText(events[event]);
    }

    private void checkAchievements() {
        if (!achievements[0] && totalLevels() > 9) unlockAchievement(0);
        if (!achievements[1] && totalStaff() >= 25) unlockAchievement(1);
        if (!achievements[2] && users >= 1_000_000) unlockAchievement(2);
        if (!achievements[3] && productLaunched[0] && productLaunched[1] && productLaunched[2]) unlockAchievement(3);
    }

    private void unlockAchievement(int index) {
        achievements[index] = true;
        cash += achievementRewards[index];
        reputation = Math.min(100, reputation + 2);
        newsLabel.setText("BASARIM: " + achievementNames[index] + " tamamlandi. Odul: " + money(achievementRewards[index]));
    }

    private void upgradeDepartment() {
        int i = selectedRoom;
        if (roomLevels[i] >= 12) {
            showNews("BU DEPARTMAN EN YUKSEK SEVIYEYE ULASTI.");
            return;
        }
        if (cash < roomUpgradeCosts[i]) {
            showNews("YETERSIZ BAKIYE: Bu departmani gelistirmek icin daha fazla sermaye gerekli.");
            return;
        }
        cash -= roomUpgradeCosts[i];
        roomLevels[i]++;
        roomUpgradeCosts[i] = Math.round(roomUpgradeCosts[i] * 1.28);
        reputation = Math.min(100, reputation + 1);
        addUpgradeGeometry(i, roomLevels[i]);
        showNews(roomNames[i] + " gelistirildi. Yeni fiziksel bolum kampuse eklendi.");
        checkAchievements();
        refreshAllUi();
    }

    private void hireDepartmentStaff() {
        int i = selectedRoom;
        long cost = 35000L + roomWorkers[i] * 5000L;
        if (roomWorkers[i] >= roomCaps[i] + roomLevels[i] * 2) {
            showNews("PERSONEL KAPASITESI DOLU: Once departmani gelistir.");
            return;
        }
        if (cash < cost) {
            showNews("YETERSIZ BAKIYE: Personel ise alim bedeli " + money(cost) + ".");
            return;
        }
        cash -= cost;
        roomWorkers[i]++;
        float x = roomPositions[i].x - 1.75f + ((roomWorkers[i] - 1) % 3) * 1.12f;
        float z = roomPositions[i].z - 1.30f + ((roomWorkers[i] - 1) / 3) * .70f;
        spawnStaff(i, x, z, roomAccents[(i + 2) % roomAccents.length], MathUtils.random() * MathUtils.PI2);
        showNews(roomNames[i] + " ekibine yeni bir calisan katildi.");
        checkAchievements();
        refreshAllUi();
    }

    private void upgradeHardware(int type) {
        int level = type == 0 ? cpuLevel : type == 1 ? gpuLevel : ramLevel;
        if (level >= 10) {
            showNews("DONANIM SEVIYESI EN UST NOKTADA.");
            return;
        }
        long base = type == 0 ? 180000L : type == 1 ? 240000L : 150000L;
        long cost = Math.round(base * Math.pow(1.58, level - 1));
        if (cash < cost) {
            showNews("YETERSIZ BAKIYE: Donanim gelistirmesi " + money(cost) + ".");
            return;
        }
        cash -= cost;
        if (type == 0) cpuLevel++;
        else if (type == 1) gpuLevel++;
        else ramLevel++;
        reputation = Math.min(100, reputation + 1);
        showNews((type == 0 ? "CPU" : type == 1 ? "GPU" : "RAM") + " altyapisi seviye " + (level + 1) + " oldu.");
        refreshAllUi();
    }

    private void improveModel() {
        int costPoints = 150 + (modelQuality - 60) * 3;
        long cashCost = 90000L + modelQuality * 1300L;
        if (modelQuality >= 100) {
            showNews("MODEL KALITESI ZATEN %100.");
        } else if (researchPoints < costPoints || cash < cashCost) {
            showNews("MODEL GELISTIRMEK ICIN YETERLI AR-GE PUANI VE SERMAYE YOK.");
        } else {
            researchPoints -= costPoints;
            cash -= cashCost;
            modelQuality = Math.min(100, modelQuality + 4);
            reputation = Math.min(100, reputation + 2);
            showNews("YENI MODEL SURUMU: Kalite %" + modelQuality + " seviyesine cikti.");
        }
        refreshAllUi();
    }

    private void launchProduct(int index) {
        if (productLaunched[index]) {
            showNews(productNames[index] + " zaten yayinda.");
            return;
        }
        if (researchPoints < productResearchRequirement[index]) {
            showNews("BU URUN ICIN " + productResearchRequirement[index] + " AR-GE PUANI GEREKIYOR.");
            return;
        }
        if (cash < productCosts[index]) {
            showNews("YETERSIZ SERMAYE: " + productNames[index] + " yatirimi " + money(productCosts[index]) + ".");
            return;
        }
        cash -= productCosts[index];
        productLaunched[index] = true;
        reputation = Math.min(100, reputation + 3);
        showNews(productNames[index] + " pazara sunuldu. Aylik gelir potansiyeli " + money(productMonthlyRevenue[index]) + ".");
        checkAchievements();
        refreshAllUi();
    }

    private void signContract(int index) {
        if (activeContractMonths[index] > 0) {
            showNews(contractNames[index] + " sozlesmesi zaten aktif.");
            return;
        }
        if (cash < contractCosts[index]) {
            showNews("SOZLESME ICIN YETERSIZ BAKIYE: " + money(contractCosts[index]) + ".");
            return;
        }
        cash -= contractCosts[index];
        activeContractMonths[index] = contractDuration[index];
        reputation = Math.min(100, reputation + (index + 1) * 2);
        showNews(contractNames[index] + " musteri sozlesmesi imzalandi. " + contractDuration[index] + " ay boyunca gelir saglayacak.");
        refreshAllUi();
    }

    private void runMarketingCampaign() {
        if (marketingCooldown > 0) {
            showNews("Yeni reklam kampanyasi icin " + marketingCooldown + " ay beklemelisin.");
            return;
        }
        long cost = 140000L;
        if (cash < cost) {
            showNews("REKLAM KAMPANYASI ICIN 140.000$ GEREKIYOR.");
            return;
        }
        cash -= cost;
        users = (int) Math.min(25_000_000L, Math.round(users * 1.12));
        reputation = Math.min(100, reputation + 2);
        marketingCooldown = 3;
        showNews("REKLAM BASARILI: Kullanici sayisi %12 artti.");
        refreshAllUi();
    }

    private void showResetConfirmation() {
        Dialog dialog = new Dialog("YENI OYUN", skin) {
            @Override
            protected void result(Object object) {
                if (Boolean.TRUE.equals(object)) {
                    // Prevent pause/dispose callbacks from writing the old save back.
                    skipSaveOnDispose = true;
                    com.badlogic.gdx.Preferences preferences = Gdx.app.getPreferences("nova_mind_save_v2");
                    preferences.clear();
                    preferences.flush();
                    Gdx.app.exit();
                }
            }
        };
        dialog.text("Tum kampus ilerlemesi, urunler ve sozlesmeler silinecek. Yeni oyun baslatilsin mi?");
        dialog.button("VAZGEC", Boolean.FALSE);
        dialog.button("KAYDI SIL", Boolean.TRUE);
        dialog.show(stage);
    }

    private void showNews(String text) {
        newsLabel.setText(text);
        updateHud();
        if (rightContent != null) rightScroll.layout();
    }

    private void cycleSpeed() {
        if (speed == 1) speed = 2;
        else if (speed == 2) speed = 4;
        else speed = 1;
        updateHud();
    }

    private void togglePause() {
        paused = !paused;
        updateHud();
    }

    private void resetCamera() {
        yaw = 0f;
        pitch = 43f;
        cameraDistance = 39f;
        updateCamera();
        showNews("KAMERA BASLANGIC ACISINA DONDU.");
    }

    // ---------- UI ----------

    private void buildUi() {
        uiViewport = new ExtendViewport(WORLD_W, WORLD_H, 1800f, 900f);
        stage = new Stage(uiViewport);
        skin = new Skin();

        Pixmap pixmap = new Pixmap(2, 2, Pixmap.Format.RGBA8888);
        pixmap.setColor(Color.WHITE);
        pixmap.fill();
        whiteTexture = new Texture(pixmap);
        ownedPixmaps.add(pixmap);
        skin.add("white", new TextureRegionDrawable(new com.badlogic.gdx.graphics.g2d.TextureRegion(whiteTexture)));

        com.badlogic.gdx.graphics.g2d.BitmapFont font = new com.badlogic.gdx.graphics.g2d.BitmapFont();
        font.getData().setScale(1.15f);
        skin.add("default-font", font);
        Label.LabelStyle labelStyle = new Label.LabelStyle(font, hex("F0F5F2"));
        skin.add("default", labelStyle);

        TextButton.TextButtonStyle buttonStyle = new TextButton.TextButtonStyle();
        buttonStyle.up = skin.newDrawable("white", hex("203B4B"));
        buttonStyle.down = skin.newDrawable("white", hex("2E6870"));
        buttonStyle.over = skin.newDrawable("white", hex("315767"));
        buttonStyle.font = font;
        buttonStyle.fontColor = hex("F4F8F5");
        buttonStyle.downFontColor = Color.WHITE;
        skin.add("default", buttonStyle);

        ScrollPane.ScrollPaneStyle scrollStyle = new ScrollPane.ScrollPaneStyle();
        scrollStyle.background = skin.newDrawable("white", new Color(.025f, .075f, .10f, .88f));
        scrollStyle.vScroll = skin.newDrawable("white", hex("536F78"));
        scrollStyle.vScrollKnob = skin.newDrawable("white", hex("79DAD3"));
        skin.add("default", scrollStyle);

        root = new Table();
        root.setFillParent(true);
        root.top();
        stage.addActor(root);

        Table header = new Table();
        header.setBackground(skin.newDrawable("white", new Color(.035f, .085f, .12f, .96f)));
        header.pad(9f, 15f, 9f, 15f);
        Label logo = new Label("NOVA MIND  /  GLOBAL AI GROUP", labelStyle);
        logo.setColor(hex("73E1DC"));
        header.add(logo).left().expandX().minWidth(220f);
        dateLabel = new Label("ARALIK 2026", labelStyle);
        cashLabel = new Label("$4.30M", labelStyle);
        repLabel = new Label("ITIBAR 48", labelStyle);
        usersLabel = new Label("125K KULLANICI", labelStyle);
        researchLabel = new Label("420 AR-GE", labelStyle);
        header.add(dateLabel).padRight(12f);
        header.add(cashLabel).padRight(12f);
        header.add(repLabel).padRight(12f);
        header.add(usersLabel).padRight(12f);
        header.add(researchLabel).padRight(12f);
        speedButton = createButton("HIZ x1", 82f, 42f, new Runnable() { @Override public void run() { cycleSpeed(); } });
        header.add(speedButton).width(82f).height(42f).padRight(5f);
        header.add(createButton("KAMERA", 82f, 42f, new Runnable() { @Override public void run() { resetCamera(); } })).width(82f).height(42f).padRight(5f);
        pauseButton = createButton("DURAKLAT", 95f, 42f, new Runnable() { @Override public void run() { togglePause(); } });
        header.add(pauseButton).width(95f).height(42f).padRight(5f);
        header.add(createButton("KAYDET", 82f, 42f, new Runnable() { @Override public void run() { saveGame(); showNews("OYUN KAYDEDILDI."); } })).width(82f).height(42f);
        root.add(header).growX().height(62f).row();

        Table workspace = new Table();
        workspace.pad(10f);
        root.add(workspace).grow().row();

        Table leftPanel = new Table();
        leftPanel.setBackground(skin.newDrawable("white", new Color(.035f, .085f, .12f, .88f)));
        leftPanel.pad(10f);
        leftPanel.add(new Label("KAMPUS DEPARTMANLARI", labelStyle)).left().padBottom(9f).row();
        departmentButtons = new Table();
        departmentButtons.top().left();
        departmentScroll = new ScrollPane(departmentButtons, skin);
        departmentScroll.setFadeScrollBars(false);
        departmentScroll.setScrollingDisabled(true, false);
        leftPanel.add(departmentScroll).width(238f).growY();
        workspace.add(leftPanel).width(258f).growY().left();
        workspace.add().growX();

        rightPanel = new Table();
        rightPanel.setBackground(skin.newDrawable("white", new Color(.035f, .085f, .12f, .92f)));
        rightPanel.pad(12f);
        rightContent = new Table();
        rightContent.top().left();
        rightScroll = new ScrollPane(rightContent, skin);
        rightScroll.setFadeScrollBars(false);
        rightScroll.setScrollingDisabled(true, false);
        rightPanel.add(rightScroll).grow();
        workspace.add(rightPanel).width(330f).growY().right();

        Table footer = new Table();
        footer.setBackground(skin.newDrawable("white", new Color(.035f, .085f, .12f, .97f)));
        footer.pad(7f, 10f, 7f, 10f);
        String[] tabs = {"GENEL", "DEPARTMAN", "AR-GE", "URUNLER", "SOZLESMELER", "FINANS"};
        for (final String tab : tabs) {
            TextButton button = createButton(tab, 155f, 43f, new Runnable() {
                @Override public void run() { setTab(tab); }
            });
            tabButtons.add(button);
            footer.add(button).width(155f).height(43f).padRight(6f);
        }
        root.add(footer).growX().height(58f);

        refreshDepartmentButtons();
    }

    private TextButton createButton(String text, float width, float height, final Runnable action) {
        TextButton button = new TextButton(text, skin);
        button.getLabel().setFontScale(.88f);
        button.addListener(new ChangeListener() {
            @Override public void changed(ChangeEvent event, Actor actor) {
                action.run();
            }
        });
        return button;
    }

    private Label addHeading(String text) {
        Label label = new Label(text, skin);
        label.setColor(hex("78DED7"));
        label.setFontScale(1.18f);
        rightContent.add(label).left().growX().padBottom(8f).row();
        return label;
    }

    private Label addText(String text) {
        Label label = new Label(text, skin);
        label.setWrap(true);
        rightContent.add(label).left().growX().padBottom(8f).row();
        return label;
    }

    private void addAction(String text, final Runnable action) {
        TextButton button = createButton(text, 280f, 44f, action);
        button.getLabel().setFontScale(.82f);
        rightContent.add(button).width(282f).height(44f).left().padBottom(7f).row();
    }

    private void refreshDepartmentButtons() {
        departmentButtons.clearChildren();
        for (int i = 0; i < roomNames.length; i++) {
            final int index = i;
            String label = (i + 1) + "  " + roomNames[i];
            TextButton button = createButton(label, 218f, 45f, new Runnable() {
                @Override public void run() { selectRoom(index); }
            });
            button.getLabel().setFontScale(.72f);
            if (i == selectedRoom) button.setColor(hex("2B7275"));
            departmentButtons.add(button).width(218f).height(45f).padBottom(5f).row();
        }
        departmentScroll.layout();
    }

    private void setTab(String tab) {
        activeTab = tab;
        refreshTabButtons();
        rebuildRightPanel();
    }

    private void refreshTabButtons() {
        String[] tabs = {"GENEL", "DEPARTMAN", "AR-GE", "URUNLER", "SOZLESMELER", "FINANS"};
        for (int i = 0; i < tabButtons.size; i++) {
            tabButtons.get(i).setColor(tabs[i].equals(activeTab) ? hex("2B7275") : hex("203B4B"));
        }
    }

    private void selectRoom(int index) {
        selectedRoom = MathUtils.clamp(index, 0, roomNames.length - 1);
        updateSelectionMarker();
        refreshDepartmentButtons();
        if ("DEPARTMAN".equals(activeTab) || "GENEL".equals(activeTab)) rebuildRightPanel();
    }

    private void rebuildRightPanel() {
        rightContent.clearChildren();
        if ("GENEL".equals(activeTab)) buildOverviewPanel();
        else if ("DEPARTMAN".equals(activeTab)) buildDepartmentPanel();
        else if ("AR-GE".equals(activeTab)) buildResearchPanel();
        else if ("URUNLER".equals(activeTab)) buildProductsPanel();
        else if ("SOZLESMELER".equals(activeTab)) buildContractsPanel();
        else buildFinancePanel();
        rightScroll.layout();
    }

    private void buildOverviewPanel() {
        addHeading("OPERASYON MERKEZI");
        addText("NOVA MIND kampusunun yonetimi sende. Departmanlari buyut, ekibini genislet ve yeni AI urunlerini piyasaya sun.");
        addText("KASA: " + money(cash) + "\nAYLIK GELIR: " + money(calculateMonthlyIncome())
                + "\nAYLIK GIDER: " + money(calculateMonthlyCosts()) + "\nNET: " + money(calculateMonthlyIncome() - calculateMonthlyCosts()));
        addText("SECILI BIRIM: " + roomNames[selectedRoom] + "\nSEVIYE " + roomLevels[selectedRoom]
                + "  |  PERSONEL " + roomWorkers[selectedRoom] + "/" + (roomCaps[selectedRoom] + roomLevels[selectedRoom] * 2));
        addAction("DEPARTMANI GELISTIR  " + money(roomUpgradeCosts[selectedRoom]), new Runnable() { @Override public void run() { upgradeDepartment(); } });
        addAction("PERSONEL ISE AL  " + money(35000L + roomWorkers[selectedRoom] * 5000L), new Runnable() { @Override public void run() { hireDepartmentStaff(); } });
        addAction("REKLAM KAMPANYASI  $140K", new Runnable() { @Override public void run() { runMarketingCampaign(); } });
        addHeading("BASARIMLAR");
        for (int i = 0; i < achievements.length; i++) {
            addText((achievements[i] ? "[TAMAMLANDI] " : "[KILITLI] ") + achievementNames[i] + "  /  ODUL " + money(achievementRewards[i]));
        }
        addNewsBlock();
    }

    private void buildDepartmentPanel() {
        int i = selectedRoom;
        addHeading("DEPARTMAN YONETIMI");
        addText(roomNames[i] + "\n" + roomDescriptions[i]);
        addText("SEVIYE: " + roomLevels[i] + "\nPERSONEL: " + roomWorkers[i] + " / " + (roomCaps[i] + roomLevels[i] * 2)
                + "\nSONRAKI GELISTIRME: " + money(roomUpgradeCosts[i]));
        addAction("DEPARTMANI GELISTIR", new Runnable() { @Override public void run() { upgradeDepartment(); } });
        addAction("PERSONEL ISE AL", new Runnable() { @Override public void run() { hireDepartmentStaff(); } });
        addText("Gelistirme yeni fiziksel bolum, ekipman ve personel kapasitesi kazandirir. Yuksek seviyeler sirketin aylik gelirini de artirir.");
        addNewsBlock();
    }

    private void buildResearchPanel() {
        addHeading("AR-GE VE ALTYAPI");
        addText("AR-GE PUANI: " + researchPoints + "\nMODEL KALITESI: %" + modelQuality
                + "\nCPU: SEVIYE " + cpuLevel + "  |  GPU: SEVIYE " + gpuLevel + "  |  RAM: SEVIYE " + ramLevel);
        final long cpuCost = hardwareCost(0);
        final long gpuCost = hardwareCost(1);
        final long ramCost = hardwareCost(2);
        addAction("CPU GELISTIR  " + money(cpuCost), new Runnable() { @Override public void run() { upgradeHardware(0); } });
        addAction("GPU GELISTIR  " + money(gpuCost), new Runnable() { @Override public void run() { upgradeHardware(1); } });
        addAction("RAM GELISTIR  " + money(ramCost), new Runnable() { @Override public void run() { upgradeHardware(2); } });
        int pointsCost = 150 + (modelQuality - 60) * 3;
        addAction("AI MODELINI GELISTIR  " + pointsCost + " PUAN", new Runnable() { @Override public void run() { improveModel(); } });
        addText("CPU sirket gelirini ve islem kapasitesini, GPU aylik arastirma puanini, RAM ise hizmet verebilen kullanici kapasitesini artirir. Model kalitesi, yayindaki urunlerin gelirini ve kullanici buyumesini destekler.");
        addNewsBlock();
    }

    private long hardwareCost(int type) {
        int level = type == 0 ? cpuLevel : type == 1 ? gpuLevel : ramLevel;
        long base = type == 0 ? 180000L : type == 1 ? 240000L : 150000L;
        return level >= 10 ? 0 : Math.round(base * Math.pow(1.58, level - 1));
    }

    private void buildProductsPanel() {
        addHeading("NOVA URUN PORTFOYU");
        addText("Kendi yapay zeka urunlerini gelistir ve her ay duzenli gelir elde et.");
        for (int i = 0; i < productNames.length; i++) {
            final int index = i;
            addText(productNames[i] + "\n" + productDescriptions[i] + "\nYATIRIM: " + money(productCosts[i])
                    + "\nAR-GE: " + productResearchRequirement[i] + " PUAN\nAYLIK GELIR: " + money(productMonthlyRevenue[i])
                    + "\nDURUM: " + (productLaunched[i] ? "YAYINDA" : "GELISTIRME BEKLIYOR"));
            addAction(productLaunched[i] ? productNames[i] + " YAYINDA" : productNames[i] + " PAZARA SUN", new Runnable() {
                @Override public void run() { launchProduct(index); }
            });
        }
        addNewsBlock();
    }

    private void buildContractsPanel() {
        addHeading("KURESEL MUSTERI AGI");
        addText("Uzun vadeli musteri anlasmalari imzala. Aktif sozlesmeler, suresi bitene kadar aylik gelir saglar.");
        for (int i = 0; i < contractNames.length; i++) {
            final int index = i;
            addText(contractNames[i] + " SOZLESMESI\nIMZA BEDELI: " + money(contractCosts[i])
                    + "\nAYLIK GELIR: " + money(contractMonthlyRevenue[i])
                    + "\nSURE: " + contractDuration[i] + " AY\nKALAN: " + activeContractMonths[i] + " AY");
            addAction(activeContractMonths[i] > 0 ? "SOZLESME AKTIF" : contractNames[i] + " SOZLESMESI IMZALA", new Runnable() {
                @Override public void run() { signContract(index); }
            });
        }
        addNewsBlock();
    }

    private void buildFinancePanel() {
        addHeading("FINANS VE PERFORMANS");
        long income = calculateMonthlyIncome();
        long costs = calculateMonthlyCosts();
        addText("TOPLAM KASA: " + money(cash) + "\nSON AY GELIRI: " + money(lastIncome)
                + "\nSON AY GIDERI: " + money(lastCosts) + "\nTAHMINI AYLIK NET: " + money(income - costs));
        addText("KULLANICILAR: " + number(users) + "\nHIZMET ALAN: " + number(servedUsers)
                + "\nTOPLAM PERSONEL: " + totalStaff() + "\nDEPARTMAN SEVIYESI: " + totalLevels()
                + "\nAKTIF URUN: " + countProducts() + "/3\nAKTIF SOZLESME: " + countContracts() + "/3");
        addText("Sirketin aylik geliri kullanici tabani, departman seviyesi, donanim, urunler ve musteri sozlesmelerinden etkilenir. Giderler personel, altyapi ve isletme maliyetlerini kapsar.");
        addAction("YENI OYUN / KAYDI SIFIRLA", new Runnable() { @Override public void run() { showResetConfirmation(); } });
        addNewsBlock();
    }

    private int countProducts() {
        int value = 0;
        for (boolean launched : productLaunched) if (launched) value++;
        return value;
    }

    private int countContracts() {
        int value = 0;
        for (int months : activeContractMonths) if (months > 0) value++;
        return value;
    }

    private void addNewsBlock() {
        if (newsLabel == null) newsLabel = new Label("3D alanda surukle: kamerayi dondur. Iki parmakla yakinlastir. Bir binaya dokunarak sec.", skin);
        rightContent.add(new Label("SON GELISME", skin)).left().padTop(7f).padBottom(4f).row();
        newsLabel.setWrap(true);
        rightContent.add(newsLabel).growX().left().padBottom(8f).row();
    }

    private void refreshAllUi() {
        updateHud();
        refreshDepartmentButtons();
        refreshTabButtons();
        rebuildRightPanel();
    }

    private void updateHud() {
        if (cashLabel == null) return;
        cashLabel.setText(moneyShort(cash));
        dateLabel.setText(monthNames[month - 1] + " " + year);
        repLabel.setText("ITIBAR " + reputation);
        usersLabel.setText(numberShort(users) + " KULLANICI");
        researchLabel.setText(researchPoints + " AR-GE");
        speedButton.setText("HIZ x" + speed);
        if (pauseButton != null) pauseButton.setText(paused ? "DEVAM ET" : "DURAKLAT");
    }

    // ---------- Camera input and 3D picking ----------

    private void updateCamera() {
        float yr = MathUtils.degreesToRadians * yaw;
        float pr = MathUtils.degreesToRadians * pitch;
        camera.position.set(
                cameraTarget.x + (float) Math.sin(yr) * (float) Math.cos(pr) * cameraDistance,
                cameraTarget.y + (float) Math.sin(pr) * cameraDistance,
                cameraTarget.z - (float) Math.cos(yr) * (float) Math.cos(pr) * cameraDistance
        );
        camera.lookAt(cameraTarget);
        camera.up.set(Vector3.Y);
        camera.update();
    }

    private void selectDepartmentAt(float screenX, float screenY) {
        Ray ray = camera.getPickRay(screenX, screenY);
        float bestDistance = Float.MAX_VALUE;
        int bestRoom = -1;
        for (int i = 0; i < roomPositions.length; i++) {
            Vector3 p = roomPositions[i];
            BoundingBox bounds = new BoundingBox(
                    new Vector3(p.x - 3.25f, 0f, p.z - 3.75f),
                    new Vector3(p.x + 3.25f, 3.2f, p.z + 3.75f)
            );
            if (Intersector.intersectRayBounds(ray, bounds, pickPoint)) {
                float distance = camera.position.dst2(pickPoint);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestRoom = i;
                }
            }
        }
        if (bestRoom >= 0) selectRoom(bestRoom);
    }

    private boolean isWorldArea(float x, float y) {
        float worldWidth = uiViewport == null ? WORLD_W : uiViewport.getWorldWidth();
        float leftPanelPx = (258f / worldWidth) * Gdx.graphics.getWidth();
        float rightPanelPx = ((worldWidth - 330f) / worldWidth) * Gdx.graphics.getWidth();
        float topHudPx = (62f / WORLD_H) * Gdx.graphics.getHeight();
        float bottomNavPx = (58f / WORLD_H) * Gdx.graphics.getHeight();
        return x > leftPanelPx && x < rightPanelPx
                && y > topHudPx && y < Gdx.graphics.getHeight() - bottomNavPx;
    }

    private class WorldTouchInput extends InputAdapter {
        private final Map<Integer, Vector3> pointers = new HashMap<>();

        @Override
        public boolean touchDown(int screenX, int screenY, int pointer, int button) {
            if (pointers.size() >= 2) return false;
            // The first finger must begin in the 3D viewport; the second may start anywhere for pinch zoom.
            if (pointers.isEmpty() && !isWorldArea(screenX, screenY)) return false;
            pointers.put(pointer, new Vector3(screenX, screenY, 0f));
            activePointers = pointers.size();
            if (activePointers == 1) {
                cameraDragging = true;
                dragMoved = false;
                dragStartX = previousX = screenX;
                dragStartY = previousY = screenY;
            } else if (activePointers == 2) {
                previousPinchDistance = pointerDistance();
                dragMoved = true;
            }
            return true;
        }

        @Override
        public boolean touchDragged(int screenX, int screenY, int pointer) {
            Vector3 old = pointers.get(pointer);
            if (old == null) return false;
            old.set(screenX, screenY, 0f);
            if (pointers.size() == 2) {
                float now = pointerDistance();
                if (previousPinchDistance > 0f) {
                    cameraDistance = MathUtils.clamp(cameraDistance - (now - previousPinchDistance) * .035f, 22f, 68f);
                    updateCamera();
                }
                previousPinchDistance = now;
            } else if (cameraDragging) {
                float dx = screenX - previousX;
                float dy = screenY - previousY;
                if (Math.abs(screenX - dragStartX) + Math.abs(screenY - dragStartY) > 7f) dragMoved = true;
                yaw -= dx * .24f;
                pitch = MathUtils.clamp(pitch + dy * .18f, 18f, 68f);
                updateCamera();
            }
            previousX = screenX;
            previousY = screenY;
            return true;
        }

        @Override
        public boolean touchUp(int screenX, int screenY, int pointer, int button) {
            Vector3 removed = pointers.remove(pointer);
            if (removed == null) return false;
            if (pointers.isEmpty()) {
                if (!dragMoved && cameraDragging) selectDepartmentAt(screenX, screenY);
                cameraDragging = false;
                previousPinchDistance = -1f;
            } else if (pointers.size() == 1) {
                Vector3 remaining = pointers.values().iterator().next();
                previousX = remaining.x;
                previousY = remaining.y;
                cameraDragging = true;
                dragMoved = true;
            }
            activePointers = pointers.size();
            return true;
        }

        private float pointerDistance() {
            if (pointers.size() < 2) return 0f;
            Vector3[] points = pointers.values().toArray(new Vector3[0]);
            float dx = points[0].x - points[1].x;
            float dy = points[0].y - points[1].y;
            return (float) Math.sqrt(dx * dx + dy * dy);
        }
    }

    // ---------- Persistence ----------

    private String money(long value) {
        return String.format(Locale.US, "$%,d", value);
    }

    private String moneyShort(long value) {
        if (Math.abs(value) >= 1_000_000) return String.format(Locale.US, "$%.2fM", value / 1_000_000.0);
        if (Math.abs(value) >= 1_000) return String.format(Locale.US, "$%.0fK", value / 1_000.0);
        return money(value);
    }

    private String number(int value) {
        return String.format(Locale.US, "%,d", value);
    }

    private String numberShort(int value) {
        if (value >= 1_000_000) return String.format(Locale.US, "%.1fM", value / 1_000_000.0);
        if (value >= 1_000) return String.format(Locale.US, "%.0fK", value / 1_000.0);
        return String.valueOf(value);
    }

    private void loadGame() {
        try {
            com.badlogic.gdx.Preferences preferences = Gdx.app.getPreferences("nova_mind_save_v2");
            cash = Math.max(0L, preferences.getLong("cash", cash));
            month = MathUtils.clamp(preferences.getInteger("month", month), 1, 12);
            year = Math.max(2026, preferences.getInteger("year", year));
            reputation = MathUtils.clamp(preferences.getInteger("rep", reputation), 0, 100);
            users = Math.max(1, preferences.getInteger("users", users));
            servedUsers = Math.max(0, preferences.getInteger("served", servedUsers));
            researchPoints = Math.max(0, preferences.getInteger("research", researchPoints));
            modelQuality = MathUtils.clamp(preferences.getInteger("quality", modelQuality), 0, 100);
            cpuLevel = MathUtils.clamp(preferences.getInteger("cpu", cpuLevel), 1, 10);
            gpuLevel = MathUtils.clamp(preferences.getInteger("gpu", gpuLevel), 1, 10);
            ramLevel = MathUtils.clamp(preferences.getInteger("ram", ramLevel), 1, 10);
            speed = preferences.getInteger("speed", 1);
            marketingCooldown = Math.max(0, preferences.getInteger("marketing", 0));
            totalMonths = Math.max(0, preferences.getInteger("totalMonths", 0));
            lastIncome = Math.max(0, preferences.getLong("income", lastIncome));
            lastCosts = Math.max(0, preferences.getLong("costs", lastCosts));
            for (int i = 0; i < 8; i++) {
                roomLevels[i] = MathUtils.clamp(preferences.getInteger("level_" + i, roomLevels[i]), 1, 12);
                roomWorkers[i] = MathUtils.clamp(preferences.getInteger("workers_" + i, roomWorkers[i]), 0, 500);
                roomUpgradeCosts[i] = Math.max(1000L, preferences.getLong("upgrade_" + i, roomUpgradeCosts[i]));
            }
            for (int i = 0; i < 3; i++) {
                productLaunched[i] = preferences.getBoolean("product_" + i, false);
                activeContractMonths[i] = MathUtils.clamp(preferences.getInteger("contract_" + i, 0), 0, 12);
            }
            for (int i = 0; i < 4; i++) achievements[i] = preferences.getBoolean("achievement_" + i, false);
            speed = speed == 1 || speed == 2 || speed == 4 ? speed : 1;
            paused = false;
        } catch (Exception ignored) {
            cash = 4_300_000L;
            month = 12;
            year = 2026;
        }
    }

    private void saveGame() {
        try {
            com.badlogic.gdx.Preferences preferences = Gdx.app.getPreferences("nova_mind_save_v2");
            preferences.putLong("cash", cash);
            preferences.putInteger("month", month);
            preferences.putInteger("year", year);
            preferences.putInteger("rep", reputation);
            preferences.putInteger("users", users);
            preferences.putInteger("served", servedUsers);
            preferences.putInteger("research", researchPoints);
            preferences.putInteger("quality", modelQuality);
            preferences.putInteger("cpu", cpuLevel);
            preferences.putInteger("gpu", gpuLevel);
            preferences.putInteger("ram", ramLevel);
            preferences.putInteger("speed", speed);
            preferences.putInteger("marketing", marketingCooldown);
            preferences.putInteger("totalMonths", totalMonths);
            preferences.putLong("income", lastIncome);
            preferences.putLong("costs", lastCosts);
            for (int i = 0; i < 8; i++) {
                preferences.putInteger("level_" + i, roomLevels[i]);
                preferences.putInteger("workers_" + i, roomWorkers[i]);
                preferences.putLong("upgrade_" + i, roomUpgradeCosts[i]);
            }
            for (int i = 0; i < 3; i++) {
                preferences.putBoolean("product_" + i, productLaunched[i]);
                preferences.putInteger("contract_" + i, activeContractMonths[i]);
            }
            for (int i = 0; i < 4; i++) preferences.putBoolean("achievement_" + i, achievements[i]);
            preferences.flush();
        } catch (Exception ignored) {
            // Saving is best-effort; the UI remains usable if storage is unavailable.
        }
    }

    // ---------- Frame lifecycle ----------

    @Override
    public void render() {
        if (!firstFrameStarted) {
            firstFrameStarted = true;
            logStartupStage("İlk render() karesi başladı; 3D çizim ve arayüz çizimi başlıyor");
        }
        float delta = Math.min(Gdx.graphics.getDeltaTime(), .05f);
        if (!paused && speed > 0) {
            monthClock += delta * speed;
            if (monthClock >= MONTH_SECONDS) {
                monthClock -= MONTH_SECONDS;
                advanceMonth();
            }
        }
        autosaveClock += delta;
        if (autosaveClock >= 60f) {
            autosaveClock = 0f;
            saveGame();
        }
        updateStaff(delta);

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(.64f, .76f, .77f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        Gdx.gl.glDisable(GL20.GL_CULL_FACE);
        modelBatch.begin(camera);
        for (ModelInstance instance : world) modelBatch.render(instance, environment);
        modelBatch.end();

        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST);
        stage.act(delta);
        stage.draw();
        if (!firstFrameLogged) {
            firstFrameLogged = true;
            logStartupStage("İlk render() karesi tamamlandı");
        }
    }

    @Override
    public void resize(int width, int height) {
        if (camera != null) {
            camera.viewportWidth = width;
            camera.viewportHeight = height;
            camera.update();
        }
        if (stage != null) {
            stage.getViewport().update(width, height, true);
            refreshDepartmentButtons();
        }
    }

    @Override
    public void pause() {
        logStartupStage("libGDX pause() çağrıldı");
        if (!skipSaveOnDispose) saveGame();
    }

    @Override
    public void resume() {
        autosaveClock = 0f;
        logStartupStage("libGDX resume() çağrıldı");
    }

    @Override
    public void dispose() {
        logStartupStage("libGDX dispose() başladı");
        if (!skipSaveOnDispose) saveGame();
        if (stage != null) stage.dispose();
        if (skin != null) skin.dispose();
        if (whiteTexture != null) whiteTexture.dispose();
        for (Texture texture : ownedTextures) texture.dispose();
        ownedTextures.clear();
        // Release CPU-side texture sources after their GL textures are gone.
        for (Pixmap pixmap : ownedPixmaps) pixmap.dispose();
        ownedPixmaps.clear();
        if (modelBatch != null) modelBatch.dispose();
        for (Model model : ownedModels) model.dispose();
        ownedModels.clear();
        modelCache.clear();
    }

    private static class Staff {
        final int room;
        final float homeX;
        final float homeZ;
        float phase;
        final ModelInstance shadow, body, head, hair, armLeft, armRight, legLeft, legRight;

        Staff(int room, float x, float z, float phase, ModelInstance shadow, ModelInstance body,
              ModelInstance head, ModelInstance hair, ModelInstance armLeft, ModelInstance armRight,
              ModelInstance legLeft, ModelInstance legRight) {
            this.room = room;
            this.homeX = x;
            this.homeZ = z;
            this.phase = phase;
            this.shadow = shadow;
            this.body = body;
            this.head = head;
            this.hair = hair;
            this.armLeft = armLeft;
            this.armRight = armRight;
            this.legLeft = legLeft;
            this.legRight = legRight;
        }
    }
}
