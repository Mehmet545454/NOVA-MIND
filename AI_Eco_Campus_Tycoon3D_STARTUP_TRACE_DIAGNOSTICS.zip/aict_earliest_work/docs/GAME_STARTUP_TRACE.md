# Game startup and entry-flow diagnostics

The game now writes a persistent, timestamped trace to:

`diagnostics/game_startup_trace.log` (LibGDX local storage; on Android this is in the app-private files area).

The trace records Android-to-game handoff stages, simulation/save initialization, hardware catalog files, intro construction and first rendering, intro skip/timer transition, 3D world/model loading, campus layout, UI setup, input setup, and the first office render.

Each stage is written immediately. During recurring render frames, the current sub-stage is updated in memory without writing every frame. If a Java exception occurs during a render stage, the exact current sub-stage and stack trace are flushed to the trace. The in-app **Hata raporunu kopyala** action includes this file.

Useful stage names include `AUTOSAVE_LOAD`, `CATALOG_FILE_*.json`, `INTRO_FIRST_RENDER_FRAME`, `INTRO_TO_OFFICE_TRANSITION_BEGIN`, `WORLD_MODEL_LIBRARY_LOAD`, `WORLD_CAMPUS_LAYOUT_BUILD`, `UI_THEME_AND_SKIN_SETUP`, `OFFICE_FIRST_RENDER_FRAME_BEGIN`, and render checkpoints such as `OFFICE_3D_SCENE_RENDER`.

This records game launch and entry into the playable campus. This project currently has no separate account sign-in/authentication screen, so there are no username/password login stages to record. Android process starts that never execute the app's code remain outside app-level logging.
