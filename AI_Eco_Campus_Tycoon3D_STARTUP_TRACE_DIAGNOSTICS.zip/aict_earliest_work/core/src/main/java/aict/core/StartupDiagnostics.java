package aict.core;

import com.badlogic.gdx.Gdx;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Persistent game-flow trace. Each stage is flushed immediately so the last completed step survives a crash. */
public final class StartupDiagnostics {
    private static final String PATH = "diagnostics/game_startup_trace.log";
    private static volatile String currentStage = "CORE_NOT_STARTED";
    private StartupDiagnostics() {}

    public static synchronized void stage(String name) {
        currentStage = name;
        write("START  " + name);
    }
    public static synchronized void success(String name) { write("SUCCESS " + name); }
    /** Updates the in-memory failure location without writing every frame to disk. */
    public static void checkpoint(String name) { currentStage = name; }
    public static synchronized void failure(String name, Throwable error) {
        currentStage = name;
        StringBuilder out = new StringBuilder("FAILED  ").append(name).append("\n");
        if (error != null) {
            out.append(error.getClass().getName()).append(": ").append(error.getMessage()).append('\n');
            for (StackTraceElement item : error.getStackTrace()) out.append("    at ").append(item).append('\n');
            Throwable cause = error.getCause();
            int depth = 0;
            while (cause != null && depth++ < 8) {
                out.append("CAUSE: ").append(cause).append('\n');
                for (StackTraceElement item : cause.getStackTrace()) out.append("    at ").append(item).append('\n');
                cause = cause.getCause();
            }
        }
        write(out.toString());
    }
    public static String currentStage() { return currentStage; }
    private static void write(String message) {
        String line = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ROOT).format(new Date())
                + " | " + message + "\n";
        try {
            if (Gdx.files != null) {
                com.badlogic.gdx.files.FileHandle file = Gdx.files.local(PATH);
                file.parent().mkdirs();
                file.writeString(line, true, "UTF-8");
                return;
            }
        } catch (Throwable ignored) { }
        // If LibGDX's file system is not ready yet, keep the event in Android logcat.
        try { if (Gdx.app != null) Gdx.app.error("StartupDiagnostics", line); } catch (Throwable ignored) { }
    }
}
