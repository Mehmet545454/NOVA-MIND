package aict.core;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import aict.sim.HardwareItem;
import aict.sim.Simulation;
import aict.sim.SaveManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.List;

public final class AictGame extends Game {
    private Simulation simulation;
    private final SaveManager saveManager = new SaveManager();
    private Path savePath;
    private int speedBeforePause = 1;

    @Override public void create() {
        StartupDiagnostics.stage("GAME_CREATE_BEGIN");
        try {
            StartupDiagnostics.stage("GRAPHICS_CONFIGURATION");
            Gdx.graphics.setForegroundFPS(60);
            StartupDiagnostics.success("GRAPHICS_CONFIGURATION");

            StartupDiagnostics.stage("SAVE_PATH_INITIALIZATION");
            savePath = Gdx.files.local("saves/autosave.json").file().toPath();
            StartupDiagnostics.success("SAVE_PATH_INITIALIZATION");

            StartupDiagnostics.stage("AUTOSAVE_LOAD");
            try {
                simulation = saveManager.load(savePath);
                StartupDiagnostics.success("AUTOSAVE_LOAD_EXISTING_SAVE");
            } catch (IOException loadError) {
                StartupDiagnostics.failure("AUTOSAVE_LOAD_FALLBACK_TO_NEW_GAME", loadError);
                simulation = new Simulation();
                StartupDiagnostics.success("NEW_SIMULATION_CREATED");
            }

            StartupDiagnostics.stage("STARTER_OFFICE_INITIALIZATION");
            simulation.ensureStarterOffice();
            StartupDiagnostics.success("STARTER_OFFICE_INITIALIZATION");

            StartupDiagnostics.stage("HARDWARE_CATALOG_LOAD");
            loadCatalog();
            StartupDiagnostics.success("HARDWARE_CATALOG_LOAD");

            StartupDiagnostics.stage("INTRO_SCREEN_CONSTRUCTION");
            setScreen(new IntroScreen(this));
            StartupDiagnostics.success("INTRO_SCREEN_CONSTRUCTION_AND_SET");
            StartupDiagnostics.success("GAME_CREATE_COMPLETE");
        } catch (Throwable error) {
            StartupDiagnostics.failure("GAME_CREATE_UNHANDLED", error);
            if (error instanceof RuntimeException) throw (RuntimeException) error;
            if (error instanceof Error) throw (Error) error;
            throw new RuntimeException(error);
        }
    }
    private void loadCatalog() {
        String[] files={"cpu.json","gpu.json","ram.json","storage.json","motherboard.json","psu.json","cooling.json","case.json","monitor.json","peripherals.json","network.json","server_systems.json","datacenter_facility.json"};
        Gson gson=new Gson(); Type type=new TypeToken<List<HardwareItem>>(){}.getType();
        for(String file:files) {
            String stage = "CATALOG_FILE_" + file;
            StartupDiagnostics.stage(stage);
            try {
                String path="hardware/"+file;
                if(!Gdx.files.internal(path).exists()) {
                    StartupDiagnostics.success(stage + "_MISSING_OPTIONAL");
                    continue;
                }
                List<HardwareItem> loaded=gson.fromJson(Gdx.files.internal(path).readString("UTF-8"),type);
                if(loaded!=null)for(HardwareItem item:loaded)simulation.getCatalog().add(item);
                StartupDiagnostics.success(stage);
            } catch(RuntimeException ex) {
                StartupDiagnostics.failure(stage, ex);
                Gdx.app.error("Catalog","Katalog dosyası yüklenemedi: "+file,ex);
            }
        }
    }
    public Simulation simulation(){return simulation;}
    public void saveSlot(int slot){if(slot<1||slot>3){simulation.setLastNotice("Kayıt yuvası 1-3 arasında olmalı.");return;}try{saveManager.save(Gdx.files.local("saves/slot"+slot+".json").file().toPath(),simulation);simulation.setLastNotice("Kayıt yuvası "+slot+" kaydedildi.");}catch(IOException ex){simulation.setLastNotice("Yuva kaydı başarısız: "+ex.getMessage());}}
    public void loadSlot(int slot) {
        StartupDiagnostics.stage("SAVE_SLOT_LOAD_REQUEST_" + slot);
        if (slot < 1 || slot > 3) { StartupDiagnostics.failure("SAVE_SLOT_INVALID_" + slot, null); return; }
        try {
            StartupDiagnostics.stage("SAVE_SLOT_READ_" + slot);
            simulation = saveManager.load(Gdx.files.local("saves/slot" + slot + ".json").file().toPath());
            StartupDiagnostics.success("SAVE_SLOT_READ_" + slot);
            StartupDiagnostics.stage("SAVE_SLOT_CATALOG_RELOAD");
            loadCatalog();
            com.badlogic.gdx.Screen previous = getScreen();
            StartupDiagnostics.stage("SAVE_SLOT_OFFICE_SCREEN_CONSTRUCTION");
            setScreen(new OfficeScreen(this));
            StartupDiagnostics.success("SAVE_SLOT_OFFICE_SCREEN_CONSTRUCTION");
            if (previous != null) previous.dispose();
        } catch (Throwable ex) {
            StartupDiagnostics.failure("SAVE_SLOT_LOAD_FAILED_" + slot, ex);
            if (ex instanceof IOException) simulation.setLastNotice("Kayıt yuvası yüklenemedi: " + ex.getMessage());
            else if (ex instanceof RuntimeException) throw (RuntimeException) ex;
            else if (ex instanceof Error) throw (Error) ex;
            else throw new RuntimeException(ex);
        }
    }

    public void saveGame() {
        try { saveManager.save(savePath,simulation); }
        catch(IOException ex){Gdx.app.error("Save","Kayıt başarısız",ex);simulation.setLastNotice("Kayıt başarısız: "+ex.getMessage());}
    }
    @Override public void pause(){if(simulation!=null){speedBeforePause=simulation.getClock().getSpeed();simulation.pause();saveGame();}super.pause();}
    @Override public void resume(){if(simulation!=null)simulation.setSpeed(speedBeforePause);super.resume();}
    @Override public void dispose(){saveGame();super.dispose();}
}
