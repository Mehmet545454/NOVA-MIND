package aict.core;

import aict.sim.Clock;
import aict.sim.EmployeeManager;
import aict.sim.Simulation;
import aict.sim.HardwareItem;
import aict.sim.OfficeGrid;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Plane;
import com.badlogic.gdx.math.collision.Ray;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import net.mgsx.gltf.scene3d.lights.DirectionalLightEx;
import net.mgsx.gltf.scene3d.scene.SceneManager;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Playable mobile management shell. Missing GLB assets remain clearly marked rather than faked. */
public final class OfficeScreen extends ScreenAdapter {
    private final AictGame game;
    private final Simulation sim;
    private final OrthographicCamera camera = new OrthographicCamera();
    private final ModelBatch modelBatch = new ModelBatch();
    private final Environment environment = new Environment();
    private final DirectionalLight officeKeyLight = new DirectionalLight();
    private ColorAttribute ambientAttribute;
    private DirectionalLightEx gltfKeyLight;
    private final Stage stage = new Stage(new ScreenViewport());
    private final Theme theme = new Theme();
    private final ModelLibrary modelLibrary = new ModelLibrary();
    private MultiTouchCameraController cameraController;
    private final List<ModelInstance> missingMarkers = new ArrayList<>();
    private final List<MissingMarkerLabel> missingMarkerLabels = new ArrayList<>();
    private final List<WorldTextLabel> worldTextLabels = new ArrayList<>();
    private final List<Model> terrainModels = new ArrayList<>();
    private final List<ModelInstance> terrainInstances = new ArrayList<>();
    private final SpriteBatch markerBatch = new SpriteBatch();
    private final GlyphLayout markerGlyph = new GlyphLayout();
    private final Matrix4 markerProjection = new Matrix4();
    private final Color markerPreviousColor = new Color();
    private BitmapFont markerFont;
    private final float density = Math.max(1f, Gdx.graphics.getDensity());
    private Model groundModel;
    private Model markerModel;
    private ModelInstance ground;
    private SceneManager sceneManager;
    private Label dateLabel, cashLabel, employeeLabel, noticeLabel, modelLabel, detailLabel;
    private Label companyLabel, marketLabel;
    private Window panelWindow;
    private Window creditsWindow;
    private Table panelActions;
    private int panelActionCount;
    private long lastAutosaveMonth;
    private int panel;
    private int missingGalleryPage = -1; // -1 = normal office; otherwise paged 3D missing-model gallery
    private int lastLightingMinute = -1;
    private float refreshTimer;

    public OfficeScreen(AictGame game) {
        StartupDiagnostics.stage("OFFICE_SCREEN_CONSTRUCTOR_BEGIN");
        try {
        this.game = game;
        this.sim = game.simulation();
        StartupDiagnostics.stage("OFFICE_SIMULATION_BIND");
        this.lastAutosaveMonth = sim.getClock().getLastProcessedMonth();
        StartupDiagnostics.success("OFFICE_SIMULATION_BIND");
        StartupDiagnostics.stage("OFFICE_WORLD_SETUP_BEGIN");
        setupWorld();
        StartupDiagnostics.success("OFFICE_WORLD_SETUP_COMPLETE");
        StartupDiagnostics.stage("OFFICE_UI_SETUP_BEGIN");
        setupUi();
        StartupDiagnostics.success("OFFICE_UI_SETUP_COMPLETE");
        InputAdapter backHandler = new InputAdapter() {
            @Override public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.BACK || keycode == Input.Keys.ESCAPE) {
                    if (creditsWindow.isVisible()) hideWindowAnimated(creditsWindow);
                    else if (panelWindow.isVisible()) hideWindowAnimated(panelWindow);
                    else showPanel(panel);
                    return true;
                }
                return false;
            }
        };
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        cameraController = new MultiTouchCameraController(camera);
        InputMultiplexer mux = new InputMultiplexer(backHandler, stage, new OfficeDragController(), cameraController);
        Gdx.input.setInputProcessor(mux);
        StartupDiagnostics.success("OFFICE_INPUT_SYSTEM_READY");
        StartupDiagnostics.success("OFFICE_SCREEN_CONSTRUCTOR_COMPLETE");
        } catch (Throwable error) {
            StartupDiagnostics.failure("OFFICE_SCREEN_CONSTRUCTOR_FAILED", error);
            if (error instanceof RuntimeException) throw (RuntimeException) error;
            if (error instanceof Error) throw (Error) error;
            throw new RuntimeException(error);
        }
    }

    private void setupWorld() {
        StartupDiagnostics.stage("WORLD_CAMERA_AND_ENVIRONMENT_SETUP");
        float initialAspect = (float) Gdx.graphics.getWidth() / Math.max(1f, Gdx.graphics.getHeight());
        boolean portrait = initialAspect < 0.85f;
        float viewHeight = portrait ? 24.0f : 14.1f;
        camera.setToOrtho(false, viewHeight * initialAspect, viewHeight);
        camera.position.set(portrait ? 29.5f : 23.5f, portrait ? 27.0f : 21.5f, portrait ? 27.5f : 21.5f);
        camera.lookAt(8f, 0f, 6f);
        camera.zoom = 1.0f;
        camera.near = 0.1f;
        camera.far = 120f;
        camera.update();

        ambientAttribute = ColorAttribute.createAmbientLight(0.76f, 0.78f, 0.77f, 1f);
        environment.set(ambientAttribute);
        environment.add(officeKeyLight.set(0.95f, 0.93f, 0.89f, -0.6f, -1f, -0.45f));
        ModelBuilder builder = new ModelBuilder();
        markerModel = builder.createBox(0.30f, 0.42f, 0.30f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(new Color(0.78f, 0.16f, 0.13f, 1f))),
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);

        // Simple terrain/path surfaces are the only code-built geometry; all buildings and props use GLBs.
        terrainModels.clear();
        terrainInstances.clear();
        Model grass = builder.createRect(-9f, -0.18f, -8f, 25f, -0.18f, -8f,
                25f, -0.18f, 22f, -9f, -0.18f, 22f, 0f, 1f, 0f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(Color.valueOf("79C95B"))),
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        terrainModels.add(grass);
        terrainInstances.add(new ModelInstance(grass));
        Model road = builder.createRect(-3f, -0.15f, 13.1f, 20f, -0.15f, 13.1f,
                20f, -0.15f, 15.3f, -3f, -0.15f, 15.3f, 0f, 1f, 0f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(Color.valueOf("B9B9A8"))),
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        terrainModels.add(road);
        terrainInstances.add(new ModelInstance(road));
        Model entrancePath = builder.createRect(7.2f, -0.13f, 12.0f, 8.8f, -0.13f, 12.0f,
                8.8f, -0.13f, 13.3f, 7.2f, -0.13f, 13.3f, 0f, 1f, 0f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(Color.valueOf("E1C887"))),
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        terrainModels.add(entrancePath);
        terrainInstances.add(new ModelInstance(entrancePath));
        Model pond = builder.createRect(-8.0f, -0.145f, 3.0f, -5.3f, -0.145f, 3.0f,
                -5.3f, -0.145f, 7.5f, -8.0f, -0.145f, 7.5f, 0f, 1f, 0f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(Color.valueOf("45C7D1"))),
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        terrainModels.add(pond);
        terrainInstances.add(new ModelInstance(pond));

        lastLightingMinute = -1;
        StartupDiagnostics.success("WORLD_CAMERA_AND_ENVIRONMENT_SETUP");
        StartupDiagnostics.stage("WORLD_3D_SCENE_MANAGER_SETUP");
        sceneManager = new SceneManager();
        sceneManager.setCamera(camera);
        gltfKeyLight = new DirectionalLightEx();
        gltfKeyLight.direction.set(-0.6f, -1f, -0.45f).nor();
        gltfKeyLight.color.set(Color.WHITE);
        sceneManager.environment.add(gltfKeyLight);
        sceneManager.setAmbientLight(0.85f);
        StartupDiagnostics.success("WORLD_3D_SCENE_MANAGER_SETUP");
        StartupDiagnostics.stage("WORLD_MODEL_LIBRARY_LOAD");
        modelLibrary.load();
        StartupDiagnostics.success("WORLD_MODEL_LIBRARY_LOAD");
        StartupDiagnostics.stage("WORLD_CAMPUS_LAYOUT_BUILD");
        int floorTiles = 0;
        if (missingGalleryPage < 0) {
            floorTiles = OfficeSceneLayout.build(modelLibrary, sceneManager, sim.getOffice(),
                    sim.getEmployeeManager().all(), sim.getComputerCount(), sim.rackCabinets(),
                    sim.warehouseCount(), sim.productionLineCount(), sim.coolingUnits());
            NatureCampusLayout.build(modelLibrary, sceneManager);
        } else {
            for (int z = 0; z < 6; z++) {
                for (int x = 0; x < 8; x++) {
                    if (modelLibrary.place("office.floor", sceneManager, x + 0.5f, -0.05f, z + 0.5f, 0f)) floorTiles++;
                }
            }
        }
        if (floorTiles == 0) {
            // Ground plane fallback is intentionally a surface, never a fabricated prop or character.
            groundModel = builder.createRect(0f, -0.1f, 0f, 16f, -0.1f, 0f,
                    16f, -0.1f, 12f, 0f, -0.1f, 12f, 0f, 1f, 0f,
                    new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(Color.valueOf("B7B3A7"))),
                    VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
            ground = new ModelInstance(groundModel);
        }

        StartupDiagnostics.success("WORLD_CAMPUS_LAYOUT_BUILD");
        StartupDiagnostics.stage("WORLD_LABELS_AND_MISSING_ASSET_MARKERS");
        worldTextLabels.clear();
        if (missingGalleryPage < 0) {
            worldTextLabels.add(new WorldTextLabel("GENEL OFİS", new Vector3(4f, 1.45f, 0.72f)));
            worldTextLabels.add(new WorldTextLabel("AI ARAŞTIRMA LAB", new Vector3(12f, 1.45f, 0.72f)));
            worldTextLabels.add(new WorldTextLabel("VERİ MERKEZİ", new Vector3(4f, 1.45f, 6.72f)));
            worldTextLabels.add(new WorldTextLabel("ÜRETİM VE LOJİSTİK", new Vector3(12f, 1.45f, 6.72f)));
        }

        List<String> keysToShow = new ArrayList<>();
        List<String> allMissing = modelLibrary.missing();
        if (missingGalleryPage < 0) {
            String[] visibleKeys = {"office.door", "character.employee_01", "server.rack", "factory.conveyor"};
            for (String key : visibleKeys) if (allMissing.contains(key)) keysToShow.add(key);
        } else {
            int pageSize = 12;
            int start = Math.min(allMissing.size(), missingGalleryPage * pageSize);
            int end = Math.min(allMissing.size(), start + pageSize);
            keysToShow.addAll(allMissing.subList(start, end));
        }
        for (int i = 0; i < keysToShow.size(); i++) {
            String key = keysToShow.get(i);
            ModelInstance marker = new ModelInstance(markerModel);
            float x;
            float z;
            if (missingGalleryPage < 0) {
                if (key.startsWith("office.")) { x = 0.75f; z = 0.55f; }
                else if (key.startsWith("character.")) { x = 4.0f; z = 3.0f; }
                else if (key.startsWith("server.")) { x = 4.0f; z = 9.1f; }
                else { x = 12.0f; z = 9.1f; }
            } else {
                x = 1.0f + (i % 4) * 2.0f;
                z = 5.1f - (i / 4) * 1.65f;
            }
            marker.transform.setToTranslation(x, 0.28f, z);
            missingMarkers.add(marker);
            missingMarkerLabels.add(new MissingMarkerLabel(key, new Vector3(x, 0.55f, z)));
        }
        StartupDiagnostics.success("WORLD_LABELS_AND_MISSING_ASSET_MARKERS");
    }

    private void setupUi() {
        StartupDiagnostics.stage("UI_THEME_AND_SKIN_SETUP");
        var skin = theme.skin();
        markerFont = skin.getFont("default-font");
        float pad = 5f * density;
        Table root = new Table();
        root.setFillParent(true);
        root.pad(pad);
        root.defaults().space(2f * density);
        stage.addActor(root);

        // Bright tycoon HUD: company identity and cash, then reputation, crew and game time.
        Table top = new Table();
        top.background(themePanel("ui/panel.png"));
        top.pad(3f * density);
        Table headline = new Table();
        companyLabel = styledLabel("AI KAMPÜSÜ", Color.valueOf("FFFFFF"));
        cashLabel = styledLabel("KASA $10,000", Color.valueOf("8FF3A9"));
        headline.add(companyLabel).left().expandX().padLeft(7f * density);
        headline.add(cashLabel).right().padRight(8f * density);
        top.add(headline).growX().height(34f * density).row();

        Table status = new Table();
        marketLabel = styledLabel("İTİBAR 65", Color.valueOf("FFD56B"));
        employeeLabel = styledLabel("EKİP 0/2", Color.valueOf("9FD9FF"));
        dateLabel = styledLabel("YIL 1 • 01/01", Color.valueOf("F0F5FF"));
        status.add(marketLabel).left().expandX().padLeft(7f * density);
        status.add(employeeLabel).center().expandX();
        status.add(dateLabel).right().padRight(8f * density);
        top.add(status).growX().height(31f * density).row();

        Table speed = new Table();
        speed.add(styledLabel("ZAMAN", Color.valueOf("C9D8F5"))).padLeft(6f * density).expandX().left();
        addButton(speed, "Ⅱ", () -> setSpeed(0));
        addButton(speed, "1×", () -> setSpeed(1));
        addButton(speed, "2×", () -> setSpeed(2));
        addButton(speed, "4×", () -> setSpeed(4));
        top.add(speed).growX().height(42f * density).row();
        root.add(top).growX().row();

        // Quick actions form the short objective strip, similar in rhythm to the reference video.
        Table objectivePanel = new Table();
        objectivePanel.background(themePanel("ui/panel.png"));
        objectivePanel.pad(2f * density);
        Label objectiveTitle = new Label("KAMPÜS GELİŞİM GÖREVLERİ", skin);
        objectiveTitle.setColor(Color.valueOf("FFE28A"));
        objectivePanel.add(objectiveTitle).left().padLeft(6f * density).row();
        Table taskActions = new Table();
        deskButton = addButton(taskActions, "MASA +", this::placeDesk);
        addButton(taskActions, "EKİP +", this::hireEmployee);
        addButton(taskActions, "PC KUR", this::buildPc);
        addButton(taskActions, "İŞ AL", this::startJob);
        addButton(taskActions, "AI EĞİT", this::trainAi);
        ScrollPane taskScroll = new ScrollPane(taskActions, skin);
        taskScroll.setScrollingDisabled(false, true);
        taskScroll.setFadeScrollBars(false);
        objectivePanel.add(taskScroll).growX().height(46f * density).row();
        root.add(objectivePanel).growX().row();

        root.add().expandY().row();

        Table bottom = new Table();
        bottom.background(themePanel("ui/panel.png"));
        bottom.pad(3f * density);
        Table nav = new Table();
        addButton(nav, "KAMPÜS", () -> showPanel(0));
        addButton(nav, "EKİP", () -> showPanel(1));
        addButton(nav, "PARÇA", () -> showPanel(2));
        addButton(nav, "AI LAB", () -> showPanel(3));
        addButton(nav, "PAZAR", () -> showPanel(4));
        addButton(nav, "KASA", () -> showPanel(5));
        addButton(nav, "BÖLGE", () -> showPanel(6));
        addButton(nav, "VERİ", () -> showPanel(7));
        addButton(nav, "ÜRETİM", () -> showPanel(8));
        addButton(nav, "AR-GE", () -> showPanel(9));
        addButton(nav, "AYAR", () -> showPanel(10));
        ScrollPane navScroll = new ScrollPane(nav, skin);
        navScroll.setScrollingDisabled(false, true);
        navScroll.setFadeScrollBars(false);
        bottom.add(navScroll).growX().height(50f * density).row();
        noticeLabel = new Label(sim.getLastNotice(), skin);
        noticeLabel.setWrap(false);
        noticeLabel.setAlignment(Align.left);
        noticeLabel.setColor(Color.valueOf("FFF1C3"));
        bottom.add(noticeLabel).growX().padTop(3f * density).row();
        modelLabel = new Label("3D VARLIK DURUMU", skin);
        modelLabel.setColor(Color.valueOf("D6F4D0"));
        bottom.add(modelLabel).growX().padTop(1f * density);
        root.add(bottom).growX().row();

        detailLabel = new Label("AI teknoloji kampüsü", skin);
        detailLabel.setWrap(true);
        detailLabel.setAlignment(Align.left);
        panelWindow = new Window("KAMPÜS YÖNETİMİ", skin);
        panelWindow.setMovable(true);
        panelWindow.setResizable(false);
        float panelWidth = Math.min(Gdx.graphics.getWidth() - 16f * density,
                Math.max(270f * density, Math.min(410f * density, Gdx.graphics.getWidth() * 0.88f)));
        float panelHeight = Math.min(Gdx.graphics.getHeight() - 100f * density,
                Math.max(190f * density, Math.min(340f * density, Gdx.graphics.getHeight() * 0.58f)));
        panelWindow.setSize(panelWidth, panelHeight);
        panelWindow.setPosition((Gdx.graphics.getWidth() - panelWidth) * 0.5f,
                (Gdx.graphics.getHeight() - panelHeight) * 0.5f);
        panelWindow.add(detailLabel).growX().left().top().pad(4f * density).row();
        panelActions = new Table();
        ScrollPane panelScroll = new ScrollPane(panelActions, skin);
        panelScroll.setScrollingDisabled(false, true);
        panelScroll.setFadeScrollBars(false);
        panelWindow.add(panelScroll).grow().pad(3f * density).row();
        Label hint = new Label("Kampüsteki Genel Ofis, AI Laboratuvarı, Veri Merkezi veya Üretim alanına dokunarak o bölgenin yönetim ve yükseltme ekranını aç. Kamerayı sürükleyerek gez, iki parmakla yakınlaştır.", skin);
        hint.setColor(Color.valueOf("C9DDF0"));
        hint.setWrap(true);
        panelWindow.add(hint).growX().pad(3f * density).row();
        TextButton closePanel = new TextButton("KAPAT", skin);
        addButtonMotion(closePanel, () -> hideWindowAnimated(panelWindow));
        panelWindow.add(closePanel).growX().height(42f * density).pad(4f * density);
        stage.addActor(panelWindow);

        creditsWindow = new Window("VARLIK KREDİLERİ", skin);
        creditsWindow.setModal(true);
        creditsWindow.setMovable(true);
        Label creditsText = new Label(loadCreditsText(), skin);
        creditsText.setWrap(true);
        creditsText.setAlignment(Align.left);
        ScrollPane creditsScroll = new ScrollPane(creditsText, skin);
        creditsScroll.setScrollingDisabled(false, true);
        creditsScroll.setFadeScrollBars(false);
        creditsWindow.add(creditsScroll).grow().pad(5f * density).row();
        TextButton closeCredits = new TextButton("KAPAT", skin);
        addButtonMotion(closeCredits, () -> hideWindowAnimated(creditsWindow));
        creditsWindow.add(closeCredits).growX().height(48f * density).pad(4f * density);
        float creditsWidth = Math.max(240f * density, Math.min(650f * density, Gdx.graphics.getWidth() - 18f * density));
        float creditsHeight = Math.max(160f * density, Math.min(430f * density, Gdx.graphics.getHeight() * 0.80f));
        creditsWindow.setSize(creditsWidth, creditsHeight);
        creditsWindow.setPosition((Gdx.graphics.getWidth() - creditsWidth) * 0.5f,
                (Gdx.graphics.getHeight() - creditsHeight) * 0.5f);
        creditsWindow.setVisible(false);
        stage.addActor(creditsWindow);

        showPanel(0);
        panelWindow.clearActions();
        panelWindow.setVisible(false);
        panelWindow.setColor(Color.WHITE);
        panelWindow.setScale(1f);
        updateUi();
    }

    private Label styledLabel(String text, Color color) {
        Label.LabelStyle style = new Label.LabelStyle(theme.skin().get("default", Label.LabelStyle.class));
        style.fontColor = color;
        return new Label(text, style);
    }

    private com.badlogic.gdx.scenes.scene2d.utils.Drawable themePanel(String path) {
        // Theme owns the shared panel texture; use the skin's named style drawable.
        return theme.skin().get("default", com.badlogic.gdx.scenes.scene2d.ui.Window.WindowStyle.class).background;
    }

    private TextButton addButton(Table table, String text, Runnable action) {
        TextButton button = new TextButton(text, theme.skin());
        float size = 48f * density;
        addButtonMotion(button, () -> { action.run(); updateUi(); });
        table.add(button).pad(2f * density).minWidth(58f * density).height(size);
        return button;
    }

    /** Adds a short, restrained press response shared by every clickable UI button. */
    private void addButtonMotion(TextButton button, Runnable action) {
        button.setTransform(true);
        button.setOrigin(Align.center);
        button.addListener(new ClickListener() {
            @Override public boolean touchDown(InputEvent event, float x, float y, int pointer, int buttonCode) {
                boolean accepted = super.touchDown(event, x, y, pointer, buttonCode);
                if (accepted && !button.isDisabled()) {
                    button.clearActions();
                    button.addAction(Actions.scaleTo(0.975f, 0.975f, 0.06f));
                }
                return accepted;
            }

            @Override public void touchUp(InputEvent event, float x, float y, int pointer, int buttonCode) {
                super.touchUp(event, x, y, pointer, buttonCode);
                button.addAction(Actions.scaleTo(1f, 1f, 0.11f, Interpolation.fade));
            }

            @Override public void clicked(InputEvent event, float x, float y) {
                if (!button.isDisabled()) action.run();
            }
        });
        StartupDiagnostics.success("UI_THEME_AND_SKIN_SETUP");
    }

    private void showWindowAnimated(Window window) {
        window.clearActions();
        window.setVisible(true);
        window.toFront();
        window.setTouchable(Touchable.disabled);
        window.setColor(1f, 1f, 1f, 0f);
        window.setScale(0.97f);
        window.addAction(Actions.sequence(
                Actions.parallel(
                        Actions.fadeIn(0.16f),
                        Actions.scaleTo(1f, 1f, 0.19f, Interpolation.fade)),
                Actions.run(() -> window.setTouchable(Touchable.enabled))));
    }

    private void hideWindowAnimated(Window window) {
        if (window == null || !window.isVisible()) return;
        window.clearActions();
        window.setTouchable(Touchable.disabled);
        window.addAction(Actions.sequence(
                Actions.parallel(
                        Actions.fadeOut(0.12f),
                        Actions.scaleTo(0.985f, 0.985f, 0.12f, Interpolation.fade)),
                Actions.run(() -> {
                    window.setVisible(false);
                    window.setColor(Color.WHITE);
                    window.setScale(1f);
                    window.setTouchable(Touchable.enabled);
                })));
    }


    /** Draws zone headers and compact keys beside missing-model markers. */
    private void drawMissingMarkerLabels() {
        if (markerFont == null || (missingMarkerLabels.isEmpty() && worldTextLabels.isEmpty())) return;
        int width = Gdx.graphics.getWidth();
        int height = Gdx.graphics.getHeight();
        markerBatch.setProjectionMatrix(markerProjection.setToOrtho2D(0f, 0f, width, height));
        markerPreviousColor.set(markerFont.getColor());
        markerFont.setColor(Color.valueOf("FF8B82FF"));
        markerBatch.begin();
        for (WorldTextLabel label : worldTextLabels) {
            label.screenPosition.set(label.worldPosition);
            camera.project(label.screenPosition);
            if (label.screenPosition.z < 0f || label.screenPosition.z > 1f) continue;
            markerFont.setColor(Color.valueOf("F4EBD1FF"));
            markerGlyph.setText(markerFont, label.text);
            float x = Math.max(3f, Math.min(width - markerGlyph.width - 3f, label.screenPosition.x - markerGlyph.width * 0.5f));
            float y = Math.max(markerGlyph.height + 3f, Math.min(height - 3f, height - label.screenPosition.y + 13f));
            markerFont.draw(markerBatch, markerGlyph, x, y);
        }
        markerFont.setColor(Color.valueOf("FF8B82FF"));
        for (MissingMarkerLabel marker : missingMarkerLabels) {
            marker.screenPosition.set(marker.worldPosition);
            camera.project(marker.screenPosition);
            if (marker.screenPosition.z < 0f || marker.screenPosition.z > 1f) continue;
            String shortKey = marker.key.substring(marker.key.lastIndexOf('.') + 1).toUpperCase(Locale.ROOT);
            String label = "MODEL EKSİK: " + shortKey;
            markerGlyph.setText(markerFont, label);
            float x = Math.max(3f, Math.min(width - markerGlyph.width - 3f, marker.screenPosition.x - markerGlyph.width * 0.5f));
            float y = Math.max(markerGlyph.height + 3f, Math.min(height - 3f, height - marker.screenPosition.y + 13f));
            markerFont.draw(markerBatch, markerGlyph, x, y);
        }
        markerBatch.end();
        markerFont.setColor(markerPreviousColor);
    }

    private static final class MissingMarkerLabel {
        final String key;
        final Vector3 worldPosition;
        final Vector3 screenPosition;
        MissingMarkerLabel(String key, Vector3 worldPosition) {
            this.key = key;
            this.worldPosition = worldPosition;
            this.screenPosition = new Vector3(worldPosition);
        }
    }

    private static final class WorldTextLabel {
        final String text;
        final Vector3 worldPosition;
        final Vector3 screenPosition;
        WorldTextLabel(String text, Vector3 worldPosition) {
            this.text = text;
            this.worldPosition = worldPosition;
            this.screenPosition = new Vector3(worldPosition);
        }
    }

    private TextButton deskButton;

    private void setSpeed(int speed) { sim.setSpeed(speed); }

    private void showPanel(int index) {
        int requested = Math.max(0, Math.min(10, index));
        boolean closeExisting = panelWindow != null && panel == requested && panelWindow.isVisible();
        panel = requested;
        String[] names = {"OFİS", "EKİP", "DONANIM", "AI LAB", "PAZAR", "FİNANS", "DÜNYA", "VERİ MERKEZİ", "FABRİKA", "ARAŞTIRMA", "SİSTEM"};
        panelWindow.getTitleLabel().setText(names[panel]);
        panelActions.clearChildren();
        panelActionCount = 0;
        switch (panel) {
            case 0 -> {
                limitButton("MASA AL", sim.getOffice().deskCapacity(), Simulation.MAX_DESKS, this::placeDesk);
                panelButton("MASA SAT", this::sellFirstDesk);
                panelButton("BAŞLANGIÇ PC KUR", this::buildPc);
                panelButton("FREELANCE İŞ AL", this::startJob);
                panelButton("KAMERAYI ORTALA", this::centerCamera);
            }
            case 1 -> {
                panelButton("ÇALIŞAN İŞE AL", this::hireEmployee);
                panelButton("İLK ÇALIŞANI ÇIKAR", this::fireFirstEmployee);
                panelButton("OPERASYONA ATA", this::assignFirstEmployee);
            }
            case 2 -> {
                panelButton("CPU SATIN AL", () -> purchaseFirst("cpu"));
                panelButton("GPU SATIN AL", () -> purchaseFirst("gpu"));
                panelButton("RAM SATIN AL", () -> purchaseFirst("ram"));
                panelButton("SSD / DEPOLAMA", () -> purchaseFirst("storage"));
                panelButton("ANAKART", () -> purchaseFirst("motherboard"));
                panelButton("GÜÇ KAYNAĞI", () -> purchaseFirst("psu"));
                panelButton("KASA", () -> purchaseFirst("case"));
                panelButton("MONİTÖR", () -> purchaseFirst("monitor"));
                panelButton("ÇEVRE BİRİMİ", () -> purchaseFirst("peripherals"));
                panelButton("AĞ EKİPMANI", () -> purchaseFirst("network"));
                panelButton("BAŞLANGIÇ PC KUR", this::buildPc);
            }
            case 3 -> {
                panelButton("VERİ SETİ OLUŞTUR", this::createDataset);
                panelButton("VERİ SETİNİ TEMİZLE", this::cleanDataset);
                panelButton("AI EĞİTİMİ BAŞLAT", this::trainAi);
                panelButton("SON MODELİ TEST ET", this::evaluateAi);
                panelButton("MODELİ YAYINLA", this::publishAi);
            }
            case 4 -> {
                panelButton("GÜVENLİK DENETİMİ", this::securityReview);
                panelButton("SUNUCU YÜK TESTİ", this::runWorkloadTest);
                panelButton("YENİ MÜŞTERİ DURUMU", this::refreshMarketNotice);
            }
            case 5 -> {
                panelButton("İŞLETME KREDİSİ", this::takeLoan);
                panelButton("TOHUM YATIRIMI", this::takeInvestment);
                panelButton("HALKA ARZ", this::ipo);
                panelButton("NAKİT AKIŞINI GÖSTER", () -> sim.setLastNotice("Net nakit hareketi: " + money(sim.getEconomy().getLedger().sumCents())));
            }
            case 6 -> {
                panelButton("SONRAKİ OPERASYON BÖLGESİ", this::moveRegion);
                panelButton("TEDARİK SİPARİŞİ", this::orderSupply);
                panelButton("TESLİMATI DEPOYA AL", this::receiveSupply);
            }
            case 7 -> {
                panelButton("1U SUNUCU KUR", () -> installServer(1, "1U hesap sunucusu", 0.45, 0.35));
                panelButton("2U SUNUCU KUR", () -> installServer(2, "2U genel sunucu", 0.9, 0.75));
                panelButton("4U GPU SUNUCU KUR", () -> installServer(4, "4U GPU hızlandırıcı", 1.8, 1.55));
                limitButton("KABİN AL", sim.rackCabinets(), Simulation.MAX_RACK_CABINETS, () -> { if (sim.buyRackCabinet()) rebuildWorld(); });
                limitButton("SOĞUTMA AL", sim.coolingUnits(), Simulation.MAX_COOLING_UNITS, () -> { if (sim.buyCoolingUnit()) rebuildWorld(); });
                panelButton("SUNUCU RACK DURUMU", this::showRackStatus);
                panelButton("KAPASİTE YÜK TESTİ", this::runWorkloadTest);
                panelButton("GÜVENLİK DENETİMİ", this::securityReview);
            }
            case 8 -> {
                limitButton("DEPO AÇ", sim.warehouseCount(), Simulation.MAX_WAREHOUSES, () -> { if (sim.buyWarehouse()) rebuildWorld(); });
                limitButton("ÜRETİM HATTI", sim.productionLineCount(), Simulation.MAX_PRODUCTION_LINES, () -> { if (sim.buyProductionLine()) rebuildWorld(); });
                panelButton("HAMMADDE TEDARİK ET", this::orderSupply);
                panelButton("GELEN SEVKİYATI AL", this::receiveSupply);
                panelButton("ÜRETİMİ BAŞLAT", this::produce);
                panelButton("HAZIR ÜRÜN SAT", this::sellGoods);
            }
            case 9 -> {
                panelButton("SONRAKİ ARAŞTIRMA", this::research);
            }
            case 10 -> {
                panelButton("HIZI DURDUR", () -> setSpeed(0));
                panelButton("HIZI 1X YAP", () -> setSpeed(1));
                panelButton("OTOMATİK KAYDET", this::save);
                panelButton("KAYIT YUVASI 1", () -> game.saveSlot(1));
                panelButton("KAYIT YUVASI 2", () -> game.saveSlot(2));
                panelButton("KAYIT YUVASI 3", () -> game.saveSlot(3));
                panelButton("YUVA 1'İ YÜKLE", () -> game.loadSlot(1));
                panelButton("YUVA 2'Yİ YÜKLE", () -> game.loadSlot(2));
                panelButton("YUVA 3'Ü YÜKLE", () -> game.loadSlot(3));
                panelButton("EKSİK MODEL GALERİSİ", this::openMissingGallery);
                panelButton("ÖNCEKİ MODEL GRUBU", this::previousMissingGalleryPage);
                panelButton("SONRAKİ MODEL GRUBU", this::nextMissingGalleryPage);
                panelButton("OFİSE DÖN", this::returnToOffice);
                panelButton("VARLIK KREDİLERİ", this::openCredits);
            }
        }
        if (closeExisting) hideWindowAnimated(panelWindow);
        else showWindowAnimated(panelWindow);
        updateUi();
    }

    private TextButton panelButton(String text, Runnable action) {
        TextButton button = new TextButton(text, theme.skin());
        addButtonMotion(button, () -> { action.run(); updateUi(); });
        float width = Math.max(108f * density, (panelWindow.getWidth() - 36f * density) * 0.5f);
        panelActions.add(button).width(width).height(48f * density).pad(3f * density);
        panelActionCount++;
        if ((panelActionCount & 1) == 0) panelActions.row();
        return button;
    }

    /** Purchase button that shows owned/limit and turns into a disabled MAX button at the cap. */
    private void limitButton(String name, int owned, int max, Runnable buy) {
        boolean atMax = owned >= max;
        TextButton button = panelButton(atMax ? name + " • MAX" : name + " " + owned + "/" + max, () -> {
            if (owned >= max) sim.setLastNotice(name + ": MAX"); else buy.run();
            reopenPanel();
        });
        button.setDisabled(atMax);
    }
    private void reopenPanel() {
        if (panelWindow != null && panelWindow.isVisible()) {
            panelWindow.clearActions();
            panelWindow.setVisible(false);
            panelWindow.setColor(Color.WHITE);
            panelWindow.setScale(1f);
            showPanel(panel);
        }
    }

    private String panelSummary() {
        return switch (panel) {
            case 1 -> {
                StringBuilder out = new StringBuilder("Çalışan: ").append(sim.getEmployeeManager().size())
                        .append(" / masa kapasitesi: ").append(sim.getOffice().deskCapacity())
                        .append("\nAylık maaş: ").append(money(sim.getEmployeeManager().monthlyPayrollCents()));
                for (var employee : sim.getEmployeeManager().all())
                    out.append("\n").append(employee.name).append(" • Beceri ").append(employee.skill)
                            .append(" • Moral %").append(Math.round(employee.morale * 100));
                yield out.toString();
            }
            case 2 -> "Katalog: " + sim.getCatalog().size() + " ürün • Envanter kalemi: " + sim.getInventory().quantities().size()
                    + " • Kurulu PC: " + sim.getComputerCount() + "\nUyumluluk kontrolü, PC kurulumunda otomatik yapılır.";
            case 3 -> "Veri setleri: " + sim.getAiLab().datasets.size() + " • Eğitim işleri: " + sim.getAiLab().jobs.size()
                    + " • Yayındaki modeller: " + sim.getAiLab().published.size() + "\n" + aiStatus();
            case 4 -> "Rakip şirket: " + sim.getRivals().size() + " • Müşteri: " + sim.getMarket().customers
                    + " • Memnuniyet: %" + Math.round(sim.getMarket().satisfaction) + " • Pazar payı: %" + Math.round(sim.getMarket().marketShare * 100)
                    + "\nAylık yinelenen gelir: " + money(sim.getMarket().monthlyRecurringRevenueCents)
                    + " • İtibar: " + sim.getReputation();
            case 5 -> "Nakit: " + money(sim.getEconomy().getCashCents()) + " • Aylık gelir: " + money(sim.getEconomy().getMonthlyRevenueCents())
                    + " • Gider: " + money(sim.getEconomy().getMonthlyExpenseCents()) + "\nŞirket değeri: " + money(sim.companyValuation())
                    + " • Kredi: " + sim.getFinance().loans.size() + " • Yatırım turu: " + sim.getFinance().investments.size()
                    + " • Defter kaydı: " + sim.getEconomy().getLedger().entries().size();
            case 6 -> "Operasyon bölgesi: " + sim.getWorld().currentCountry + " • Bölge sayısı: " + sim.getWorld().regions.size()
                    + "\nKira x" + sim.getWorld().current().rent + " • Maaş x" + sim.getWorld().current().wage
                    + " • Elektrik x" + sim.getWorld().current().power + " • Lojistik x" + sim.getWorld().current().logistics
                    + "\nDepoda: " + (int)sim.getSupplyChain().storedUnits + " • Yoldaki: " + (int)sim.getSupplyChain().inTransitUnits();
            case 7 -> "Rack: " + sim.getServerRack().usedUnits() + "/" + sim.getServerRack().totalUnits + "U • Cihaz: " + sim.getServerRack().devices.size()
                    + " • Güç: " + String.format(Locale.ROOT, "%.2f", sim.getServerRack().powerKw()) + " kW"
                    + " • Kabin " + sim.rackCabinets() + "/" + Simulation.MAX_RACK_CABINETS + " • Soğutma ünitesi " + sim.coolingUnits() + "/" + Simulation.MAX_COOLING_UNITS + "\nIsı: " + String.format(Locale.ROOT, "%.2f", sim.getServerRack().heatKw()) + " kW\nSoğutma: "
                    + (sim.getFacility().thermalThrottle ? "Yetersiz" : "Normal") + " • Elektrik: "
                    + (sim.getFacility().breakerTripped ? "Aşırı yük" : "Normal");
            case 8 -> "Üretim hattı: " + (sim.getFactory().active == null ? "Boş" : sim.getFactory().active.product)
                    + " • Tamamlanan ürün: " + (int)sim.getFactory().finishedGoods + "\nHammadde: " + (int)sim.getFactory().rawMaterials
                    + " • Depo: " + (int)sim.getSupplyChain().storedUnits + " • Depo sayısı " + sim.warehouseCount() + "/" + Simulation.MAX_WAREHOUSES + " • Hat " + sim.productionLineCount() + "/" + Simulation.MAX_PRODUCTION_LINES + " • Bakım: %" + sim.getFactory().maintenance;
            case 9 -> "Tamamlanan araştırma: " + sim.getResearch().completed.size() + " • Açık araştırma: " + sim.getResearch().unlocked.size()
                    + "\nSonraki araştırma: " + sim.nextResearch();
            case 10 -> "Kayıt sürümü: " + sim.getSaveVersion() + " • Simülasyon hızı: " + sim.getClock().getSpeed() + "x"
                    + "\nDurum: " + (sim.isBankruptcy() ? "İflas riski" : "Faaliyette")
                    + " • Autosave: aylık ve uygulama duraklatıldığında"
                    + "\nEksik GLB: " + modelLibrary.missing().size() + " • Galeri: "
                    + (missingGalleryPage < 0 ? "kapalı" : (missingGalleryPage + 1) + "/" + Math.max(1, (modelLibrary.missing().size() + 11) / 12));
            default -> "Şirket: " + sim.getCompanyName() + " • Ülke: " + sim.getCountry() + "\nMasa: " + sim.getOffice().deskCapacity() + "/" + Simulation.MAX_DESKS
                    + " • Bilgisayar: " + sim.getComputerCount() + " • Çalışan: " + sim.getEmployeeManager().size()
                    + "\nAktif iş: " + sim.getWorkOrders().stream().filter(w -> !w.completed).count()
                    + " • Nakit: " + money(sim.getEconomy().getCashCents());
        };
    }

    private String aiStatus() {
        if (sim.getAiLab().jobs.isEmpty()) return "Henüz eğitim başlatılmadı.";
        var job = sim.getAiLab().jobs.get(sim.getAiLab().jobs.size() - 1);
        return "Son iş: " + job.name + " • " + (job.completed ? (job.evaluated ? "Değerlendirildi" : "Test bekliyor") : "Eğitim sürüyor")
                + " • Kalan oyun süresi: " + job.remainingSeconds + " sn";
    }

    private void placeDesk() {
        if (sim.buyNextDesk()) rebuildWorld();
    }
    private void hireEmployee() {
        EmployeeManager.HireResult result = sim.hireEmployee();
        sim.setLastNotice(result.message());
        if (result.success()) rebuildWorld();
    }
    private void fireFirstEmployee() {
        if (sim.getEmployeeManager().all().isEmpty()) { sim.setLastNotice("İşten çıkarılacak çalışan yok."); return; }
        if (sim.fireEmployee(sim.getEmployeeManager().all().get(0).id)) rebuildWorld();
    }
    private void assignFirstEmployee() {
        if (sim.getEmployeeManager().all().isEmpty()) { sim.setLastNotice("Atanacak çalışan yok."); return; }
        sim.assignEmployee(sim.getEmployeeManager().all().get(0).id, "company-operations");
    }
    private void sellFirstDesk() {
        var desk = sim.getOffice().items().stream().filter(i -> "desk".equals(i.kind())).findFirst();
        if (desk.isEmpty() || !sim.sellDesk(desk.get().id())) sim.setLastNotice("Satılabilecek masa yok veya kapasite engelliyor.");
        else rebuildWorld();
    }
    private void buildPc() {
        if (sim.buildStarterComputer()) rebuildWorld();
    }
    private void startJob() { sim.startFreelanceJob(); }
    private void createDataset() {
        try { sim.createAiDataset("Kurumsal eğitim verisi", 12_000, 72, 15_000L); sim.setLastNotice("12.000 satırlık veri seti oluşturuldu."); }
        catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); }
    }
    private void cleanDataset() {
        if (sim.getAiLab().datasets.isEmpty()) { sim.setLastNotice("Önce veri seti oluştur."); return; }
        var dataset = sim.getAiLab().datasets.get(0);
        if (sim.cleanAiDataset(dataset.id, 10, 8_000L)) sim.setLastNotice("Veri seti temizlendi; kalite " + Math.round(dataset.quality) + ".");
        else sim.setLastNotice("Veri seti temizlenemedi veya temizlik zaten uygulandı.");
    }
    private void trainAi() {
        try {
            if (sim.getAiLab().datasets.isEmpty()) createDataset();
            if (sim.getAiLab().datasets.isEmpty()) return;
            var dataset = sim.getAiLab().datasets.get(0);
            int skill = sim.getEmployeeManager().all().stream().mapToInt(e -> e.skill).max().orElse(45);
            sim.startAiTrainingFromDataset("NOVA-1 Kurumsal Model", dataset.id, 100_000L, 35, skill);
            sim.setLastNotice("AI eğitimi kuyruğa alındı. Oyun zamanı ilerledikçe tamamlanır.");
        } catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); }
    }
    private void evaluateAi() {
        try {
            var result = sim.evaluateLatestAiModel();
            sim.setLastNotice("Test • Doğruluk %" + result.accuracy() + " • Güvenlik %" + result.safety() + " • " + (result.passed() ? "Yayınlanabilir" : "Başarısız"));
        } catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); }
    }
    private void publishAi() { try { sim.publishLatestAiModel(); } catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); } }
    private void purchaseFirst(String category) {
        List<HardwareItem> products = sim.getCatalog().byCategory(category);
        if (products.isEmpty()) { sim.setLastNotice("Bu kategoride katalog ürünü bulunamadı: " + category); return; }
        HardwareItem item = products.get(0);
        boolean bought = sim.purchaseHardware(item.id, false);
        if (bought) sim.setLastNotice(item.label() + " satın alındı. Fiyat: " + money(item.priceCents()));
    }
    private void installServer(int units, String kind, double power, double heat) {
        String id = "server-" + (sim.getServerRack().devices.size() + 1);
        if (sim.installServer(id, kind, units, power, heat)) rebuildWorld();
    }
    private void showRackStatus() {
        var facility = sim.getFacility();
        sim.setLastNotice("Rack " + sim.getServerRack().usedUnits() + "/" + sim.getServerRack().totalUnits + "U • " + sim.getServerRack().devices.size()
                + " cihaz • Güç " + String.format(Locale.ROOT, "%.2f", facility.powerUsedKw) + "/" + facility.powerCapacityKw
                + " kW • Soğutma " + String.format(Locale.ROOT, "%.2f", facility.heatLoadKw) + "/" + facility.coolingCapacityKw + " kW");
    }
    private void runWorkloadTest() {
        var facility = sim.getFacility();
        var report = sim.evaluateWorkload(70, 55, 40, 65, 80, 60, facility.coolingFactor() * 100, Math.max(1, sim.getServerRack().devices.size()));
        sim.setLastNotice("İş yükü testi • Darboğaz: " + report.bottleneck() + " • İş hacmi: " + String.format(Locale.ROOT, "%.1f", report.throughput()));
    }
    private void research() {
        String next = sim.nextResearch();
        if (next.isBlank()) sim.setLastNotice("Açık araştırma kalmadı.");
        else if (!sim.completeResearch(next, 20)) sim.setLastNotice("Araştırma tamamlanamadı: " + next);
    }
    private void produce() {
        if (!sim.beginProduction("AI hızlandırıcı kart", 2, 25_000L)) sim.setLastNotice("Üretim başlatılamadı; nakit, hammadde veya hat meşgul.");
        else sim.setLastNotice("AI hızlandırıcı kart için üretim emri açıldı.");
    }
    private void securityReview() { var result = sim.runSecurityReview(); sim.setLastNotice(result.report() + " Etki: " + result.serviceImpact()); }
    private void sellGoods() {
        var first = sim.getFactory().finishedProducts.entrySet().stream().findFirst();
        if (first.isEmpty() || !sim.sellFactoryGoods(first.get().getKey(), 1, 45_000L)) sim.setLastNotice("Satılacak tamamlanmış ürün yok.");
    }
    private void moveRegion() { sim.moveCompany(sim.getWorld().nextRegion()); }
    private void takeLoan() { try { sim.takeStarterLoan(); } catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); } }
    private void takeInvestment() { try { sim.takeSeedInvestment(); } catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); } }
    private void ipo() { sim.listCompany(); }
    private void orderSupply() {
        try { sim.orderShipment("Genel üretim hammaddesi", 20, 3, 1_000L, sim.getWorld().current().logistics); }
        catch (RuntimeException ex) { sim.setLastNotice(ex.getMessage()); }
    }
    private void receiveSupply() { if (!sim.receiveFirstShipment()) sim.setLastNotice("Teslim alınabilecek sevkiyat yok."); }
    private void refreshMarketNotice() {
        sim.setLastNotice("Müşteri " + sim.getMarket().customers + " • Memnuniyet %" + Math.round(sim.getMarket().satisfaction)
                + " • Yayındaki AI modeli " + sim.getAiLab().published.size() + ". Pazar büyümesi aylık döngüde gerçekleşir.");
    }
    private void centerCamera() {
        float aspect = (float) Gdx.graphics.getWidth() / Math.max(1f, Gdx.graphics.getHeight());
        boolean portrait = aspect < 0.85f;
        float viewHeight = portrait ? 24.0f : 14.1f;
        camera.viewportHeight = viewHeight;
        camera.viewportWidth = viewHeight * aspect;
        camera.position.set(portrait ? 29.5f : 23.5f, portrait ? 27.0f : 21.5f, portrait ? 27.5f : 21.5f);
        camera.lookAt(8f, 0f, 6f);
        if (cameraController != null) cameraController.setTargetZoom(1f);
        camera.update();
        sim.setLastNotice("Kamera kampüs merkezine alındı.");
    }
    private void openMissingGallery() {
        missingGalleryPage = 0;
        rebuildWorld();
        sim.setLastNotice("Eksik modeller galerisi. Kırmızı işaretçiler gerçek model dosyası bulunmayan manifest anahtarlarıdır.");
        updateUi();
    }
    private void previousMissingGalleryPage() {
        if (missingGalleryPage < 0) { openMissingGallery(); return; }
        int pages = Math.max(1, (modelLibrary.missing().size() + 11) / 12);
        missingGalleryPage = (missingGalleryPage - 1 + pages) % pages;
        rebuildWorld();
        sim.setLastNotice("Eksik model grubu " + (missingGalleryPage + 1) + "/" + pages + ".");
        updateUi();
    }
    private void nextMissingGalleryPage() {
        if (missingGalleryPage < 0) { openMissingGallery(); return; }
        int pages = Math.max(1, (modelLibrary.missing().size() + 11) / 12);
        missingGalleryPage = (missingGalleryPage + 1) % pages;
        rebuildWorld();
        sim.setLastNotice("Eksik model grubu " + (missingGalleryPage + 1) + "/" + pages + ".");
        updateUi();
    }
    private void returnToOffice() {
        missingGalleryPage = -1;
        rebuildWorld();
        sim.setLastNotice("Ofis görünümüne dönüldü.");
        updateUi();
    }

    private void moveDesk(String itemId, int x, int z) {
        OfficeGrid.PlacedItem placed = sim.getOffice().find(itemId).orElse(null);
        if (placed == null) return;
        int w = placed.rotation() % 2 == 0 ? placed.width() : placed.depth();
        int d = placed.rotation() % 2 == 0 ? placed.depth() : placed.width();
        if (x < 0 || z < 0 || x + w > OfficeSceneLayout.OFFICE_WIDTH || z + d > OfficeSceneLayout.OFFICE_DEPTH) {
            sim.setLastNotice("Çalışma masaları şimdilik yalnızca genel ofis bölümüne yerleştirilebilir.");
            return;
        }
        if (sim.moveOfficeItem(itemId, x, z)) rebuildWorld();
    }
    private void rebuildWorld() {
        Vector3 position = new Vector3(camera.position);
        Vector3 direction = new Vector3(camera.direction);
        Vector3 up = new Vector3(camera.up);
        float zoom = camera.zoom;
        if (sceneManager != null) sceneManager.dispose();
        modelLibrary.dispose();
        missingMarkers.clear();
        missingMarkerLabels.clear();
        if (groundModel != null) { groundModel.dispose(); groundModel = null; ground = null; }
        for (Model model : terrainModels) model.dispose();
        terrainModels.clear();
        terrainInstances.clear();
        worldTextLabels.clear();
        if (markerModel != null) markerModel.dispose();
        setupWorld();
        camera.position.set(position);
        camera.direction.set(direction);
        camera.up.set(up);
        camera.zoom = zoom;
        if (cameraController != null) cameraController.setTargetZoom(zoom);
        camera.update();
        if (sceneManager != null) sceneManager.setCamera(camera);
        if (sceneManager != null) sceneManager.updateViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        updateModelStatus();
    }
    private void save() { game.saveGame(); sim.setLastNotice("Oyun kaydedildi."); }

    private final class OfficeDragController extends InputAdapter {
        private OfficeGrid.PlacedItem selected;
        private float downX, downY;
        private boolean dragging;
        private final Vector3 intersection = new Vector3();
        private final Plane floorPlane = new Plane(Vector3.Y, 0f);
        @Override public boolean touchDown(int screenX, int screenY, int pointer, int button) {
            if (missingGalleryPage >= 0) return false;
            if (pointer != 0 || button != Input.Buttons.LEFT) return false;
            OfficeGrid.PlacedItem item = itemAtScreen(screenX, screenY);
            if (item != null && "desk".equals(item.kind())) {
                selected = item;
                downX = screenX;
                downY = screenY;
                dragging = false;
                return true;
            }
            int region = regionAtScreen(screenX, screenY);
            if (region >= 0) {
                openRegionPanel(region);
                return true;
            }
            return false;
        }
        @Override public boolean touchDragged(int screenX, int screenY, int pointer) {
            if (selected == null || pointer != 0) return false;
            if (!dragging && Math.hypot(screenX - downX, screenY - downY) > 9f * density) {
                dragging = true;
                sim.setLastNotice("Masayı yeni hücreye sürükle ve bırak.");
            }
            if (dragging) return true;
            return false;
        }
        @Override public boolean touchUp(int screenX, int screenY, int pointer, int button) {
            if (selected == null || pointer != 0) return false;
            OfficeGrid.PlacedItem item = selected;
            selected = null;
            if (!dragging) return true;
            dragging = false;
            Ray ray = camera.getPickRay(screenX, screenY);
            if (Intersector.intersectRayPlane(ray, floorPlane, intersection)) {
                int x = Math.round(intersection.x - item.width() * 0.5f);
                int z = Math.round(intersection.z - item.depth() * 0.5f);
                moveDesk(item.id(), x, z);
            }
            updateUi();
            return true;
        }
        private int regionAtScreen(int screenX, int screenY) {
            Ray ray = camera.getPickRay(screenX, screenY);
            if (!Intersector.intersectRayPlane(ray, floorPlane, intersection)) return -1;
            float x = intersection.x;
            float z = intersection.z;
            if (x < 0f || x >= 16f || z < 0f || z >= 12f) return -1;
            // Four clickable campus wings: office, AI lab, data centre and production.
            if (z < 6f) return x < 8f ? 0 : 3;
            return x < 8f ? 7 : 8;
        }
        private void openRegionPanel(int region) {
            panel = region;
            showPanel(region);
            String[] titles = {"GENEL OFİS", "EKİP", "DONANIM", "AI LAB", "PAZAR",
                    "FİNANS", "DÜNYA", "VERİ MERKEZİ", "FABRİKA", "ARAŞTIRMA", "SİSTEM"};
            panelWindow.getTitleLabel().setText(titles[region] + " • YÖNETİM");
            panelWindow.setPosition((Gdx.graphics.getWidth() - panelWindow.getWidth()) * 0.5f,
                    (Gdx.graphics.getHeight() - panelWindow.getHeight()) * 0.5f);
            panelWindow.toFront();
        }
        private OfficeGrid.PlacedItem itemAtScreen(int screenX, int screenY) {
            Ray ray = camera.getPickRay(screenX, screenY);
            if (!Intersector.intersectRayPlane(ray, floorPlane, intersection)) return null;
            int x = (int)Math.floor(intersection.x);
            int z = (int)Math.floor(intersection.z);
            return sim.getOffice().at(x, z).orElse(null);
        }
    }

    private void updateUi() {
        Clock.CalendarDate date = sim.getClock().date();
        dateLabel.setText(date.display() + " • " + sim.getClock().getSpeed() + "×");
        if (companyLabel != null) companyLabel.setText(sim.getCompanyName());
        cashLabel.setText("KASA " + money(sim.getEconomy().getCashCents()));
        if (marketLabel != null) marketLabel.setText("İTİBAR " + sim.getReputation());
        employeeLabel.setText("EKİP " + sim.getEmployeeManager().size() + "/" + sim.getOffice().deskCapacity());
        if (deskButton != null) deskButton.setText(sim.getOffice().deskCapacity() >= Simulation.MAX_DESKS ? "MASA MAX" : "MASA +");
        noticeLabel.setText(sim.getLastNotice());
        updateModelStatus();
        detailLabel.setText(panelSummary());
    }

    private void updateModelStatus() {
        if (modelLabel == null) return;
        int missing = modelLibrary.missing().size();
        if (missingGalleryPage >= 0) {
            int pages = Math.max(1, (missing + 11) / 12);
            modelLabel.setText("EKSİK MODEL GALERİSİ • " + (missingGalleryPage + 1) + "/" + pages + " • " + missing + " eksik");
        } else {
            modelLabel.setText("3D VARLIK: " + modelLibrary.loadedCount() + " GLB/GLTF YÜKLÜ • " + missing
                    + " EKSİK MODEL — SİSTEM / EKSİK MODEL GALERİSİ");
        }
    }

    private String loadCreditsText() {
        try {
            return Gdx.files.internal("CREDITS.md").readString("UTF-8");
        } catch (RuntimeException ex) {
            return "Varlık kredileri okunamadı. Paket içindeki assets/CREDITS.md dosyasını kontrol et.\n" + ex.getMessage();
        }
    }

    private void openCredits() {
        showWindowAnimated(creditsWindow);
        sim.setLastNotice("Kullanılan 3D modellerin lisans ve kaynak bilgileri açıldı.");
    }

    private static String money(long cents) {
        return NumberFormat.getCurrencyInstance(Locale.US).format(cents / 100.0);
    }

    private void updateLighting() {
        Clock.CalendarDate date = sim.getClock().date();
        int minuteOfDay = date.hour() * 60 + date.minute();
        if (minuteOfDay == lastLightingMinute) return;
        lastLightingMinute = minuteOfDay;
        float hour = date.hour() + date.minute() / 60f;
        float daylight = (float)Math.max(0d, Math.sin((hour - 6f) * Math.PI / 12d));
        float intensity = 0.16f + 0.84f * daylight;
        float red = 1.00f * intensity;
        float green = 0.96f * intensity;
        float blue = 0.88f * intensity;
        float ambient = 0.30f + 0.58f * daylight;
        if (ambientAttribute != null) ambientAttribute.color.set(ambient * 0.91f, ambient * 0.95f, ambient, 1f);
        officeKeyLight.set(red, green, blue, -0.6f, -1f, -0.45f);
        if (gltfKeyLight != null) gltfKeyLight.color.set(red, green, blue, 1f);
        if (sceneManager != null) sceneManager.setAmbientLight(ambient);
    }

    private boolean firstOfficeFrameLogged;
    private boolean firstOfficeFrameSuccessLogged;
    @Override public void render(float delta) {
        StartupDiagnostics.checkpoint("OFFICE_RENDER_FRAME");
        try {
        if (!firstOfficeFrameLogged) {
            firstOfficeFrameLogged = true;
            StartupDiagnostics.stage("OFFICE_FIRST_RENDER_FRAME_BEGIN");
        }
StartupDiagnostics.checkpoint("OFFICE_CAMERA_INPUT_UPDATE");
                if (cameraController != null) cameraController.update(delta);
StartupDiagnostics.checkpoint("OFFICE_SIMULATION_TICK");
                sim.advance(delta);
StartupDiagnostics.checkpoint("OFFICE_LIGHTING_UPDATE");
                updateLighting();
        long currentMonth = sim.getClock().getLastProcessedMonth();
        if (currentMonth != lastAutosaveMonth) {
            lastAutosaveMonth = currentMonth;
            game.saveGame();
        }
        refreshTimer += delta;
        if (refreshTimer > 0.20f) { updateUi(); refreshTimer = 0f; }

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(0.48f, 0.74f, 0.88f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);

StartupDiagnostics.checkpoint("OFFICE_3D_MODEL_BATCH_RENDER");
                modelBatch.begin(camera);
        for (ModelInstance terrain : terrainInstances) modelBatch.render(terrain, environment);
        if (ground != null) modelBatch.render(ground, environment);
        for (ModelInstance marker : missingMarkers) modelBatch.render(marker, environment);
        modelBatch.end();

StartupDiagnostics.checkpoint("OFFICE_MODEL_ANIMATION_UPDATE");
                modelLibrary.updateAnimations(delta);
        sceneManager.update(delta);
StartupDiagnostics.checkpoint("OFFICE_3D_SCENE_RENDER");
                sceneManager.render();

        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST);
        drawMissingMarkerLabels();
StartupDiagnostics.checkpoint("OFFICE_UI_STAGE_UPDATE");
                stage.act(Math.min(delta, 0.033f));
        stage.draw();
        if (firstOfficeFrameLogged && !firstOfficeFrameSuccessLogged) {
            firstOfficeFrameSuccessLogged = true;
            StartupDiagnostics.success("OFFICE_FIRST_RENDER_FRAME_COMPLETE");
        }
    
        } catch (Throwable error) {
            StartupDiagnostics.failure(StartupDiagnostics.currentStage(), error);
            if (error instanceof RuntimeException) throw (RuntimeException) error;
            if (error instanceof Error) throw (Error) error;
            throw new RuntimeException(error);
        }
    }

    @Override public void resize(int width, int height) {
        float aspect = (float) width / Math.max(1f, height);
        float viewHeight = aspect < 0.85f ? 24.0f : 14.1f;
        camera.viewportHeight = viewHeight;
        camera.viewportWidth = viewHeight * aspect;
        camera.update();
        stage.getViewport().update(width, height, true);
        if (panelWindow != null) {
            float w = Math.min(width - 16f * density,
                    Math.max(270f * density, Math.min(410f * density, width * 0.88f)));
            float h = Math.min(height - 100f * density,
                    Math.max(190f * density, Math.min(340f * density, height * 0.58f)));
            panelWindow.setSize(w, h);
            panelWindow.setPosition((width - w) * 0.5f, (height - h) * 0.5f);
        }
        if (creditsWindow != null) {
            float w = Math.max(240f, Math.min(650f * density, width - 18f * density));
            float h = Math.max(160f, Math.min(430f * density, height * 0.80f));
            creditsWindow.setSize(w, h);
            creditsWindow.setPosition((width - w) * 0.5f, (height - h) * 0.5f);
        }
        if (sceneManager != null) sceneManager.updateViewport(width, height);
    }

    @Override public void hide() { game.saveGame(); }

    @Override public void dispose() {
        Gdx.input.setCatchKey(Input.Keys.BACK, false);
        modelBatch.dispose();
        markerBatch.dispose();
        if (groundModel != null) groundModel.dispose();
        for (Model model : terrainModels) model.dispose();
        terrainModels.clear();
        terrainInstances.clear();
        if (markerModel != null) markerModel.dispose();
        if (sceneManager != null) sceneManager.dispose();
        modelLibrary.dispose();
        stage.dispose();
        theme.dispose();
    }
}
