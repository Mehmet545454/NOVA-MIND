package aict.android;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Earliest application-owned crash recorder: installed during Application.attachBaseContext. */
public final class AictDiagnostics {
    private static final String TRACE = "startup_trace.log";
    private static final String CRASH = "last_startup_crash.txt";
    private static final String HISTORY = "diagnostics_history.log";
    private static volatile String currentStage = "PROCESS_ATTACH";
    private static volatile Context appContext;
    private static volatile boolean installed;

    private AictDiagnostics() {}

    public static synchronized void install(Context context) {
        if (installed) return;
        appContext = context.getApplicationContext();
        recordStage("APPLICATION_ATTACH_BASE_CONTEXT");
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                String report = "FATAL JAVA EXCEPTION\nStage: " + currentStage
                        + "\nThread: " + thread.getName() + " (" + thread.getId() + ")\n"
                        + deviceInfo() + "\n" + stackTrace(error);
                writeCrash(report);
                append(HISTORY, report + "\n---\n");
                recordStage("FATAL_EXCEPTION_RECORDED");
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
            else android.os.Process.killProcess(android.os.Process.myPid());
        });
        installed = true;
        recordStage("EARLY_CRASH_HANDLER_INSTALLED");
    }

    public static void recordStage(String stage) {
        currentStage = stage;
        append(TRACE, timestamp() + " | " + stage + " | thread=" + Thread.currentThread().getName() + "\n");
    }

    public static String readPreviousCrash(Context context) {
        File file = new File(context.getFilesDir(), CRASH);
        if (!file.isFile()) return null;
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] data = new byte[(int) Math.min(file.length(), 2 * 1024 * 1024)];
            int count = in.read(data);
            return count > 0 ? new String(data, 0, count, StandardCharsets.UTF_8) : "Crash report empty";
        } catch (Throwable error) { return "Crash report read failed: " + error; }
    }

    public static void collectSystemExitInfo(Context context) {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (manager == null) return;
            List<ApplicationExitInfo> exits = manager.getHistoricalProcessExitReasons(context.getPackageName(), 0, 10);
            if (exits == null || exits.isEmpty()) return;
            StringBuilder out = new StringBuilder("ANDROID HISTORICAL PROCESS EXIT INFO\n");
            for (ApplicationExitInfo info : exits) {
                out.append("time=").append(new Date(info.getTimestamp()))
                   .append(" reason=").append(info.getReason())
                   .append(" description=").append(info.getDescription())
                   .append(" status=").append(info.getStatus())
                   .append(" importance=").append(info.getImportance()).append('\n');
                try (InputStream trace = info.getTraceInputStream()) {
                    if (trace != null) {
                        byte[] bytes = new byte[65536];
                        int n = trace.read(bytes);
                        if (n > 0) out.append(new String(bytes, 0, n, StandardCharsets.UTF_8)).append('\n');
                    }
                } catch (Throwable ignored) { }
            }
            append(HISTORY, out + "\n---\n");
        } catch (Throwable error) { append(TRACE, timestamp() + " | EXIT_INFO_ERROR | " + error + "\n"); }
    }

    public static String readAllDiagnostics(Context context) {
        StringBuilder all = new StringBuilder("AI ECO CAMPUS TYCOON 3D - FULL DIAGNOSTICS\n\n");
        appendFileContents(all, context, CRASH);
        appendFileContents(all, context, TRACE);
        appendFileContents(all, context, HISTORY);
        appendFileContents(all, context, "diagnostics/game_startup_trace.log");
        return all.toString();
    }

    private static void appendFileContents(StringBuilder target, Context context, String name) {
        target.append("\n===== ").append(name).append(" =====\n");
        File file = new File(context.getFilesDir(), name);
        if (!file.isFile()) { target.append("(not created)\n"); return; }
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) target.append(new String(buffer, 0, n, StandardCharsets.UTF_8));
        } catch (Throwable error) { target.append("READ ERROR: ").append(error).append('\n'); }
    }

    public static void clearCrashAfterSuccessfulStartup(Context context) {
        // Keep crash evidence for diagnosis; never silently erase it.
        recordStage("STARTUP_MARKED_SUCCESSFUL");
    }

    private static String deviceInfo() {
        return "Time: " + timestamp() + "\nAndroid: " + Build.VERSION.RELEASE + " API " + Build.VERSION.SDK_INT
                + "\nDevice: " + Build.MANUFACTURER + " " + Build.MODEL;
    }
    private static String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.ROOT).format(new Date());
    }
    private static String stackTrace(Throwable error) {
        StringWriter sw = new StringWriter();
        error.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }
    private static synchronized void writeCrash(String value) {
        Context context = appContext;
        if (context == null) return;
        write(new File(context.getFilesDir(), CRASH), value);
    }
    private static synchronized void append(String name, String value) {
        Context context = appContext;
        if (context == null) return;
        File file = new File(context.getFilesDir(), name);
        try (FileOutputStream out = new FileOutputStream(file, true)) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Throwable ignored) { }
    }
    private static void write(File file, String value) {
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(bytes); out.getFD().sync(); }
        catch (Throwable error) { return; }
        if (!temp.renameTo(file)) {
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); out.getFD().sync(); }
            catch (Throwable ignored) { }
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }
    }
}
