package com.novamind.game.android;

import android.os.Bundle;
import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.novamind.game.NovaMindGame;

public class AndroidLauncher extends AndroidApplication {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AndroidApplicationConfiguration config =
                new AndroidApplicationConfiguration();

        config.useAccelerometer = false;
        config.useCompass = false;
        config.useImmersiveMode = true;

        // Disable multisampling for broader Android GPU compatibility.
        config.numSamples = 0;

        initialize(new NovaMindGame(), config);
    }
}
