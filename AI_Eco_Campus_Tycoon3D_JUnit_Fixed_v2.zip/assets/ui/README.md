# UI textures

`panel.png`, `button_up.png`, `button_over.png` and `button_down.png` are original 9-patch UI textures generated for this project. They use a bright blue/cyan/teal tycoon palette and match the 18 px slicing values in `Theme.java`.
