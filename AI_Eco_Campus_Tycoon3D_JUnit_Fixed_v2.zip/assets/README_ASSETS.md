# Oyun varlıkları

`models/runtime_manifest.json` ana GLB modellerini, `models/nature/scene_manifest.json` kampüs çevre modellerini listeler.

Kaynak ve lisans bilgileri `CREDITS.md` dosyasındadır. Çevre modellerinin CC0 lisansı `models/nature/License_Standard.txt` içinde korunur. Doğrulama: `python3 tools/validate_runtime_assets.py` ve `python3 tools/validate_nature_assets.py`.
