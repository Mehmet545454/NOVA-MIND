# Stylized Nature MegaKit — integrated assets

Source: Quaternius, Stylized Nature MegaKit Standard. License: CC0 1.0 Universal; see `License_Standard.txt`.

The complete supplied glTF folder is preserved under `glTF/`: 68 `.gltf` scene definitions, 68 `.bin` geometry buffers and 20 PNG texture files. Relative URIs are intentionally unchanged so the glTF loader can resolve the original textures and buffers.

`scene_manifest.json` loads 21 selected low-poly nature models into the gameplay scene. Other package models remain bundled for later environment variations and do not all consume runtime memory at launch.
