# Asset Credits

Bu dosya `tools/update_credits.py` ile manifestten üretilir.
`status: available` girdiler listelenir; kaynak/lisans bilgisi eksik olanlar doğrulanmadı olarak işaretlenir.

| Manifest anahtarı | Dosya | Yazar | Kaynak | Lisans | Değişiklik |
|---|---|---|---|---|---|
| office.floor | `models/office/floor.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.wall | `models/office/wall.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.door | `models/office/door.glb` | Kenney | https://kenney.nl/assets/factory-kit | CC0 | Yok |
| office.window | `models/office/window.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.desk | `models/office/desk.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.chair | `models/office/chair.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.monitor | `models/office/monitor.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.laptop | `models/office/laptop.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.keyboard_mouse | `models/office/keyboard_mouse.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.shelf | `models/office/shelf.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.plant | `models/office/plant.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.meeting_table | `models/office/meeting_table.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.sofa | `models/office/sofa.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.coffee_machine | `models/office/coffee_machine.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.lamp | `models/office/lamp.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.trash_bin | `models/office/trash_bin.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| office.box | `models/office/box.glb` | Kenney | https://kenney.nl/assets/furniture-kit | CC0 | Yok |
| character.employee_01 | `models/characters/employee_01.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| character.employee_02 | `models/characters/employee_02.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| character.employee_03 | `models/characters/employee_03.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| character.employee_04 | `models/characters/employee_04.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| character.employee_05 | `models/characters/employee_05.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| character.employee_06 | `models/characters/employee_06.glb` | Kenney | https://kenney.nl/assets/mini-characters | CC0 | Yok |
| server.rack | `models/server/rack.glb` | Innerscene | https://www.innerscene.com/tools/library/3d-parts/low-poly-sci-fi-server-4fc9c6da | CC0 | Yok |
| server.router | `models/server/router.glb` | Innerscene Corp | https://www.innerscene.com/ | CC0 | Yok |
| server.generator | `models/server/generator.glb` | Innerscene | https://www.innerscene.com/tools/library/3d-parts/low-poly-sci-fi-generator-68591035 | CC0 | Yok |
| server.outdoor_unit | `models/server/outdoor_unit.glb` | Innerscene Corp | https://www.innerscene.com/ | CC0 | Yok |
| factory.warehouse_shelf | `models/factory/warehouse_shelf.glb` | RembotGames | https://sketchfab.com/3d-models/warehouse-racking-shelving-low-poly-854bdf0773b24a36a329d7abaee36517 | CC-BY | Yok |
| factory.container | `models/factory/container.glb` | Kenney | https://kenney.nl/assets/city-kit-industrial | CC0 | Yok |
| factory.crane | `models/factory/crane.glb` | Kenney | https://kenney.nl/assets/factory-kit | CC0 | Yok |
| factory.conveyor | `models/factory/conveyor.glb` | Kenney | https://kenney.nl/assets/factory-kit | CC0 | Yok |

## Çevre modelleri — Stylized Nature MegaKit Standard

- Yazar/kaynak: Quaternius — https://quaternius.com/
- Paket: kullanıcının sağladığı Stylized Nature MegaKit Standard arşivi.
- Lisans: CC0 1.0 Universal; orijinal `assets/models/nature/License_Standard.txt` dosyası korunur.
- Değişiklik: Sahne için seçilen 21 glTF model kullanılır; büyük PNG dokuların proje kopyaları 1024 px üst sınırına indirilmiştir.

## Font

- Bu teslimatta ayrı Noto Sans font dosyası bulunmaz. Android sistem Roboto fontu veya libGDX varsayılan bitmap fontu yedek olarak kullanılır.
