package aict.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g3d.utils.AnimationController;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;
import net.mgsx.gltf.loaders.glb.GLBLoader;
import net.mgsx.gltf.loaders.gltf.GLTFLoader;
import net.mgsx.gltf.scene3d.scene.Scene;
import net.mgsx.gltf.scene3d.scene.SceneAsset;
import net.mgsx.gltf.scene3d.scene.SceneManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Loads manifest GLB and glTF assets once and creates lightweight scene instances. */
public final class ModelLibrary {
    // Only the GLB assets used in the live game are included in the runtime manifest.
    private static final Set<String> RUNTIME_MODEL_KEYS = Set.of(
            "office.floor", "office.wall", "office.door", "office.window", "office.desk",
            "office.chair", "office.monitor", "office.laptop", "office.keyboard_mouse",
            "office.shelf", "office.plant", "office.meeting_table", "office.sofa",
            "office.coffee_machine", "office.lamp", "office.trash_bin", "office.box",
            "character.employee_01", "character.employee_02", "character.employee_03",
            "character.employee_04", "character.employee_05", "character.employee_06",
            "server.rack", "server.router", "server.generator", "server.outdoor_unit",
            "factory.warehouse_shelf", "factory.container", "factory.crane",
            "factory.conveyor"
    );

    private final Map<String, SceneAsset> assets = new HashMap<>();
    private final Map<String, float[]> rotations = new HashMap<>();
    private final Map<String, Float> scales = new HashMap<>();
    private final List<SceneAsset> ownedAssets = new ArrayList<>();
    private final List<String> missing = new ArrayList<>();
    private final List<AnimationController> animators = new ArrayList<>();
    private int placedInstances;

    public void load() {
        missing.clear();
        animators.clear();
        placedInstances = 0;
        loadManifest("models/runtime_manifest.json");
        // The supplied Stylized Nature MegaKit is a separate glTF catalogue so its
        // external .bin buffers and PNG textures remain in their original relative paths.
        loadManifest("models/nature/scene_manifest.json");
        Gdx.app.log("ModelLibrary", "3D varlık hazır: " + assets.size() + " • eksik: " + missing.size());
    }

    private void loadManifest(String path) {
        if (!Gdx.files.internal(path).exists()) {
            missing.add(path);
            Gdx.app.error("ModelLibrary", "Model manifesti bulunamadı: " + path);
            return;
        }

        JsonValue root;
        try {
            root = new JsonReader().parse(Gdx.files.internal(path));
        } catch (RuntimeException ex) {
            missing.add(path);
            Gdx.app.error("ModelLibrary", "Manifest okunamadı: " + path, ex);
            return;
        }
        JsonValue entries = root.get("models");
        if (entries == null || !entries.isArray()) {
            Gdx.app.error("ModelLibrary", "Manifest içinde models dizisi bulunamadı: " + path);
            return;
        }

        for (JsonValue item : entries) {
            String key = item.getString("key", "unknown");
            String file = item.getString("file", "");
            String status = item.getString("status", "available");
            if ("models/runtime_manifest.json".equals(path) && !RUNTIME_MODEL_KEYS.contains(key)) {
                continue;
            }
            if (!"available".equals(status) || file.trim().isEmpty() || !Gdx.files.internal(file).exists()) {
                missing.add(key);
                Gdx.app.log("ModelLibrary", "MODEL EKSİK: " + key + " -> " + file);
                continue;
            }

            try {
                SceneAsset asset = file.toLowerCase().endsWith(".gltf")
                        ? new GLTFLoader().load(Gdx.files.internal(file))
                        : new GLBLoader().load(Gdx.files.internal(file));
                assets.put(key, asset);
                ownedAssets.add(asset);
                scales.put(key, item.getFloat("scale", 1f));
                JsonValue rotation = item.get("rotation");
                float[] angles = new float[3];
                if (rotation != null && rotation.isArray()) {
                    for (int i = 0; i < Math.min(3, rotation.size); i++) angles[i] = rotation.get(i).asFloat();
                }
                rotations.put(key, angles);
                Gdx.app.log("ModelLibrary", "3D model yüklendi: " + key);
            } catch (Exception ex) {
                missing.add(key);
                Gdx.app.error("ModelLibrary", "Model yüklenemedi: " + key + " -> " + file, ex);
            }
        }
    }

    /** Places one instance while reusing the already-loaded model data. */
    public boolean place(String key, SceneManager manager, float x, float y, float z, float yawDegrees) {
        return placeScaled(key, manager, x, y, z, yawDegrees, 1f, 1f, 1f);
    }

    /** Reuses a model while stretching modular architectural pieces to fit a room. */
    public boolean placeScaled(String key, SceneManager manager, float x, float y, float z,
                               float yawDegrees, float scaleX, float scaleY, float scaleZ) {
        return createScene(key, manager, x, y, z, yawDegrees, scaleX, scaleY, scaleZ) != null;
    }

    /**
     * Places a rigged character and loops one of its GLB animations (for example "sit" or "idle").
     * Falls back to "idle" when the requested clip does not exist. The speed varies slightly so
     * several employees never move in lockstep.
     */
    public boolean placeAnimated(String key, SceneManager manager, float x, float y, float z,
                                 float yawDegrees, String animation, float speed) {
        Scene scene = createScene(key, manager, x, y, z, yawDegrees, 1f, 1f, 1f);
        if (scene == null) return false;
        String clip = scene.modelInstance.getAnimation(animation) != null ? animation
                : (scene.modelInstance.getAnimation("idle") != null ? "idle" : null);
        if (clip == null) return true;
        AnimationController controller = new AnimationController(scene.modelInstance);
        controller.setAnimation(clip, -1, speed, null);
        animators.add(controller);
        return true;
    }

    /** Advances every looping character animation; call once per frame before SceneManager.update. */
    public void updateAnimations(float delta) {
        for (AnimationController controller : animators) controller.update(delta);
    }

    private Scene createScene(String key, SceneManager manager, float x, float y, float z,
                              float yawDegrees, float scaleX, float scaleY, float scaleZ) {
        SceneAsset asset = assets.get(key);
        if (asset == null) return null;
        if (!Float.isFinite(scaleX) || !Float.isFinite(scaleY) || !Float.isFinite(scaleZ)
                || scaleX <= 0f || scaleY <= 0f || scaleZ <= 0f) return null;

        Scene scene = new Scene(asset.scene);
        scene.modelInstance.transform.setToTranslation(x, y, z);
        float[] angle = rotations.getOrDefault(key, new float[3]);
        if (angle[0] != 0f) scene.modelInstance.transform.rotate(Vector3.X, angle[0]);
        if (angle[1] != 0f) scene.modelInstance.transform.rotate(Vector3.Y, angle[1]);
        if (angle[2] != 0f) scene.modelInstance.transform.rotate(Vector3.Z, angle[2]);
        if (yawDegrees != 0f) scene.modelInstance.transform.rotate(Vector3.Y, yawDegrees);
        float scale = scales.getOrDefault(key, 1f);
        scene.modelInstance.transform.scale(scale * scaleX, scale * scaleY, scale * scaleZ);
        manager.addScene(scene);
        placedInstances++;
        return scene;
    }

    public boolean has(String key) { return assets.containsKey(key); }
    public int loadedCount() { return assets.size(); }
    public int placedInstances() { return placedInstances; }
    public List<String> missing() { return new ArrayList<>(missing); }

    public void dispose() {
        for (SceneAsset asset : ownedAssets) asset.dispose();
        ownedAssets.clear();
        animators.clear();
        assets.clear();
        rotations.clear();
        scales.clear();
        missing.clear();
        placedInstances = 0;
    }
}
