package aict.core;

import aict.sim.Employee;
import aict.sim.OfficeGrid;
import net.mgsx.gltf.scene3d.scene.SceneManager;

import java.util.List;

/**
 * Builds the four-wing cutaway company campus seen from the isometric gameplay camera.
 * All furniture and architectural modules are instances of licensed manifest GLBs.
 */
public final class OfficeSceneLayout {
    public static final int CAMPUS_WIDTH = 16;
    public static final int CAMPUS_DEPTH = 12;
    public static final int OFFICE_WIDTH = 8;
    public static final int OFFICE_DEPTH = 6;

    private OfficeSceneLayout() { }

    public static int build(ModelLibrary models, SceneManager manager, OfficeGrid office,
                            List<Employee> employees, int computerCount, int rackCabinets,
                            int warehouses, int productionLines, int coolingUnits) {
        int floors = 0;
        // Four modular floor slabs: general office, AI lab, data centre, and production wing.
        float[][] rooms = {{0f, 0f}, {8f, 0f}, {0f, 6f}, {8f, 6f}};
        for (float[] room : rooms) {
            if (models.placeScaled("office.floor", manager, room[0] + 4f, -0.07f,
                    room[1] + 3f, 0f, 8f, 1f, 6f)) floors++;
        }

        // Cutaway architecture: the far and left walls remain; the camera-facing sides stay open.
        for (int x = 0; x < CAMPUS_WIDTH; x++) {
            boolean window = x == 2 || x == 5 || x == 10 || x == 13;
            if (x == 7) { // entrance door scaled to the wall module (1.0 wide, 1.29 high)
                models.placeScaled("office.door", manager, x + 0.5f, 0f, 0.04f, 0f, 1.25f, 0.8f, 0.4f);
                continue;
            }
            models.place(window ? "office.window" : "office.wall", manager,
                    x + 0.5f, 0f, 0.04f, 0f);
        }
        for (int z = 0; z < CAMPUS_DEPTH; z++) {
            models.place("office.wall", manager, 0.04f, 0f, z + 0.5f, 90f);
        }

        // Low internal dividers give each wing a distinct room without hiding its contents.
        for (int z = 0; z < OFFICE_DEPTH; z++) {
            if (z == 2 || z == 3) continue; // open connection between office and AI lab
            models.placeScaled("office.wall", manager, 8.04f, 0f, z + 0.5f, 90f, 1f, 0.58f, 1f);
        }
        for (int x = 0; x < CAMPUS_WIDTH; x++) {
            if (x == 7 || x == 8) continue; // central campus corridor
            models.placeScaled("office.wall", manager, x + 0.5f, 0f, 6.04f, 0f, 1f, 0.58f, 1f);
        }

        // Player-managed desks stay in the first office wing; their placement is persisted by OfficeGrid.
        List<OfficeGrid.PlacedItem> desks = office.items().stream()
                .filter(item -> "desk".equals(item.kind())).toList();
        for (int i = 0; i < desks.size(); i++) {
            OfficeGrid.PlacedItem desk = desks.get(i);
            int rotatedWidth = desk.rotation() % 2 == 0 ? desk.width() : desk.depth();
            int rotatedDepth = desk.rotation() % 2 == 0 ? desk.depth() : desk.width();
            float x = desk.x() + rotatedWidth * 0.5f;
            float z = desk.z() + rotatedDepth * 0.5f;
            float yaw = desk.rotation() == 0 ? 0f : 90f;
            models.place(desk.modelKey(), manager, x, 0f, z, yaw);
            models.place("office.chair", manager, x, 0f, z + 0.72f, 180f + yaw);
            if (i < employees.size()) {
                // Employees with a PC sit on the chair and work; the others stand idle beside it.
                // Speed varies per employee so the looping clips do not play in lockstep.
                String key = String.format("character.employee_%02d", i % 6 + 1);
                float speed = 0.9f + 0.05f * i;
                if (i < computerCount) models.placeAnimated(key, manager, x, 0f, z + 0.72f, 180f + yaw, "sit", speed);
                else models.placeAnimated(key, manager, x, 0f, z + 1.2f, 180f + yaw, "idle", speed);
            }
            if (i < computerCount) {
                if ((i & 1) == 0) {
                    models.place("office.monitor", manager, x, 0.384f, z - 0.13f, yaw);
                    models.place("office.keyboard_mouse", manager, x, 0.384f, z + 0.14f, yaw);
                } else {
                    models.place("office.laptop", manager, x, 0.384f, z, yaw);
                }
            }
        }

        // AI laboratory: desks 7-10 are bought into fixed slots here; the lab starts with a lounge corner.
        models.place("office.shelf", manager, 15.25f, 0f, 1.3f, 0f);
        models.place("office.plant", manager, 14.9f, 0f, 5.2f, 0f);
        models.place("office.sofa", manager, 9.6f, 0f, 5.3f, 180f);
        models.place("office.lamp", manager, 8.7f, 0f, 5.3f, 0f);

        // Break and meeting corner at the open side of the office wing (below the desk rows).
        models.place("office.meeting_table", manager, 5.45f, 0f, 5.2f, 0f);
        models.place("office.chair", manager, 4.85f, 0f, 5.65f, 0f);
        models.place("office.chair", manager, 6.05f, 0f, 5.65f, 0f);
        models.place("office.coffee_machine", manager, 5.45f, 0.327f, 5.2f, 0f);
        models.place("office.sofa", manager, 7.2f, 0f, 5.4f, 180f);
        models.place("office.plant", manager, 0.65f, 0f, 5.15f, 0f);
        models.place("office.trash_bin", manager, 2.0f, 0f, 5.4f, 0f);
        models.place("office.box", manager, 7.1f, 0f, 2.1f, 0f);

        // Data centre wing (x 0-8, z 6-12): one cabinet per purchased rack (1-4).
        // Cabinets are scaled to 0.62 so they stay below the 1.29-high walls.
        int racks = Math.max(1, Math.min(4, rackCabinets));
        for (int i = 0; i < racks; i++) {
            models.placeScaled("server.rack", manager, 1.5f + i, 0f, 7.3f, 0f, 0.62f, 0.62f, 0.62f);
        }
        models.place("server.router", manager, 1.5f + (racks - 1), 1.24f, 7.3f, 0f);
        // One outdoor cooling unit per purchased cooling unit (1-4), stacked along the right wall.
        int coolers = Math.max(1, Math.min(4, coolingUnits));
        for (int i = 0; i < coolers; i++) {
            models.placeScaled("server.outdoor_unit", manager, 6.9f, 0f, 7.3f + 1.2f * i, 0f, 0.6f, 0.6f, 0.6f);
        }
        models.place("server.generator", manager, 4.6f, 0f, 10.9f, 0f);
        models.place("office.shelf", manager, 1.2f, 0f, 10.4f, 90f);
        models.place("office.box", manager, 3.0f, 0f, 10.0f, 0f);

        // Production and logistics wing (x 8-16, z 6-12): conveyor tiles grow with purchased lines,
        // shelves/containers/crane with purchased warehouses.
        int lines = Math.max(1, Math.min(2, productionLines));
        for (int i = 0; i < lines * 2; i++) {
            models.place("factory.conveyor", manager, 10.8f + i, 0f, 8.8f, 90f);
        }
        int stores = Math.max(1, Math.min(2, warehouses));
        models.place("factory.warehouse_shelf", manager, 12.5f, 0f, 11.3f, 0f);
        models.place("factory.container", manager, 14.6f, 0f, 10.0f, 90f);
        if (stores >= 2) {
            models.place("factory.warehouse_shelf", manager, 10.5f, 0f, 11.3f, 0f);
            models.place("factory.container", manager, 14.6f, 0f, 11.4f, 90f);
            models.place("factory.crane", manager, 15.1f, 0f, 8.0f, 0f);
        }
        models.place("office.box", manager, 9.0f, 0f, 10.0f, 0f);

        // A few office-kit plants soften the hard edge of the campus while keeping draw calls bounded.
        models.place("office.plant", manager, 0.8f, 0f, 0.7f, 0f);
        models.place("office.plant", manager, 15.1f, 0f, 0.7f, 0f);
        return floors;
    }
}
