package aict.core;

import net.mgsx.gltf.scene3d.scene.SceneManager;

/** Places the supplied Quaternius nature models around the company's open-cutaway campus. */
public final class NatureCampusLayout {
    private NatureCampusLayout() { }

    public static int build(ModelLibrary models, SceneManager manager) {
        int placed = 0;

        // The back and side tree line frames the campus without hiding the four working wings.
        placed += place(models, manager, "nature.tree_1", -4.4f, -2.6f, 12f);
        placed += place(models, manager, "nature.tree_2", 0.2f, -4.3f, -12f);
        placed += place(models, manager, "nature.tree_3", 4.6f, -4.5f, 18f);
        placed += place(models, manager, "nature.pine_1", 14.8f, -3.7f, 22f);
        placed += place(models, manager, "nature.tree_2", 19.2f, -1.8f, 5f);
        placed += place(models, manager, "nature.tree_3", 21.0f, 4.2f, -15f);
        placed += place(models, manager, "nature.pine_2", 21.0f, 9.4f, 16f);
        placed += place(models, manager, "nature.tree_1", 19.0f, 15.2f, 8f);
        placed += place(models, manager, "nature.tree_2", 8.7f, 18.8f, 15f);
        placed += place(models, manager, "nature.tree_3", 2.5f, 18.2f, -8f);
        placed += place(models, manager, "nature.pine_1", -2.8f, 16.5f, 12f);
        placed += place(models, manager, "nature.tree_1", -4.8f, 10.5f, -12f);
        placed += place(models, manager, "nature.tree_2", -4.8f, 4.4f, 14f);

        // Bush belts and flower beds soften the campus edges and the entrance road.
        float[][] bushes = {
                {-3.4f, -0.4f}, {2.5f, -3.0f}, {7.0f, -3.1f}, {12.0f, -2.7f}, {17.0f, -1.7f},
                {19.6f, 2.3f}, {19.7f, 7.1f}, {18.2f, 13.7f}, {12.8f, 16.6f}, {6.3f, 16.6f},
                {-3.3f, 12.8f}, {-3.5f, 7.5f}
        };
        for (int i = 0; i < bushes.length; i++) {
            placed += place(models, manager, i % 3 == 0 ? "nature.bush_flowers" : "nature.bush",
                    bushes[i][0], bushes[i][1], (i * 37) % 360);
        }

        float[][] flowers = {
                {-1.7f, 5.8f}, {-1.5f, 9.2f}, {1.5f, 14.6f},
                {5.0f, 15.1f}, {10.0f, 15.3f}, {15.9f, 13.8f}, {17.4f, 4.8f}, {12.8f, -2.2f}
        };
        for (int i = 0; i < flowers.length; i++) {
            placed += place(models, manager, (i & 1) == 0 ? "nature.flower_3" : "nature.flower_4",
                    flowers[i][0], flowers[i][1], (i * 29) % 360);
        }

        // Low plants, ferns and grass fill the open patches; draw count is kept modest for phones.
        float[][] grass = {
                {-2.4f, 1.2f}, {-2.2f, 11.3f}, {0.0f, 15.6f},
                {4.1f, 16.2f}, {8.0f, 16.1f}, {12.2f, 15.8f}, {16.8f, 11.3f}, {17.0f, 2.5f}
        };
        for (int i = 0; i < grass.length; i++) {
            placed += place(models, manager, (i % 3 == 0) ? "nature.grass_tall" : "nature.grass_short",
                    grass[i][0], grass[i][1], (i * 41) % 360);
        }
        placed += place(models, manager, "nature.plant_1", -2.0f, 4.7f, 15f);
        placed += place(models, manager, "nature.plant_1", -2.0f, 10.1f, 65f);
        placed += place(models, manager, "nature.plant_7", 15.8f, 15.1f, -25f);
        placed += place(models, manager, "nature.fern", -2.2f, 6.2f, 10f);

        // Rock clusters mark the natural boundary and frame the small water garden.
        placed += place(models, manager, "nature.rock_1", -6.0f, 3.0f, 22f);
        placed += place(models, manager, "nature.rock_2", -5.5f, 5.5f, -12f);
        placed += place(models, manager, "nature.rock_3", -6.4f, 7.0f, 28f);
        placed += place(models, manager, "nature.rock_1", 18.3f, 15.7f, 12f);
        placed += place(models, manager, "nature.rock_2", 12.8f, 17.1f, 14f);

        // Pebbles, path stones and mushrooms add small-scale detail near the pond and garden beds.
        placed += place(models, manager, "nature.rock_path_round", -5.0f, 1.0f, 20f);
        placed += place(models, manager, "nature.pebble_1", -3.4f, 4.0f, 0f);
        placed += place(models, manager, "nature.pebble_2", -3.7f, 6.7f, 25f);
        placed += place(models, manager, "nature.pebble_1", 17.0f, 14.5f, 40f);
        placed += place(models, manager, "nature.mushroom", -4.2f, 4.2f, 0f);
        placed += place(models, manager, "nature.mushroom", 18.1f, 14.0f, 20f);

        return placed;
    }

    private static int place(ModelLibrary models, SceneManager manager, String key,
                             float x, float z, float yaw) {
        return models.place(key, manager, x, 0f, z, yaw) ? 1 : 0;
    }
}
