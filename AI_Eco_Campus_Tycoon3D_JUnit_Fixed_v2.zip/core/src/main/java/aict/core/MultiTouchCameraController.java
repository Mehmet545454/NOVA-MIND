package aict.core;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector3;
import java.util.HashMap;
import java.util.Map;

/** One finger pans; two fingers pinch to zoom and twist to rotate. */
public final class MultiTouchCameraController extends InputAdapter {
    private final OrthographicCamera camera;
    private final Map<Integer, Vector3> points = new HashMap<>();
    private float previousDistance;
    private float previousAngle;
    private float previousX, previousY;
    private float targetZoom;
    public MultiTouchCameraController(OrthographicCamera camera){this.camera=camera;this.targetZoom=camera.zoom;}
    @Override public boolean touchDown(int x,int y,int pointer,int button){
        points.put(pointer,new Vector3(x,y,0));
        if(points.size()==1){previousX=x;previousY=y;}
        if(points.size()==2){previousDistance=distance();previousAngle=angle();}
        return true;
    }
    @Override public boolean touchDragged(int x,int y,int pointer){
        Vector3 p=points.get(pointer);if(p==null)return false;p.set(x,y,0);
        if(points.size()==1){float scale=camera.zoom*0.012f;camera.position.add(-(x-previousX)*scale,0,(y-previousY)*scale);previousX=x;previousY=y;}
        else if(points.size()>=2){float d=distance();if(previousDistance>0&&d>0)targetZoom=clampZoom(targetZoom*previousDistance/d);float a=angle();float diff=a-previousAngle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;camera.rotate(Vector3.Y,(float)Math.toDegrees(diff)*0.65f);previousDistance=d;previousAngle=a;}
        camera.position.x=Math.max(-8,Math.min(29,camera.position.x));camera.position.z=Math.max(-8,Math.min(28,camera.position.z));camera.update();return true;
    }
    @Override public boolean touchUp(int x,int y,int pointer,int button){points.remove(pointer);if(points.size()==1){Vector3 remaining=points.values().iterator().next();previousX=remaining.x;previousY=remaining.y;}return true;}
    @Override public boolean scrolled(float amountX,float amountY){targetZoom=clampZoom(targetZoom*(1f+amountY*0.08f));return true;}
    /** Smooths zoom changes without adding inertial movement to deliberate camera drags. */
    public void update(float delta){
        float t=1f-(float)Math.exp(-16f*Math.min(Math.max(delta,0f),0.05f));
        camera.zoom+=(targetZoom-camera.zoom)*t;
        if(Math.abs(targetZoom-camera.zoom)<0.001f)camera.zoom=targetZoom;
        camera.update();
    }
    public void setTargetZoom(float zoom){targetZoom=clampZoom(zoom);}
    private float clampZoom(float zoom){return Math.max(0.55f,Math.min(2.4f,zoom));}
    private float distance(){var it=points.values().iterator();Vector3 a=it.next(),b=it.next();return a.dst(b);}
    private float angle(){var it=points.values().iterator();Vector3 a=it.next(),b=it.next();return (float)Math.atan2(b.y-a.y,b.x-a.x);}
}
