package aict.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import java.util.ArrayList;
import java.util.List;

/** A short illustrated story intro that leads into the playable campus. */
public final class IntroScreen extends ScreenAdapter {
    private static final float W=1000f, H=1800f, DURATION=15.4f;
    private final AictGame game;
    private final OrthographicCamera camera=new OrthographicCamera();
    private final Viewport viewport=new FitViewport(W,H,camera);
    private final ShapeRenderer shapes=new ShapeRenderer();
    private final SpriteBatch batch=new SpriteBatch();
    private final BitmapFont font=createFont();
    private final GlyphLayout glyph=new GlyphLayout();
    private final List<TextItem> textQueue=new ArrayList<>();
    private float time=0f;
    private boolean launched=false;

    private static BitmapFont createFont(){
        FreeTypeFontGenerator gen=new FreeTypeFontGenerator(Gdx.files.internal("fonts/DejaVuSans.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter p=new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size=32; p.characters=FreeTypeFontGenerator.DEFAULT_CHARS+"ğĞüÜşŞıİöÖçÇ₺";
        p.minFilter=com.badlogic.gdx.graphics.Texture.TextureFilter.Linear; p.magFilter=com.badlogic.gdx.graphics.Texture.TextureFilter.Linear;
        BitmapFont f=gen.generateFont(p); gen.dispose(); return f;
    }
    public IntroScreen(AictGame game) {
        this.game = game;
        font.getData().setScale(2.0f);
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override public boolean touchDown(int x, int y, int pointer, int button) {
                launch();
                return true;
            }
        });
    }

    @Override public void render(float delta){
        if(launched)return;
        time+=Math.min(delta,0.05f);
        if(time>=DURATION){launch();return;}
        Gdx.gl.glEnable(GL20.GL_BLEND); Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glClearColor(0.035f,0.055f,0.09f,1f); Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT|GL20.GL_DEPTH_BUFFER_BIT);
        float progress = smooth(time / DURATION);
        camera.position.set(W * 0.5f + (float)Math.sin(time * 0.22f) * 4f,
                H * 0.5f + (float)Math.cos(time * 0.18f) * 3f, 0f);
        camera.zoom = 1.02f - 0.055f * progress;
        camera.update();
        viewport.apply();
        shapes.setProjectionMatrix(camera.combined);
        batch.setProjectionMatrix(camera.combined);
        textQueue.clear();
        drawBackdrop(); drawDeskAndMan(); drawLaptop(); drawStoryCards(); drawIdea(); drawVignette();
        float fade = smooth((time - 13.35f) / 1.15f);
        if(fade>0){shapes.begin(ShapeRenderer.ShapeType.Filled); shapes.setColor(0.015f,0.025f,0.045f,fade); shapes.rect(0,0,W,H); shapes.end();}
        drawBrand();
        drawSkipPrompt();
        flushText();
    }
    private void drawBackdrop(){
        float windowGlow = 0.07f + 0.025f * (float)Math.sin(time * 1.7f);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(new Color(0.055f,0.09f,0.15f,1)); shapes.rect(0,0,W,H);
        shapes.setColor(new Color(0.08f,0.14f,0.21f,1)); shapes.rect(0,0,W,620);
        shapes.setColor(new Color(0.10f,0.19f,0.25f,1)); shapes.rect(70,760,860,650);
        shapes.setColor(new Color(0.14f,0.27f,0.34f,1)); shapes.rect(105,795,790,580);
        // Window and rainy night skyline
        shapes.setColor(new Color(0.07f,0.12f,0.20f,1)); shapes.rect(130,1060,740,280);
        shapes.setColor(1f,0.70f,0.37f,windowGlow); shapes.circle(735,1110,150);
        for(int i=0;i<8;i++){
            float x=150+i*92;
            shapes.setColor(new Color(0.10f,0.18f,0.27f,1)); shapes.rect(x,1060,55,80+(i%3)*45);
            if(i%2==0){shapes.setColor(1f,0.68f,0.33f,0.30f); shapes.rect(x+13,1110+(i%3)*24,8,10);}
        }
        // Fine rain streaks move across the glass while the skyline stays still.
        for(int i=0;i<34;i++){
            float x=130f+((i*97f+time*(95f+(i%4)*19f))%740f);
            float y=1065f+((i*43f)%260f);
            shapes.setColor(0.57f,0.78f,0.88f,0.16f+(i%3)*0.035f);
            shapes.rect(x,y,2f,13f+(i%4)*3f);
        }
        shapes.setColor(new Color(0.20f,0.47f,0.55f,0.72f)); shapes.rect(485,1060,3,280);
        shapes.setColor(new Color(0.20f,0.47f,0.55f,0.72f)); shapes.rect(130,1198,740,3);
        shapes.setColor(0.66f,0.86f,0.89f,0.22f); shapes.rect(130,1337,740,3);
        // desk
        shapes.setColor(new Color(0.34f,0.22f,0.17f,1)); shapes.rect(0,470,W,46);
        shapes.setColor(new Color(0.64f,0.43f,0.29f,1)); shapes.rect(0,510,W,5);
        shapes.setColor(new Color(0.20f,0.14f,0.12f,1)); shapes.rect(120,0,42,470); shapes.rect(840,0,42,470);
        shapes.end();
        float captionAlpha=smooth(time/0.7f);
        drawText("03:17  /  KÜÇÜK BİR OFİS",80,1685,new Color(0.58f,0.76f,0.82f,captionAlpha),1.1f);
    }
    private void drawDeskAndMan(){
        float bob=2.5f*(float)Math.sin(time*2.3f);
        float frustration=smooth((time-5.25f)/0.42f)*(1f-smooth((time-7.85f)/0.5f));
        float typing=(1f-frustration)*2.8f*(float)Math.sin(time*13f);
        float handY=590f+bob+typing+frustration*535f;
        float leftHandX=390f-frustration*34f;
        float rightHandX=610f+frustration*34f;
        float blinkPhase=time%4.2f;
        float eyeHeight=(blinkPhase>3.58f&&blinkPhase<3.78f)?3f:10f;
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // chair
        shapes.setColor(new Color(0.10f,0.18f,0.24f,1)); shapes.rect(285,420,300,500); shapes.circle(435,420,150);
        // torso / hoodie
        shapes.setColor(new Color(0.13f,0.42f,0.48f,1)); shapes.rect(350,540+bob,300,430); shapes.triangle(350,970+bob,650,970+bob,500,1110+bob);
        // neck and face
        shapes.setColor(new Color(0.78f,0.53f,0.38f,1)); shapes.rect(450,1000+bob,100,105); shapes.circle(500,1170+bob,145);
        // Arms move from typing to a brief face-palm as the failed replies stack up.
        shapes.setColor(new Color(0.13f,0.42f,0.48f,1));
        shapes.rectLine(365,650+bob, leftHandX,handY,54f);
        shapes.rectLine(635,650+bob, rightHandX,handY,54f);
        // hair
        shapes.setColor(new Color(0.10f,0.085f,0.08f,1)); shapes.arc(500,1190+bob,147,0,180,30); shapes.rect(365,1190+bob,270,90);
        // ears
        shapes.setColor(new Color(0.78f,0.53f,0.38f,1)); shapes.circle(355,1150+bob,30); shapes.circle(645,1150+bob,30);
        // eyes + brows
        shapes.setColor(new Color(0.10f,0.08f,0.07f,1)); shapes.rect(425,1170+bob,38,eyeHeight); shapes.rect(535,1170+bob,38,eyeHeight);
        shapes.rect(420,1200+bob,50,9); shapes.rect(530,1200+bob,50,9);
        // Expression shifts from focused to frustrated, then relaxes at the idea moment.
        shapes.setColor(new Color(0.35f,0.12f,0.11f,1));
        if(frustration>0.08f) shapes.arc(500,1095+bob,36,190,160,20); else shapes.rect(480,1090+bob,40,7);
        // Hands land on the keyboard while typing, then rise toward the temples.
        shapes.setColor(new Color(0.78f,0.53f,0.38f,1));
        shapes.circle(leftHandX,handY,43f); shapes.circle(rightHandX,handY,43f);
        shapes.end();
    }
    private void drawLaptop(){
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(new Color(0.16f,0.19f,0.23f,1)); shapes.rect(250,520,500,300);
        shapes.setColor(new Color(0.025f,0.055f,0.08f,1)); shapes.rect(270,540,460,260);
        shapes.setColor(new Color(0.42f,0.80f,0.82f,0.8f)); shapes.rect(470,540,60,5);
        shapes.setColor(new Color(0.55f,0.59f,0.62f,1)); shapes.triangle(205,500,795,500,740,525);
        shapes.setColor(new Color(0.23f,0.27f,0.30f,1)); shapes.rect(205,490,590,20);
        shapes.setColor(new Color(0.38f,0.46f,0.49f,1)); shapes.rect(284,555,432,1.5f);
        shapes.end();
        drawText("AI ASİSTAN",305,770,new Color(0.48f,0.88f,0.85f,1),1.1f);
        drawText("YENİ SOHBET  •  03:17",305,741,new Color(0.52f,0.63f,0.69f,1),0.58f);
        drawText("> "+typed("Bana çalışan bir iş modeli oluştur.",0.55f,1.75f),
                305,700,Color.WHITE,0.76f);
        if(time<2.6f){
            float cursorAlpha=time%0.8f<0.42f?1f:0.18f;
            float cursorX=305f+glyphWidth("> "+typed("Bana çalışan bir iş modeli oluştur.",0.55f,1.75f),0.76f);
            drawText("▍",cursorX,700,new Color(0.48f,0.88f,0.85f,cursorAlpha),0.76f);
        }
        if(time>3.0f) drawText("AI-1  "+typed("İsteğini tam anlayamadım.",3.0f,0.55f),
                305,660,new Color(1f,0.72f,0.55f,smooth((time-2.9f)/0.18f)),0.67f);
        if(time>4.0f) drawText("AI-2  "+typed("Bu sonucu garanti edemem.",4.0f,0.55f),
                305,625,new Color(1f,0.66f,0.49f,smooth((time-3.9f)/0.18f)),0.64f);
        if(time>5.0f) drawText("AI-3  "+typed("Daha açık bir istek yazar mısın?",5.0f,0.65f),
                305,590,new Color(1f,0.57f,0.46f,smooth((time-4.9f)/0.18f)),0.58f);
        drawAssistantStatus();
    }
    private void drawStoryCards(){
        float failureAlpha=fadeBetween(2.45f,6.55f,0.30f);
        if(failureAlpha>0f){
            float lift=24f*(1f-smooth((time-2.45f)/0.32f));
            card(85,1430+lift,830,150,new Color(0.13f,0.22f,0.30f,failureAlpha));
            drawText("YANIT 01  /  İŞE YARAMADI",125,1530+lift,
                    new Color(1f,0.72f,0.57f,failureAlpha),0.88f);
            drawText("İstediğim sonucu üretemedi...",125,1470+lift,
                    new Color(0.91f,0.94f,0.95f,failureAlpha),1.05f);
        }
        float balanceAlpha=fadeBetween(7.65f,10.35f,0.28f);
        if(balanceAlpha>0f){
            float lift=22f*(1f-smooth((time-7.65f)/0.30f));
            int balance=Math.round(2450f*smooth((time-7.85f)/0.90f));
            card(130,1320+lift,740,260,new Color(0.08f,0.13f,0.19f,balanceAlpha));
            drawText("HESAP BAKİYESİ",190,1510+lift,
                    new Color(0.68f,0.78f,0.82f,balanceAlpha),0.92f);
            drawText("₺ "+balance,190,1415+lift,
                    new Color(1f,0.78f,0.38f,balanceAlpha),1.85f);
            drawText("Bu parayla ne yapabilirim?",190,1355+lift,
                    new Color(0.94f,0.96f,0.97f,balanceAlpha),0.84f);
        }
        float ideaAlpha=fadeBetween(10.25f,13.35f,0.32f);
        if(ideaAlpha>0f){
            float lift=20f*(1f-smooth((time-10.25f)/0.34f));
            card(120,1360+lift,760,210,new Color(0.08f,0.23f,0.25f,ideaAlpha));
            drawText("BİR DAKİKA...",175,1500+lift,
                    new Color(0.47f,0.94f,0.79f,ideaAlpha),1.12f);
            drawText("Kendi AI şirketimi kurabilirim!",175,1425+lift,
                    new Color(0.97f,0.99f,0.98f,ideaAlpha),1.0f);
        }
    }
    private void drawIdea(){
        if(time<10.0f)return;
        float p=smooth((time-10f)/0.72f);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        float pulse=0.82f+0.18f*(float)Math.sin(time*3.2f);
        shapes.setColor(1f,0.68f,0.22f,0.07f*p); shapes.circle(790,1120,142f*pulse);
        shapes.setColor(1f,0.78f,0.28f,0.12f*p); shapes.circle(790,1120,101f*pulse);
        for(int i=0;i<8;i++){
            float angle=time*0.35f+i*(float)Math.PI/4f;
            float x=790f+(float)Math.cos(angle)*88f;
            float y=1120f+(float)Math.sin(angle)*88f;
            shapes.setColor(1f,0.86f,0.43f,(0.35f+0.35f*(float)Math.sin(time*4f+i))*p);
            shapes.circle(x,y,2.5f+1.8f*(float)Math.sin(time*3f+i));
        }
        shapes.setColor(1f,0.84f,0.35f,p); shapes.circle(790,1120,48f*p);
        shapes.setColor(1f,0.96f,0.69f,p); shapes.circle(778,1134,13f*p);
        shapes.setColor(0.98f,0.72f,0.25f,p); shapes.rect(770,1060,40,38f*p);
        shapes.setColor(0.98f,0.72f,0.25f,p); shapes.rect(777,1045,26,12f*p);
        shapes.end();
        drawText("✦",760,1140,new Color(1f,1f,0.9f,p),1.3f);
    }
    private void drawVignette(){
        float alpha=fadeBetween(10.3f,13.55f,0.35f);
        if(alpha>0f) drawCentered("HER ŞEY BİR FİKİRLE BAŞLAR",260,
                new Color(0.75f,0.84f,0.87f,0.78f*alpha),0.92f);
    }
    private void drawAssistantStatus(){
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        for(int i=0;i<3;i++){
            float glow=0.36f+0.64f*(0.5f+0.5f*(float)Math.sin(time*5f-i*1.6f));
            shapes.setColor(0.35f,0.78f,0.76f,glow);
            shapes.circle(675f+i*16f,575f,2.4f+glow);
        }
        shapes.end();
    }

    private void drawBrand(){
        float alpha=smooth((time-14.1f)/0.7f);
        if(alpha<=0f)return;
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.31f,0.83f,0.76f,0.8f*alpha);
        shapes.rect(390f,1000f,220f,4f);
        shapes.end();
        drawCentered("AI ECO CAMPUS TYCOON",955f,new Color(0.40f,0.91f,0.83f,alpha),1.8f);
        drawCentered("BİR FİKİR. KENDİ ŞİRKETİN. KENDİ KAMPÜSÜN.",
                875f,new Color(0.77f,0.85f,0.88f,alpha),0.58f);
    }

    private void drawSkipPrompt(){
        float alpha=(1f-smooth((time-13.2f)/0.4f))*smooth((time-0.75f)/0.45f);
        if(alpha<=0f)return;
        float pulse=0.76f+0.24f*(float)Math.sin(time*3.5f);
        drawCentered("DOKUN  •  GEÇ",78f,
                new Color(0.78f,0.87f,0.9f,alpha*pulse),0.62f);
    }

    private void card(float x,float y,float w,float h,Color c){
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0f,0.025f,0.05f,0.28f*c.a); shapes.rect(x+8f,y-10f,w,h);
        shapes.setColor(c); shapes.rect(x,y,w,h);
        shapes.setColor(0.36f,0.82f,0.78f,c.a); shapes.rect(x,y+h-5f,w,5f);
        shapes.end();
    }

    private float smooth(float value){
        float t=Math.max(0f,Math.min(1f,value));
        return t*t*(3f-2f*t);
    }
    private float fadeBetween(float start,float end,float duration){
        return smooth((time-start)/duration)*smooth((end-time)/duration);
    }
    private String typed(String text,float start,float duration){
        int count=Math.min(text.length(),Math.round(text.length()*smooth((time-start)/duration)));
        return text.substring(0,count);
    }
    private float glyphWidth(String text,float scale){
        font.getData().setScale(scale);
        glyph.setText(font,text);
        return glyph.width;
    }
    private void drawText(String s,float x,float y,Color c,float scale){
        if(s!=null&&!s.isEmpty())textQueue.add(new TextItem(s,x,y,new Color(c),scale));
    }
    private void drawCentered(String s,float y,Color c,float scale){font.getData().setScale(scale);glyph.setText(font,s);drawText(s,(W-glyph.width)/2f,y,c,scale);}
    private void flushText(){
        if(textQueue.isEmpty())return;
        batch.begin();
        for(TextItem item:textQueue){
            font.getData().setScale(item.scale);
            font.setColor(item.color);
            font.draw(batch,item.text,item.x,item.y);
        }
        batch.end();
        textQueue.clear();
    }
    private static final class TextItem {
        final String text;
        final float x,y,scale;
        final Color color;
        TextItem(String text,float x,float y,Color color,float scale){
            this.text=text;this.x=x;this.y=y;this.color=color;this.scale=scale;
        }
    }
    private void launch(){if(launched)return;launched=true;game.setScreen(new OfficeScreen(game));dispose();}
    @Override public void resize(int width,int height){viewport.update(width,height,true);}
    @Override public void dispose(){shapes.dispose();batch.dispose();font.dispose();}
}
