package aict.core;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import aict.sim.HardwareItem;
import aict.sim.Simulation;
import aict.sim.SaveManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.List;

public final class AictGame extends Game {
    private Simulation simulation;
    private final SaveManager saveManager = new SaveManager();
    private Path savePath;
    private int speedBeforePause = 1;

    @Override public void create() {
        Gdx.graphics.setForegroundFPS(60);
        savePath = Gdx.files.local("saves/autosave.json").file().toPath();
        try { simulation = saveManager.load(savePath); }
        catch (IOException ignored) { simulation = new Simulation(); }
        simulation.ensureStarterOffice();
        loadCatalog();
        setScreen(new IntroScreen(this));
    }
    private void loadCatalog() {
        String[] files={"cpu.json","gpu.json","ram.json","storage.json","motherboard.json","psu.json","cooling.json","case.json","monitor.json","peripherals.json","network.json","server_systems.json","datacenter_facility.json"};
        Gson gson=new Gson(); Type type=new TypeToken<List<HardwareItem>>(){}.getType();
        for(String file:files) {
            try {
                String path="hardware/"+file;
                if(!Gdx.files.internal(path).exists())continue;
                List<HardwareItem> loaded=gson.fromJson(Gdx.files.internal(path).readString("UTF-8"),type);
                if(loaded!=null)for(HardwareItem item:loaded)simulation.getCatalog().add(item);
            } catch(RuntimeException ex) { Gdx.app.error("Catalog","Katalog dosyası yüklenemedi: "+file,ex); }
        }
    }
    public Simulation simulation(){return simulation;}
    public void saveSlot(int slot){if(slot<1||slot>3){simulation.setLastNotice("Kayıt yuvası 1-3 arasında olmalı.");return;}try{saveManager.save(Gdx.files.local("saves/slot"+slot+".json").file().toPath(),simulation);simulation.setLastNotice("Kayıt yuvası "+slot+" kaydedildi.");}catch(IOException ex){simulation.setLastNotice("Yuva kaydı başarısız: "+ex.getMessage());}}
    public void loadSlot(int slot) {
        if (slot < 1 || slot > 3) return;
        try {
            simulation = saveManager.load(Gdx.files.local("saves/slot" + slot + ".json").file().toPath());
            loadCatalog();
            com.badlogic.gdx.Screen previous = getScreen();
            setScreen(new OfficeScreen(this));
            if (previous != null) previous.dispose();
        } catch (IOException ex) {
            simulation.setLastNotice("Kayıt yuvası yüklenemedi: " + ex.getMessage());
        }
    }

    public void saveGame() {
        try { saveManager.save(savePath,simulation); }
        catch(IOException ex){Gdx.app.error("Save","Kayıt başarısız",ex);simulation.setLastNotice("Kayıt başarısız: "+ex.getMessage());}
    }
    @Override public void pause(){if(simulation!=null){speedBeforePause=simulation.getClock().getSpeed();simulation.pause();saveGame();}super.pause();}
    @Override public void resume(){if(simulation!=null)simulation.setSpeed(speedBeforePause);super.resume();}
    @Override public void dispose(){saveGame();super.dispose();}
}
