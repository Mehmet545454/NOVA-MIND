package aict.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;
import java.util.ArrayList;
import java.util.List;

/** One restrained UI theme; visual panels use real NinePatch textures. */
public final class Theme implements Disposable {
    private final Skin skin = new Skin();
    private final List<Texture> textures = new ArrayList<>();
    private BitmapFont font;
    private final JsonValue config;

    public Theme() {
        config = new JsonReader().parse(Gdx.files.internal("ui/uiskin.json"));
        JsonValue palette = config.get("palette");
        font = loadFont(config.getString("font", "fonts/NotoSans-Regular.ttf"));
        skin.add("default-font", font);
        skin.add("default", new Label.LabelStyle(font, Color.valueOf(palette.getString("text", "E8ECEB"))));

        NinePatchDrawable panel = patch(config.getString("panel", "ui/panel.png"));
        NinePatchDrawable up = patch(config.getString("buttonUp", "ui/button_up.png"));
        NinePatchDrawable over = patch(config.getString("buttonOver", "ui/button_over.png"));
        NinePatchDrawable down = patch(config.getString("buttonDown", "ui/button_down.png"));

        TextButton.TextButtonStyle button = new TextButton.TextButtonStyle();
        button.font = font;
        button.fontColor = Color.valueOf(palette.getString("buttonText", "F0F3F1"));
        button.overFontColor = Color.WHITE;
        button.downFontColor = Color.valueOf(palette.getString("buttonDownText", "D9F4E5"));
        button.up = up; button.over = over; button.down = down;
        skin.add("default", button);

        Window.WindowStyle window = new Window.WindowStyle();
        window.titleFont = font;
        window.titleFontColor = Color.valueOf(palette.getString("title", "F2F5F3"));
        window.background = panel;
        skin.add("default", window);

        ScrollPane.ScrollPaneStyle scroll = new ScrollPane.ScrollPaneStyle();
        scroll.background = panel;
        scroll.vScroll = up;
        scroll.vScrollKnob = down;
        skin.add("default", scroll);
    }

    private BitmapFont loadFont(String configuredFont) {
        FileHandle fontFile = Gdx.files.internal(configuredFont);
        if (!fontFile.exists() && Gdx.app.getType() == Application.ApplicationType.Android) {
            FileHandle androidFont = Gdx.files.absolute("/system/fonts/Roboto-Regular.ttf");
            if (androidFont.exists()) fontFile = androidFont;
        }
        if (fontFile.exists()) {
            FreeTypeFontGenerator generator = null;
            try {
                generator = new FreeTypeFontGenerator(fontFile);
                FreeTypeFontGenerator.FreeTypeFontParameter p = new FreeTypeFontGenerator.FreeTypeFontParameter();
                p.size = Math.max(16, Math.round(16f * Gdx.graphics.getDensity()));
                p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + "ğĞüÜşŞıİöÖçÇ₺";
                p.color = Color.valueOf("E8ECEB");
                p.minFilter = Texture.TextureFilter.Linear;
                p.magFilter = Texture.TextureFilter.Linear;
                return generator.generateFont(p);
            } catch (RuntimeException ex) {
                Gdx.app.error("Theme", "OFL/system font yüklenemedi; yerleşik font kullanılacak.", ex);
            } finally {
                if (generator != null) generator.dispose();
            }
        }
        return new BitmapFont();
    }

    private NinePatchDrawable patch(String path) {
        Texture texture = new Texture(Gdx.files.internal(path));
        texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        textures.add(texture);
        return new NinePatchDrawable(new NinePatch(texture, 18, 18, 18, 18));
    }

    public Skin skin() { return skin; }

    @Override public void dispose() {
        skin.dispose();
        for (Texture texture : textures) texture.dispose();
        textures.clear();
    }
}
