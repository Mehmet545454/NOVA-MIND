# AI Eco Campus Tycoon 3D

Android ve masaüstü için Java 17 + libGDX yönetim oyunu. Bu paket kaynak kodu ve oyunun şu an kullandığı varlıkları içerir; APK içermez.

## Derleme

```sh
gradle :sim:test
gradle :android:assembleDebug
```

Kurulum adımları `docs/YUKLEME.md` içinde. Oyun verisi ve formüller için `docs/` klasöründeki kısa teknik notlara bakın.

## İçerik

- 31 ana GLB ve sahnede kullanılan 21 çevre modeli
- Arayüz dokuları, fontlar, oyun verileri ve model lisans/atıfları
- Açılış sinematiği, kampüs ve dokunmatik yönetim ekranları

Kullanılmayan ek model katalogları paketten çıkarıldı. Oyunda kullanılan model dosyaları ve lisans bilgileri korunmuştur.
