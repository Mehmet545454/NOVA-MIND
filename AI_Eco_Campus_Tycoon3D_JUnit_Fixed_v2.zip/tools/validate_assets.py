#!/usr/bin/env python3
"""Validate manifest-backed GLB files and report intentionally missing assets."""
from pathlib import Path
import json
import struct
import sys
import base64

ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / 'assets'
manifest_path = ASSET_ROOT / 'models/runtime_manifest.json'
credits_path = ASSET_ROOT / 'CREDITS.md'
errors, warnings = [], []


def image_dimensions(data: bytes):
    """Read dimensions for embedded PNG/JPEG images without an imaging dependency."""
    if data.startswith(b'\x89PNG\r\n\x1a\n') and len(data) >= 24:
        return struct.unpack_from('>II', data, 16)
    if data.startswith(b'\xff\xd8'):
        offset = 2
        while offset + 4 <= len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
                continue
            if offset + 2 > len(data):
                break
            length = struct.unpack_from('>H', data, offset)[0]
            if length < 2 or offset + length > len(data):
                break
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                if length < 7:
                    break
                height, width = struct.unpack_from('>HH', data, offset + 3)
                return width, height
            offset += length
    raise ValueError('Gömülü doku PNG/JPEG değil veya boyutları okunamadı')


def read_glb(path: Path):
    raw = path.read_bytes()
    if len(raw) < 20 or raw[:4] != b'glTF':
        raise ValueError('GLB başlığı geçersiz')
    version, declared_length = struct.unpack_from('<II', raw, 4)
    if version != 2 or declared_length != len(raw):
        raise ValueError('GLB sürümü/uzunluğu geçersiz')
    offset = 12
    document = None
    binary_chunk = b''
    while offset < len(raw):
        if offset + 8 > len(raw):
            raise ValueError('GLB chunk başlığı kesilmiş')
        chunk_length, chunk_type = struct.unpack_from('<I4s', raw, offset)
        offset += 8
        end = offset + chunk_length
        if end > len(raw):
            raise ValueError('GLB chunk uzunluğu dosyayı aşıyor')
        chunk = raw[offset:end]
        offset = end
        if chunk_type == b'JSON':
            document = json.loads(chunk.decode('utf-8').rstrip('\x00 \t\r\n'))
        elif chunk_type == b'BIN\x00':
            binary_chunk = chunk
    if document is None:
        raise ValueError('GLB JSON chunk bulunamadı')

    triangles = 0
    for mesh in document.get('meshes', []):
        for primitive in mesh.get('primitives', []):
            mode = primitive.get('mode', 4)
            if mode not in (4, 5, 6):
                continue
            if 'indices' in primitive:
                count = document['accessors'][primitive['indices']]['count']
            else:
                count = document['accessors'][primitive['attributes']['POSITION']]['count']
            triangles += count // 3 if mode == 4 else max(0, count - 2)

    external = []
    for item in document.get('buffers', []) + document.get('images', []):
        uri = item.get('uri')
        if uri and not uri.startswith('data:'):
            external.append(uri)

    image_sizes = []
    for image in document.get('images', []):
        uri = image.get('uri')
        if uri and uri.startswith('data:'):
            try:
                encoded = uri.split(',', 1)[1]
                image_bytes = base64.b64decode(encoded)
            except Exception as exc:
                raise ValueError(f'Gömülü doku data URI okunamadı: {exc}') from exc
        elif 'bufferView' in image:
            view = document.get('bufferViews', [])[image['bufferView']]
            start = int(view.get('byteOffset', 0))
            length = int(view['byteLength'])
            image_bytes = binary_chunk[start:start + length]
            if len(image_bytes) != length:
                raise ValueError('Gömülü doku bufferView dosya sınırını aşıyor')
        else:
            continue
        image_sizes.append(image_dimensions(image_bytes))
    return raw, document, triangles, external, image_sizes


# The UI theme is mandatory for startup; verify its JSON and all four 9-patch PNGs.
ui_config_path = ASSET_ROOT / 'ui/uiskin.json'
if not ui_config_path.is_file():
    errors.append('assets/ui/uiskin.json bulunamadı; Theme açılışta başarısız olur')
else:
    try:
        ui_config = json.loads(ui_config_path.read_text(encoding='utf-8'))
        for field in ('panel', 'buttonUp', 'buttonOver', 'buttonDown'):
            rel_ui = ui_config.get(field)
            ui_path = ASSET_ROOT / rel_ui if rel_ui else None
            if not ui_path or not ui_path.is_file():
                errors.append(f'UI {field} dokusu bulunamadı: {rel_ui}')
                continue
            png = ui_path.read_bytes()
            if len(png) < 24 or png[:8] != b'\x89PNG\r\n\x1a\n':
                errors.append(f'UI dokusu geçerli PNG değil: {rel_ui}')
            else:
                width, height = struct.unpack_from('>II', png, 16)
                if width < 37 or height < 37:
                    errors.append(f'UI 9-patch dokusu 37x37 altı: {rel_ui} ({width}x{height})')
        font_path = ASSET_ROOT / ui_config.get('font', 'fonts/NotoSans-Regular.ttf')
        font_license = ASSET_ROOT / 'fonts/OFL.txt'
        if not font_path.is_file():
            warnings.append('Türkçe OFL font dosyası yok; Android sistem fontu fallback olarak kullanılır')
        elif not font_license.is_file() or 'SIL OPEN FONT LICENSE' not in font_license.read_text(encoding='utf-8').upper():
            errors.append('Noto Sans fontu için SIL OFL lisans dosyası eksik/geçersiz')
    except Exception as exc:
        errors.append(f'UI tema JSON okunamadı: {exc}')

if not manifest_path.exists():
    errors.append('assets/models/runtime_manifest.json bulunamadı')
else:
    data = json.loads(manifest_path.read_text(encoding='utf-8'))
    entries = data.get('models', [])
    credits = credits_path.read_text(encoding='utf-8') if credits_path.exists() else ''
    keys = set()
    available = 0
    missing_count = 0
    total_bytes = 0
    manifested_files = set()

    for item in entries:
        key = item.get('key', '?')
        rel = item.get('file', '')
        status = item.get('status', 'missing')
        path = ASSET_ROOT / rel if rel else None
        if rel:
            manifested_files.add(Path(rel).as_posix())
        if key in keys:
            errors.append(f'{key}: manifest anahtarı yineleniyor')
        keys.add(key)

        if status != 'available':
            missing_count += 1
            warnings.append(f'MODEL EKSİK: {key} ({rel or "dosya yolu bekleniyor"})')
            continue
        available += 1
        if not path or not path.is_file():
            errors.append(f'{key}: available işaretli dosya bulunamadı: {rel}')
            continue
        if item.get('license') not in ('CC0', 'CC-BY'):
            errors.append(f'{key}: lisans CC0/CC-BY değil')
        if not item.get('source_url') or not item.get('author'):
            errors.append(f'{key}: source_url/author eksik')
        if item.get('verified') is not True:
            errors.append(f'{key}: verified=true değil')

        try:
            raw, gltf, triangles, external, image_sizes = read_glb(path)
        except Exception as exc:
            errors.append(f'{key}: GLB okunamadı: {exc}')
            continue

        total_bytes += len(raw)
        if len(raw) > 20 * 1024 * 1024:
            errors.append(f'{key}: 20 MB tek dosya sınırı aşıldı')
        if external:
            errors.append(f'{key}: GLB harici dosya URI içeriyor: {external}')
        for width, height in image_sizes:
            if width > 1024 or height > 1024:
                errors.append(f'{key}: doku {width}x{height}; 1024x1024 sınırı aşıldı')
        if item.get('tris') != triangles:
            errors.append(f'{key}: manifest tris={item.get("tris")} ancak GLB üçgen={triangles}')

        kind = item.get('kind', '')
        if key.startswith('character.') or kind == 'character':
            budget = 6000
        elif kind in ('building', 'structure') or key in ('office.floor', 'office.wall'):
            budget = 1500
        elif key.startswith(('server.', 'factory.', 'sector.')) or kind in ('machine', 'vehicle'):
            budget = 6000
        else:
            budget = 2500
        if triangles > budget:
            errors.append(f'{key}: {triangles} üçgen, mobil bütçe {budget} aşıldı')
        if key not in credits:
            errors.append(f'{key}: CREDITS.md içinde kayıt yok')

    if total_bytes > 120 * 1024 * 1024:
        errors.append('GLB toplamı 120 MB sınırını aştı')

    # Reject orphan GLBs that cannot be loaded and credited through the manifest.
    for glb in (ASSET_ROOT / 'models').rglob('*.glb'):
        relative = glb.relative_to(ASSET_ROOT).as_posix()
        if relative not in manifested_files:
            errors.append(f'Manifestte referansı olmayan GLB: {relative}')

    for message in warnings:
        print('UYARI: ' + message)
    for message in errors:
        print('HATA: ' + message)
    if not errors:
        print(f'Varlık kontrolü geçti: {available} GLB mevcut, {missing_count} model eksik, {total_bytes:,} bayt.')

assets_total = sum(file.stat().st_size for file in ASSET_ROOT.rglob('*') if file.is_file())
if assets_total > 120 * 1024 * 1024:
    errors.append(f'assets/ toplamı {assets_total:,} bayt; 120 MB sınırı aşıldı')

if errors:
    sys.exit(1)
print('Eksik dosyalar, şartname 30.8 kapsamındaki açık missing-model modunda raporlandı.')
