#!/usr/bin/env python3
"""Validate game JSON catalogs and required Stage 1 category minimums."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]; counts={}
required={'id','brand','family','model','category','tier','release_year','era','specs','game_price','price_is_game_value','power_w','warranty_months','lifespan_hours','compat','verified'}
seen=set()
for path in sorted((ROOT/'data').rglob('*.json')):
    try: value=json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{path.relative_to(ROOT)}: JSON parse hatası: {exc}'); continue
    if path.parent.name=='hardware':
        if not isinstance(value,list): errors.append(f'{path.name}: donanım kökü liste olmalı'); continue
        for item in value:
            missing=required-set(item)
            if missing: errors.append(f"{path.name}/{item.get('id','?')}: eksik alanlar {sorted(missing)}")
            ident=item.get('id')
            if ident in seen: errors.append(f'{ident}: yinelenen ürün kimliği')
            seen.add(ident)
            category=item.get('category','');counts[category]=counts.get(category,0)+1
            if not 1<=int(item.get('tier',0))<=11: errors.append(f'{ident}: tier 1-11 dışında')
            if item.get('game_price',-1)<0: errors.append(f'{ident}: negatif oyun fiyatı')
            if item.get('price_is_game_value') is not True: errors.append(f'{ident}: oyun fiyatı açıkça işaretlenmeli')
minimums={'cpu':15,'gpu':10,'ram':10,'storage':10,'motherboard':8,'psu':8,'cooling':6,'case':6,'monitor':8,'peripherals':8,'network':6}
for cat,minimum in minimums.items():
    if counts.get(cat,0)<minimum: errors.append(f'{cat}: {minimum} alt sınırının altında ({counts.get(cat,0)})')
for e in errors: print('HATA:',e)
print('Donanım kategori sayıları:',', '.join(f'{k}={v}' for k,v in sorted(counts.items())))
if errors: sys.exit(1)
print('Veri doğrulaması başarılı; verified:false satırlar gerçek teknik veri kabul edilmez.')
