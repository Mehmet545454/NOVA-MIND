#!/usr/bin/env python3
"""Validate the supplied Stylized Nature MegaKit glTF package and runtime scene list."""
from __future__ import annotations
import json
import re
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NATURE = ROOT / "assets/models/nature"
GLTF_DIR = NATURE / "glTF"
errors: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        errors.append(f"JSON okunamadı: {path.relative_to(ROOT)} ({exc})")
        return {}


manifest_path = NATURE / "scene_manifest.json"
manifest = read_json(manifest_path)
models = manifest.get("models", [])
runtime_gltfs = {
    (ROOT / "assets" / item.get("file", "")).resolve()
    for item in models if item.get("file", "").endswith(".gltf")
}
gltfs = {path.resolve() for path in GLTF_DIR.glob("*.gltf")}
check(gltfs == runtime_gltfs,
      f"Yalnızca sahne modelleri tutulmalı. Eksik: {sorted(str(p) for p in runtime_gltfs-gltfs)}, gereksiz: {sorted(str(p) for p in gltfs-runtime_gltfs)}")

referenced_bins: set[Path] = set()
referenced_pngs: set[Path] = set()
for gltf in sorted(runtime_gltfs):
    if not gltf.is_file():
        continue
    payload = read_json(gltf)
    for group in ("buffers", "images"):
        for item in payload.get(group, []):
            uri = item.get("uri")
            if not uri or uri.startswith("data:"):
                continue
            resolved = (gltf.parent / uri).resolve()
            check(resolved.is_file(), f"Eksik {group} URI: {gltf.name} -> {uri}")
            if resolved.suffix.lower() == ".bin":
                referenced_bins.add(resolved)
            elif resolved.suffix.lower() == ".png":
                referenced_pngs.add(resolved)

bins = {path.resolve() for path in GLTF_DIR.glob("*.bin")}
pngs = {path.resolve() for path in GLTF_DIR.glob("*.png")}
check(bins == referenced_bins, "Kullanılmayan veya eksik .bin dosyaları var")
check(pngs == referenced_pngs, "Kullanılmayan veya eksik PNG dokuları var")

for png in sorted(referenced_pngs):
    try:
        data = png.read_bytes()
        check(data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24,
              f"Geçerli PNG başlığı yok: {png.name}")
        if len(data) >= 24 and data.startswith(b"\x89PNG\r\n\x1a\n"):
            width, height = struct.unpack_from(">II", data, 16)
            check(width <= 1024 and height <= 1024,
                  f"Doku 1024 px sınırını aşıyor: {png.name} ({width}x{height})")
    except Exception as exc:  # noqa: BLE001
        errors.append(f"PNG okunamadı: {png.name} ({exc})")

check(len(models) == 21, f"Sahnede 21 doğa modeli bekleniyordu, bulundu: {len(models)}")
manifest_keys = set()
for item in models:
    key = item.get("key", "")
    manifest_keys.add(key)
    check(item.get("status") == "available", f"Model available değil: {key}")
    model_path = ROOT / "assets" / item.get("file", "")
    check(model_path.is_file(), f"Sahne modeli bulunamadı: {key} -> {item.get('file')}")

layout = (ROOT / "core/src/main/java/aict/core/NatureCampusLayout.java").read_text(encoding="utf-8")
used_keys = set(re.findall(r'"(nature\.[a-zA-Z0-9_]+)"', layout))
check(used_keys == manifest_keys,
      f"NatureCampusLayout/manifest anahtarları farklı. Koddaki eksik: {sorted(used_keys-manifest_keys)}, manifestte kullanılmayan: {sorted(manifest_keys-used_keys)}")

license_path = NATURE / "License_Standard.txt"
check(license_path.is_file(), "Orijinal Standard lisans metni eksik")
if license_path.exists():
    license_text = license_path.read_text(encoding="utf-8", errors="replace").lower()
    check("cc0" in license_text or "public domain" in license_text,
          "Lisans metni CC0/Public Domain ifadesi içermiyor")

if errors:
    print("DOĞA VARLIK DOĞRULAMASI BAŞARISIZ")
    for error in errors:
        print("HATA:", error)
    raise SystemExit(1)

print("Doğa varlık doğrulaması başarılı.")
print(f"Runtime varlıkları: {len(gltfs)} glTF, {len(bins)} .bin, {len(pngs)} PNG")
print(f"Başlangıç sahnesi: {len(models)} model; tüm harici URI'ler ve doku dosyaları mevcut.")
