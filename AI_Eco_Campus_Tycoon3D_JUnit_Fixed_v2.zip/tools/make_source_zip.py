#!/usr/bin/env python3
"""Create <=24 MB source and optional model archives with repository-root layout."""
from pathlib import Path
import zipfile, sys
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
STAGE=sys.argv[1] if len(sys.argv)>1 else '5'
LIMIT=24*1024*1024
EXCLUDED_DIRS={'build','.gradle','.git','.idea','__pycache__'}
EXCLUDED_SUFFIXES={'.class','.apk','.pyc'}

def files_for_source():
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in rel.parts): continue
        if p.suffix in EXCLUDED_SUFFIXES or p.name=='local.properties': continue
        if rel.parts[:2]==('assets','models') and p.suffix.lower()=='.glb': continue
        if rel.parts[:2] in (('assets','ui'),('assets','fonts')): continue
        yield p,rel

def write_zip(path, entries):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p,rel in entries: z.write(p,rel.as_posix())
    size=path.stat().st_size
    if size>LIMIT: raise SystemExit(f'{path.name} 24 MB sınırını aştı: {size}')
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        required={'settings.gradle','android/src/main/AndroidManifest.xml','assets/models/runtime_manifest.json'}
        missing=required-names
        if missing and 'kod.zip' in path.name: raise SystemExit(f'ZIP eksik dosya: {missing}')
        print(f'{path.name}: {size/1024/1024:.2f} MB | {len(names)} dosya')
        print('  '+', '.join(sorted(required & names)))

source=OUT/f'AICompanyTycoon3D_Asama{STAGE}_kod.zip'
write_zip(source,files_for_source())
assets=[]
for p in sorted((ROOT/'assets').rglob('*')):
    if p.is_file() and (p.relative_to(ROOT/'assets').parts[0] in ('models','ui','fonts')):
        if p.relative_to(ROOT/'assets').as_posix()=='models/runtime_manifest.json': continue
        assets.append((p,Path('assets')/p.relative_to(ROOT/'assets')))
if assets:
    model=OUT/f'AICompanyTycoon3D_Asama{STAGE}_modeller_1.zip'
    write_zip(model,assets)
else: print('Model ZIP oluşturulmadı: assets/models, ui ve fonts altında eklenecek dosya yok.')
