#!/usr/bin/env python3
"""Regenerate model credits and append the supplied CC0 nature package credit."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / 'assets/models/runtime_manifest.json').read_text(encoding='utf-8'))
lines = [
    '# Asset Credits',
    '',
    'Bu dosya `tools/update_credits.py` ile manifestten üretilir.',
    '`status: available` girdiler listelenir; kaynak/lisans bilgisi eksik olanlar doğrulanmadı olarak işaretlenir.',
    '',
    '| Manifest anahtarı | Dosya | Yazar | Kaynak | Lisans | Değişiklik |',
    '|---|---|---|---|---|---|',
]
added = False
for item in manifest.get('models', []):
    if item.get('status') != 'available':
        continue
    required = ('file', 'author', 'source_url', 'license')
    if not all(item.get(k) for k in required):
        # Keep the manifest asset visible without inventing a source or license.
        lines.append("| {key} | `{file}` | Doğrulanmadı | — | Lisans/atıf gerekli | Başlangıç sahnesi allowlist'inde kullanılmaz. |".format(
            key=item.get('key', '?'), file=item.get('file', '')))
        added = True
        continue
    lines.append('| {key} | `{file}` | {author} | {source} | {license} | {change} |'.format(
        key=item['key'], file=item['file'], author=item['author'], source=item['source_url'],
        license=item['license'], change=item.get('changes', 'Yok')))
    added = True
if not added:
    lines.append('| — | Henüz eklenmiş model yok | — | — | — | — |')
lines.extend([
    '',
    '## Çevre modelleri — Stylized Nature MegaKit Standard',
    '',
    '- Yazar/kaynak: Quaternius — https://quaternius.com/',
    '- Paket: kullanıcının sağladığı Stylized Nature MegaKit Standard arşivi.',
    '- Lisans: CC0 1.0 Universal; orijinal `assets/models/nature/License_Standard.txt` dosyası korunur.',
    '- Değişiklik: Sahne için seçilen 21 glTF model kullanılır; büyük PNG dokuların proje kopyaları 1024 px üst sınırına indirilmiştir.',
    '',
    '## Font',
    '',
    '- Bu teslimatta ayrı Noto Sans font dosyası bulunmaz. Android sistem Roboto fontu veya libGDX varsayılan bitmap fontu yedek olarak kullanılır.',
])
(ROOT / 'assets/CREDITS.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('Kredi tablosu güncellendi.')
