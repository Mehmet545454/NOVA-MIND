#!/usr/bin/env python3
"""Validate only GLBs that ModelLibrary actually loads at game startup."""
from __future__ import annotations
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
manifest = json.loads((ASSETS / "models/runtime_manifest.json").read_text(encoding="utf-8"))
source = (ROOT / "core/src/main/java/aict/core/ModelLibrary.java").read_text(encoding="utf-8")
section = source.split("private static final Set<String> RUNTIME_MODEL_KEYS = Set.of(", 1)[1].split(");", 1)[0]
runtime_keys = set(re.findall(r'"([a-z]+\.[a-zA-Z0-9_]+)"', section))
entries = {item["key"]: item for item in manifest.get("models", [])}
credits = (ASSETS / "CREDITS.md").read_text(encoding="utf-8")
errors: list[str] = []
total_bytes = 0


def image_dimensions(data: bytes):
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        return struct.unpack_from(">II", data, 16)
    if data.startswith(b"\xff\xd8"):
        offset = 2
        while offset + 4 <= len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
                continue
            if offset + 2 > len(data):
                break
            length = struct.unpack_from(">H", data, offset)[0]
            if length < 2 or offset + length > len(data):
                break
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                if length < 7:
                    break
                height, width = struct.unpack_from(">HH", data, offset + 3)
                return width, height
            offset += length
    raise ValueError("embedded image format/dimensions unsupported")


def read_glb(path: Path):
    raw = path.read_bytes()
    if len(raw) < 20 or raw[:4] != b"glTF":
        raise ValueError("invalid GLB header")
    version, declared_length = struct.unpack_from("<II", raw, 4)
    if version != 2 or declared_length != len(raw):
        raise ValueError("invalid GLB version/length")
    offset, document, binary = 12, None, b""
    while offset < len(raw):
        if offset + 8 > len(raw):
            raise ValueError("truncated chunk header")
        length, kind = struct.unpack_from("<I4s", raw, offset)
        offset += 8
        chunk = raw[offset:offset + length]
        if len(chunk) != length:
            raise ValueError("truncated chunk")
        offset += length
        if kind == b"JSON":
            document = json.loads(chunk.decode("utf-8").rstrip("\x00 \t\r\n"))
        elif kind == b"BIN\x00":
            binary = chunk
    if document is None:
        raise ValueError("missing JSON chunk")
    tris = 0
    for mesh in document.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            mode = primitive.get("mode", 4)
            if mode not in (4, 5, 6):
                continue
            count = (document["accessors"][primitive["indices"]]["count"]
                     if "indices" in primitive
                     else document["accessors"][primitive["attributes"]["POSITION"]]["count"])
            tris += count // 3 if mode == 4 else max(0, count - 2)
    external = [item["uri"] for group in ("buffers", "images")
                for item in document.get(group, [])
                if item.get("uri") and not item["uri"].startswith("data:")]
    image_sizes = []
    for image in document.get("images", []):
        if "bufferView" not in image:
            continue
        view = document["bufferViews"][image["bufferView"]]
        start, length = int(view.get("byteOffset", 0)), int(view["byteLength"])
        data = binary[start:start + length]
        image_sizes.append(image_dimensions(data))
    return raw, tris, external, image_sizes


for key in sorted(runtime_keys):
    item = entries.get(key)
    if not item:
        errors.append(f"{key}: missing from manifest")
        continue
    rel = item.get("file", "")
    path = ASSETS / rel
    if item.get("status") != "available" or not path.is_file():
        errors.append(f"{key}: model unavailable or file missing ({rel})")
        continue
    if item.get("license") not in ("CC0", "CC-BY") or not item.get("author") or not item.get("source_url"):
        errors.append(f"{key}: source/license attribution incomplete")
    if item.get("verified") is not True:
        errors.append(f"{key}: verified flag is not true")
    if key not in credits:
        errors.append(f"{key}: missing from CREDITS.md")
    try:
        raw, tris, external, dimensions = read_glb(path)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"{key}: {exc}")
        continue
    total_bytes += len(raw)
    if len(raw) > 20 * 1024 * 1024:
        errors.append(f"{key}: file exceeds 20 MB")
    if external:
        errors.append(f"{key}: external file references: {external}")
    if item.get("tris") != tris:
        errors.append(f"{key}: manifest triangles {item.get('tris')} != actual {tris}")
    for width, height in dimensions:
        if width == 0 or height == 0 or width > 1024 or height > 1024:
            errors.append(f"{key}: embedded texture dimension outside 1..1024 ({width}x{height})")
    kind = item.get("kind", "")
    if key.startswith("character.") or kind == "character":
        budget = 6000
    elif kind in ("building", "structure") or key in ("office.floor", "office.wall"):
        budget = 1500
    elif key.startswith(("server.", "factory.", "sector.")) or kind in ("machine", "vehicle"):
        budget = 6000
    else:
        budget = 2500
    if tris > budget:
        errors.append(f"{key}: {tris} triangles > mobile budget {budget}")

if total_bytes > 120 * 1024 * 1024:
    errors.append(f"runtime GLBs total {total_bytes:,} bytes > 120 MB")

if errors:
    print("RUNTIME MODEL VALIDATION FAILED")
    for error in errors:
        print("ERROR:", error)
    raise SystemExit(1)
print("Runtime GLB validation passed.")
print(f"Startup allowlist: {len(runtime_keys)} GLB models; {total_bytes:,} bytes total.")
print("All startup GLBs have verified license/credit metadata, embedded textures, and fit configured mobile triangle budgets.")
