from PIL import Image, ImageDraw
from pathlib import Path
root=Path(__file__).resolve().parents[1] / 'assets' / 'ui'
root.mkdir(parents=True, exist_ok=True)
W=H=64

def create(name, top, bottom, border, accent=None):
    im=Image.new('RGBA',(W,H))
    px=im.load()
    for y in range(H):
        t=y/(H-1)
        c=tuple(round(top[i]*(1-t)+bottom[i]*t) for i in range(3))+(244,)
        for x in range(W): px[x,y]=c
    d=ImageDraw.Draw(im)
    # Subtle inset edge and rounded corners; center remains flat for 9-patch stretching.
    d.rounded_rectangle((1,1,W-2,H-2),radius=9,outline=border,width=2)
    d.line((10,3,W-11,3),fill=(255,255,255,26),width=1)
    if accent:
        d.line((12,5,W-13,5),fill=accent,width=1)
    im.save(root/name,optimize=True)

create('panel.png',(31,63,103),(15,35,66),(82,139,197),(110,202,226,120))
create('button_up.png',(53,111,171),(29,73,130),(104,166,218))
create('button_over.png',(75,147,205),(39,94,158),(150,203,239),(132,224,233,140))
create('button_down.png',(28,88,130),(18,56,100),(83,160,198),(142,218,229,150))
(root/'README.md').write_text(
    '# UI Texture Assets\n\n'
    'Bu dört 9-patch PNG, AI Company Tycoon 3D arayüzü için bu projede özgün olarak üretildi. '
    'Dış kaynaktan alınmış görsel içermez. `Theme.java` içindeki 18 px dilim ölçüsüyle uyumludur.\n',
    encoding='utf-8')
config={
 'font':'fonts/NotoSans-Regular.ttf',
 'panel':'ui/panel.png',
 'buttonUp':'ui/button_up.png',
 'buttonOver':'ui/button_over.png',
 'buttonDown':'ui/button_down.png',
 'palette':{
   'text':'F1F5FA',
   'buttonText':'FFFFFF',
   'buttonDownText':'E0F8FF',
   'title':'FFFFFF'
 }
}
(root/'uiskin.json').write_text(__import__('json').dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
