# Donanım JSON şeması

Her `data/hardware/*.json` dosyası `HardwareItem[]` dizisidir. Alanlar: `id`, `brand`, `family`, `model`, `category`, `tier` (1–11), `release_year`, `era`, `specs` nesnesi, `game_price` (USD oyun dengesi), `price_is_game_value:true`, `power_w`, `warranty_months`, `lifespan_hours`, `compat`, `verified`.

Uyumluluk için kullanılan teknik `specs` anahtarları: `socket`, `ram_type`, `form_factor`, `watt`, `required_psu_w`. Bilgisi teyit edilmemiş model `verified:false` olmalıdır.
