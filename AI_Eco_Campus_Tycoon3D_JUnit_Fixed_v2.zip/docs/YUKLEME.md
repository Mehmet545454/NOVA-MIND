# Telefonda GitHub üzerinden APK derleme

1. Telefonda tarayıcıdan `github.com` aç. Gerekirse tarayıcı menüsünden **Masaüstü sitesi**ni etkinleştir.
2. **New repository** seç ve boş bir depo oluştur. README veya .gitignore eklemek zorunda değilsin.
3. Depoda **Add file → Create new file** seç. Dosya adı alanına `.github/workflows/build.yml` yaz. ZIP içindeki `.github/workflows/build.yml` ile aynı içeriği yapıştır ve **Commit changes** yap.
4. **Add file → Create new file** ile `incoming/.gitkeep` dosyasını oluştur ve commit et.
5. Depoda `incoming` klasörüne gir. **Add file → Upload files** ile `AICompanyTycoon3D_Asama5_kod.zip` ve `AICompanyTycoon3D_Asama5_modeller_1.zip` dosyalarını seç. ZIP'leri açma; olduğu gibi yükle. Görsel ZIP, 16 Kenney CC0 ofis GLB modelini, lisans dosyasını, 9-patch arayüz dokularını ve Noto Sans OFL fontunu içerir. Güncel projede kalan 20 GLB dosyası eksik olarak manifestte işaretlidir.
6. **Commit changes** yap. Ardından **Actions → android-build** akışını aç. `:sim:test` ve Android APK derlemesi başarılı olursa iş yeşil olur.
7. Depo ana sayfasındaki **Releases** bölümünden en yeni `build-...` kaydını aç. `.apk` dosyasına dokunup indir.
8. Android indirilen APK'yı açmanı engellerse Android'in gösterdiği uygulama bazlı kurulum iznini verip kurulumu tamamla. Play dışı APK için Play Protect uyarısı görünebilir.

## Build.yml'i ayrı yapıştırma
ZIP depoya yüklendiğinde GitHub Actions kendiliğinden içindeki workflow dosyasını etkinleştirmez. Bu yüzden 3. adım zorunludur. `build.yml` içeriği proje ZIP'inde de bulunur.

## Yeni sürüm yüklerken
Önce `incoming/` klasöründeki önceki aşamaların tüm ZIP dosyalarını sil. Yeni aşamanın kod ve model parçalarını yükle. Aksi halde eski kaynaklar yeni dosyaların üzerine yazılabilir.

## Hata alırsan
Actions içinde kırmızı olan adımı açıp hata metnini kopyala. Derleme hatasında önce o hatayı gider; kırmızı CI üzerinde yeni oyun aşamasına geçme.
