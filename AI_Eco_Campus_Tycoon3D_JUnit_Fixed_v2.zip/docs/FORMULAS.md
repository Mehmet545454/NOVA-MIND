# Temel Formüller

## Oyun zamanı
- 365 gün × 24 × 60 × 60 = 31.536.000 oyun saniyesi/yıl.
- 31.536.000 / 1.080 = 29.200 oyun saniyesi / gerçek saniye.
- 2x, 4x, 8x hızları bu temel oranı çarpar.

## İş ilerlemesi
- Her oyun günü, her çalışan `max(1, floor(skill / 20))` iş birimi üretir.
- İş tamamlanınca sözleşme ödülü tek seferlik deftere yazılır.

## Donanım puanı
- Kurulan PC'nin ilk basit performans skoru, parçaların `tier × 8` toplamıdır. Aşama 2'de CPU/GPU/RAM/IO dar boğaz modeli ile değiştirilecektir.

## Ekonomi
- Nakit = başlangıç nakdi + gelir defteri toplamı + gider defteri toplamı.
- Kira, internet, maaş ve birikmiş elektrik ay sınırında tek sefer işlenir.

## Veri merkezi ve iş yükü (Aşama 2)
- Rack doluluğu = kurulu cihazların U toplamı; toplam U sınırı aşılırsa kurulum reddedilir.
- Kesici durumu: kullanılan kW > tesis güç kapasitesi; bu durumda iş üretimi durur.
- Soğutma faktörü = `min(1, coolingCapacity / heatLoad)` ve aşırı yükte en az 0,25; iş ilerlemesini çarpar.
- İş yükü darboğazı = CPU, GPU (çoklu GPU verim kaybı dahil), VRAM, RAM, disk, ağ ve soğutma faktörlerinin en küçüğü.
- AI eğitim süresi = `18.000.000 / (GPU skoru × veri kalitesi × (0,5 + çalışan becerisi/100) × soğutma faktörü)` oyun saniyesi. En düşük çarpan 0,25 alınır.
- Yayınlama öncesi güvenlik puanı en az 60 olmalıdır.

## Pazar ve finans (Aşama 3)
- Aylık talep tabanı = `max(0, 18 + (ürünKalitesi-50)×0,18 - (fiyatEndeksi-100)×0,12 - rakipBaskısı×0,08)`.
- Müşteri kazanımı memnuniyetle çarpılır; kayıp müşteri oranı memnuniyet azaldıkça yükselir; müşteri sayısı sunucu kapasitesiyle sınırlanır.
- Kredi aylık taksiti = sabit anapara payı + kalan anapara × aylık faiz. Nakit yetmezse ödeme uygulanmaz.
- Şirket değeri = `max(varlıklar, yıllık abonelik geliri × (1 + itibar/100 + teknoloji/200))`.

## Dünya ve üretim (Aşama 4)
- Bölgesel kira/maaş/elektrik/lojistik katsayıları `WorldMap` verisinden gelir; bunlar gerçek ülke maliyeti iddiası değil oyun dengesi değerleridir.
- Sevkiyat teslimi kalan oyun günü sıfıra indiğinde gerçekleşir; depo kapasitesi mevcut + yoldaki stok için kontrol edilir.
- Üretim hızı = `max(0,15, (işçiSayısı×0,12 + makineVerimi/100) × bakım/100)`.

## Sektör yaşam döngüsü (Aşama 5)
- Tasarım için en az 20 araştırma puanı ve 100.000 cent yatırım; prototip için beceri ≥40 ve tesis seviyesi ≥1; testten sertifikaya geçiş için kalite ≥55 gerekir.
- Üretim aşamasında satış geliri = `max(10.000, yatırım × (kalite+20)/100)` oyun centidir.
