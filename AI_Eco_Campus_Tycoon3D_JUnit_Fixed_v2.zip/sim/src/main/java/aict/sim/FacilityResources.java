package aict.sim;

/** Physical limits for an office/data-centre site. All capacities are persisted as plain values. */
public final class FacilityResources {
    public double powerCapacityKw=8.0, coolingCapacityKw=6.0, networkGbps=1.0, floorLoadKg=1200.0;
    public double powerUsedKw, heatLoadKw, networkUsedGbps, floorLoadUsedKg;
    public boolean breakerTripped, thermalThrottle;
    public void setCapacity(double power,double cooling,double network,double floor){if(power<=0||cooling<=0||network<=0||floor<=0)throw new IllegalArgumentException("Kapasiteler pozitif olmalı.");powerCapacityKw=power;coolingCapacityKw=cooling;networkGbps=network;floorLoadKg=floor;recalculate();}
    public void setLoad(double power,double heat,double network,double floor){powerUsedKw=Math.max(0,power);heatLoadKw=Math.max(0,heat);networkUsedGbps=Math.max(0,network);floorLoadUsedKg=Math.max(0,floor);recalculate();}
    public void recalculate(){breakerTripped=powerUsedKw>powerCapacityKw;thermalThrottle=heatLoadKw>coolingCapacityKw;}
    public double powerFactor(){return breakerTripped?0.0:1.0;}
    public double coolingFactor(){return thermalThrottle?Math.max(.25,coolingCapacityKw/Math.max(coolingCapacityKw,heatLoadKw)):1.0;}
    public boolean networkOverloaded(){return networkUsedGbps>networkGbps;}
}
