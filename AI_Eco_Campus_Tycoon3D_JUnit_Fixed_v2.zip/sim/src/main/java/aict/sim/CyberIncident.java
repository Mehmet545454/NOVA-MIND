package aict.sim;

/** Safe abstract incident resolution: numeric impact only, no attack instructions. */
public final class CyberIncident {
 public enum Type { SERVICE_DISRUPTION, DATA_EXPOSURE, PHISHING_WAVE, SUPPLY_CHAIN_ALERT }
 public Result resolve(Type type,int defense,int response,int reputation){int severity=20+(type.ordinal()*7);int mitigation=Math.min(95,Math.max(0,defense*2+response));int impact=Math.max(0,severity-mitigation);int reputationLoss=Math.max(0,impact/5);return new Result(impact,reputationLoss,impact>0?"Olay kontrol altında; hizmet etkisi ölçüldü.":"Savunma olayı etkisizleştirdi.");}
 public record Result(int serviceImpact,int reputationLoss,String report){}
}
