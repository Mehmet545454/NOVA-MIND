package aict.sim;

/** Small serializable SplitMix64 generator; independent of java.util.Random. */
public final class Rng {
    private long state;
    public Rng() { this(0x6A09E667F3BCC909L); }
    public Rng(long seed) { state = seed; }
    public long nextLong() {
        long z = (state += 0x9E3779B97F4A7C15L);
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }
    public int nextInt(int bound) {
        if (bound <= 0) throw new IllegalArgumentException("bound > 0 olmalı");
        return (int) Long.remainderUnsigned(nextLong(), bound);
    }
    public double nextDouble() { return (nextLong() >>> 11) * 0x1.0p-53; }
    public long getState() { return state; }
    public void setState(long state) { this.state = state; }
}
