package aict.sim;

import java.util.LinkedHashMap;import java.util.Map;

/** Production queue with capacity, quality, scrap and maintenance. */
public final class Factory {
 public int level=1,workers=2,machineEfficiency=70,maintenance=80;public double rawMaterials=100,finishedGoods;public Map<String,Integer> finishedProducts=new LinkedHashMap<>();public ProductionOrder active;
 public boolean start(String product,int units,long materialCostCents){if(active!=null&&!active.completed||units<1||rawMaterials<units)return false;rawMaterials-=units;active=new ProductionOrder(product,units,Math.max(1,units*86_400L),materialCostCents);return true;}
 public void advance(long gameSeconds){if(active==null||active.completed)return;double factor=Math.max(.15,(workers*.12+machineEfficiency/100.0)*(maintenance/100.0));active.remainingSeconds=Math.max(0,active.remainingSeconds-(long)(gameSeconds*factor));if(active.remainingSeconds==0){active.completed=true;active.quality=Math.max(1,Math.min(100,machineEfficiency+maintenance-30));finishedGoods+=active.units;finishedProducts.merge(active.product,active.units,Integer::sum);}}
 public boolean removeFinished(String product,int units){int have=finishedProducts.getOrDefault(product,0);if(units<1||have<units)return false;if(have==units)finishedProducts.remove(product);else finishedProducts.put(product,have-units);finishedGoods-=units;return true;}
 public static final class ProductionOrder{public String product;public int units;public long remainingSeconds,materialCostCents;public int quality;public boolean completed;public ProductionOrder(){}ProductionOrder(String p,int u,long t,long c){product=p;units=u;remainingSeconds=t;materialCostCents=c;}}
}
