package aict.sim;

public final class WorkOrder {
    public String id;
    public String title;
    public int remainingWorkUnits;
    public long rewardCents;
    public boolean completed;
    public WorkOrder() { }
    public WorkOrder(String id, String title, int workUnits, long rewardCents) {
        this.id=id; this.title=title; this.remainingWorkUnits=workUnits; this.rewardCents=rewardCents;
    }
}
