package aict.sim;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HardwareItem {
    public String id;
    public String brand;
    public String family;
    public String model;
    public String category;
    public int tier;
    public int release_year;
    public String era;
    public Map<String, Object> specs = new LinkedHashMap<>();
    public long game_price;
    public boolean price_is_game_value = true;
    public int power_w;
    public int warranty_months;
    public long lifespan_hours;
    public Map<String, Object> compat = new LinkedHashMap<>();
    public boolean verified;

    public String label() { return (brand == null ? "" : brand + " ") + (model == null ? id : model); }
    public String spec(String key) {
        Object value = specs == null ? null : specs.get(key);
        return value == null ? null : String.valueOf(value);
    }
    public long priceCents() { return game_price * 100L; }
}
