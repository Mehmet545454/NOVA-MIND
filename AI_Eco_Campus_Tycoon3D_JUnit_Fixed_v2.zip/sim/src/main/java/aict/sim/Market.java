package aict.sim;

/** Customer subscriptions, churn and service quality. */
public final class Market {
 public int customers,capacity=100;public double satisfaction=75,marketShare;public long monthlyRecurringRevenueCents;public int outages;
 public void simulateMonth(int productQuality,int security,int priceIndex,int competitorPressure,int availableCapacity){capacity=Math.max(0,availableCapacity);double quality=(productQuality+security)/2.0;double demand=Math.max(0,18+(quality-50)*.18-(priceIndex-100)*.12-competitorPressure*.08);int gained=(int)Math.round(demand*Math.max(.2,satisfaction/75.0));int lost=(int)Math.ceil(customers*Math.max(.005,(100-satisfaction)/900.0));customers=Math.max(0,Math.min(capacity,customers+gained-lost));if(customers>=capacity&&capacity>0)outages++;satisfaction=Math.max(5,Math.min(100,satisfaction+(quality-60)*.04-(customers>capacity*.9?2:0)));monthlyRecurringRevenueCents=customers*(priceIndex*100L);}
}
