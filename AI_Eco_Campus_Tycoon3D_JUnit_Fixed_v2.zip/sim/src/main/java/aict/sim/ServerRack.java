package aict.sim;

import java.util.ArrayList;import java.util.List;
/** Rack inventory measured in rack units; placement is validated before mutation. */
public final class ServerRack {
 public int totalUnits=12; public List<RackDevice> devices=new ArrayList<>();
 public int usedUnits(){return devices.stream().mapToInt(d->d.units).sum();}
 public boolean install(String id,String kind,int units,double powerKw,double heatKw){if(id==null||id.isBlank()||units<1||units>42||devices.stream().anyMatch(d->d.id.equals(id))||usedUnits()+units>totalUnits)return false;devices.add(new RackDevice(id,kind,units,powerKw,heatKw));return true;}
 public boolean remove(String id){return devices.removeIf(d->d.id.equals(id));}
 public double powerKw(){return devices.stream().mapToDouble(d->d.powerKw).sum();} public double heatKw(){return devices.stream().mapToDouble(d->d.heatKw).sum();}
 public static final class RackDevice {public String id,kind;public int units;public double powerKw,heatKw;public RackDevice(){} RackDevice(String i,String k,int u,double p,double h){id=i;kind=k;units=u;powerKw=p;heatKw=h;}}
}
