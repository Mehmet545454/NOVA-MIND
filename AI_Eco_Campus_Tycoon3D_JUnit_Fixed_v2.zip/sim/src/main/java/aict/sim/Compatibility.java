package aict.sim;

import java.util.ArrayList;
import java.util.List;

public final class Compatibility {
    public Report check(List<HardwareItem> parts) {
        List<String> errors = new ArrayList<>();
        HardwareItem cpu = find(parts, "cpu");
        HardwareItem board = find(parts, "motherboard");
        HardwareItem ram = find(parts, "ram");
        HardwareItem psu = find(parts, "psu");
        HardwareItem box = find(parts, "case");
        HardwareItem cooler = find(parts, "cooling");
        if (cpu == null || board == null || ram == null || psu == null || box == null) {
            errors.add("PC için CPU, anakart, RAM, PSU ve kasa zorunludur.");
        } else {
            match(cpu, board, "socket", "İşlemci soketi anakartla uyuşmuyor.", errors);
            match(ram, board, "ram_type", "RAM türü anakartla uyuşmuyor.", errors);
            match(box, board, "form_factor", "Kasa anakart form faktörünü desteklemiyor.", errors);
            int required = number(cpu, "required_psu_w", 250) + number(cpu, "power_w", 65);
            int available = number(psu, "watt", psu.power_w);
            if (available < required) errors.add("Güç kaynağı yetersiz: en az " + required + " W öneriliyor.");
            if (cooler != null) {
                String supported = cooler.spec("socket");
                String cpuSocket = cpu.spec("socket");
                if (supported != null && cpuSocket != null && !supported.equalsIgnoreCase("universal") && !supported.equalsIgnoreCase(cpuSocket)) {
                    errors.add("Soğutucu işlemci soketiyle uyumlu değil.");
                }
            }
        }
        return new Report(errors.isEmpty(), List.copyOf(errors));
    }
    private static HardwareItem find(List<HardwareItem> items, String category) {
        return items.stream().filter(i -> category.equalsIgnoreCase(i.category)).findFirst().orElse(null);
    }
    private static int number(HardwareItem item, String key, int fallback) {
        try { return (int) Math.round(Double.parseDouble(item.spec(key))); } catch (Exception ignored) { return fallback; }
    }
    private static void match(HardwareItem a, HardwareItem b, String key, String message, List<String> errors) {
        String left = a.spec(key), right = b.spec(key);
        if (left != null && right != null && !left.equalsIgnoreCase(right)) errors.add(message);
    }
    public record Report(boolean compatible, List<String> errors) { }
}
