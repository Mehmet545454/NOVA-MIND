package aict.sim;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Inventory {
    private Map<String, Integer> quantities = new LinkedHashMap<>();
    private List<ComputerBuild> computers = new ArrayList<>();
    public void add(String itemId, int count) {
        if (itemId == null || itemId.isBlank() || count <= 0) throw new IllegalArgumentException("Geçersiz envanter girişi.");
        quantities.merge(itemId, count, Integer::sum);
    }
    public boolean consume(String itemId, int count) {
        int current = quantities.getOrDefault(itemId, 0);
        if (count <= 0 || current < count) return false;
        if (current == count) quantities.remove(itemId); else quantities.put(itemId, current - count);
        return true;
    }
    public int quantity(String id) { return quantities.getOrDefault(id, 0); }
    public Map<String, Integer> quantities() { return Map.copyOf(quantities); }
    public List<ComputerBuild> computers() { return List.copyOf(computers); }
    public void addComputer(ComputerBuild build) { computers.add(build); }
    public record ComputerBuild(String name, List<String> partIds, int performanceScore) { }
}
