package aict.sim;

import java.util.LinkedHashMap;import java.util.Map;
/** Finds the limiting resource; multi-GPU scaling includes communication overhead. */
public final class WorkloadEngine {
 public Result evaluate(double cpu,double gpu,double vram,double ram,double disk,double network,double cooling,int gpuCount){Map<String,Double> f=new LinkedHashMap<>();f.put("CPU",positive(cpu));f.put("GPU",positive(gpu)*gpuScaling(Math.max(1,gpuCount)));f.put("VRAM",positive(vram));f.put("RAM",positive(ram));f.put("Disk",positive(disk));f.put("Ağ",positive(network));f.put("Soğutma",positive(cooling));String bottleneck="CPU";double score=Double.POSITIVE_INFINITY;for(var e:f.entrySet())if(e.getValue()<score){score=e.getValue();bottleneck=e.getKey();}return new Result(bottleneck,Math.max(0,score),Map.copyOf(f));}
 private double positive(double n){return Math.max(0,n);} private double gpuScaling(int n){return n<=1?1.0:1.0+(n-1)*.72-(n-1)*(n-1)*.035;}
 public record Result(String bottleneck,double throughput,Map<String,Double> factors){}
}
