package aict.sim;

import java.util.Arrays;

/** Deterministic calendar: one game year is exactly 1,080 real seconds at 1x. */
public final class Clock {
    public static final long GAME_SECONDS_PER_YEAR = 365L * 24L * 60L * 60L;
    public static final long GAME_SECONDS_PER_DAY = 86_400L;
    public static final long GAME_SECONDS_PER_HOUR = 3_600L;
    public static final double GAME_SECONDS_PER_REAL_SECOND = 29_200.0;
    private static final int[] MONTH_DAYS = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    private long gameSeconds;
    private double fractionalGameSeconds;
    private int speed = 1;
    private long lastProcessedHour;
    private long lastProcessedDay;
    private long lastProcessedMonth;
    private long lastProcessedYear;

    public Clock() { }

    public AdvanceResult advance(double realDeltaSeconds) {
        if (!Double.isFinite(realDeltaSeconds) || realDeltaSeconds <= 0 || speed == 0) {
            return new AdvanceResult(0, 0, 0, 0, 0);
        }
        // A single frame may not inject a huge catch-up step. Remaining time is handled by later frames.
        double safeDelta = Math.min(realDeltaSeconds, 0.25d);
        double add = safeDelta * GAME_SECONDS_PER_REAL_SECOND * speed + fractionalGameSeconds;
        long whole = (long) Math.floor(add + 1e-9d);
        fractionalGameSeconds = add - whole;
        long before = gameSeconds;
        gameSeconds = Math.addExact(gameSeconds, whole);

        long hourIndex = gameSeconds / GAME_SECONDS_PER_HOUR;
        long dayIndex = gameSeconds / GAME_SECONDS_PER_DAY;
        long monthIndex = calendarMonthIndex(gameSeconds);
        long yearIndex = gameSeconds / GAME_SECONDS_PER_YEAR;

        long hours = Math.max(0, hourIndex - lastProcessedHour);
        long days = Math.max(0, dayIndex - lastProcessedDay);
        long months = Math.max(0, monthIndex - lastProcessedMonth);
        long years = Math.max(0, yearIndex - lastProcessedYear);
        lastProcessedHour = hourIndex;
        lastProcessedDay = dayIndex;
        lastProcessedMonth = monthIndex;
        lastProcessedYear = yearIndex;
        return new AdvanceResult(whole, hours, days, months, years);
    }

    private static long calendarMonthIndex(long seconds) {
        long year = seconds / GAME_SECONDS_PER_YEAR;
        long remainingDays = (seconds % GAME_SECONDS_PER_YEAR) / GAME_SECONDS_PER_DAY;
        int month = 0;
        while (month < MONTH_DAYS.length - 1 && remainingDays >= MONTH_DAYS[month]) {
            remainingDays -= MONTH_DAYS[month++];
        }
        return year * 12L + month;
    }

    public CalendarDate date() {
        long year = gameSeconds / GAME_SECONDS_PER_YEAR + 1;
        long remainingDays = (gameSeconds % GAME_SECONDS_PER_YEAR) / GAME_SECONDS_PER_DAY;
        long secondsInDay = gameSeconds % GAME_SECONDS_PER_DAY;
        int month = 0;
        while (month < MONTH_DAYS.length - 1 && remainingDays >= MONTH_DAYS[month]) {
            remainingDays -= MONTH_DAYS[month++];
        }
        int day = (int) remainingDays + 1;
        int hour = (int) (secondsInDay / 3_600L);
        int minute = (int) ((secondsInDay % 3_600L) / 60L);
        return new CalendarDate((int) year, month + 1, day, hour, minute);
    }

    public void setSpeed(int value) {
        if (!Arrays.stream(new int[]{0, 1, 2, 4, 8}).anyMatch(v -> v == value)) {
            throw new IllegalArgumentException("Hız yalnızca 0, 1, 2, 4 veya 8 olabilir.");
        }
        speed = value;
    }

    public int getSpeed() { return speed; }
    public long getGameSeconds() { return gameSeconds; }
    public double getFractionalGameSeconds() { return fractionalGameSeconds; }
    public long getLastProcessedHour() { return lastProcessedHour; }
    public long getLastProcessedDay() { return lastProcessedDay; }
    public long getLastProcessedMonth() { return lastProcessedMonth; }
    public long getLastProcessedYear() { return lastProcessedYear; }

    public record AdvanceResult(long gameSecondsAdded, long hours, long days, long months, long years) { }
    public record CalendarDate(int year, int month, int day, int hour, int minute) {
        public String display() {
            return String.format(java.util.Locale.ROOT, "Yıl %d • %02d/%02d • %02d:%02d", year, day, month, hour, minute);
        }
    }
}
