package aict.sim;

public final class Employee {
    public String id;
    public String name;
    public String specialty;
    public int skill;
    public long monthlySalaryCents;
    public int experienceMonths;
    public double morale = 1.0;
    public String assignedProjectId;
    public String state = "idle";
    public int workloadPercent = 70;
    public Employee() { }
    public Employee(String id, String name, String specialty, int skill, long salaryCents) {
        this.id=id; this.name=name; this.specialty=specialty; this.skill=skill; this.monthlySalaryCents=salaryCents;
    }
}
