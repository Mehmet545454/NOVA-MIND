package aict.sim;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Versioned JSON save with atomic replace. */
public final class SaveManager {
    private static final int CURRENT_VERSION = 5;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    public void save(Path destination, Simulation simulation) throws IOException {
        Path parent=destination.toAbsolutePath().getParent();
        if(parent!=null)Files.createDirectories(parent);
        Path temporary=destination.resolveSibling(destination.getFileName()+".tmp");
        SaveEnvelope envelope=new SaveEnvelope(CURRENT_VERSION,simulation);
        Files.writeString(temporary,gson.toJson(envelope));
        try { Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
        catch(java.nio.file.AtomicMoveNotSupportedException ex){Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING);}
    }
    public Simulation load(Path source) throws IOException {
        if(!Files.exists(source))throw new IOException("Kayıt dosyası bulunamadı.");
        SaveEnvelope envelope;
        try { envelope=gson.fromJson(Files.readString(source),SaveEnvelope.class); }
        catch(RuntimeException ex){throw new IOException("Kayıt dosyası okunamadı veya bozuk.",ex);}
        if(envelope==null||envelope.simulation==null)throw new IOException("Kayıt dosyası boş.");
        if(envelope.saveVersion>CURRENT_VERSION)throw new IOException("Bu kayıt daha yeni bir oyun sürümüne ait.");
        envelope.simulation.setSaveVersion(CURRENT_VERSION);
        envelope.simulation.ensureStarterOffice();
        return envelope.simulation;
    }
    private static final class SaveEnvelope {
        int saveVersion; Simulation simulation;
        SaveEnvelope(int version,Simulation simulation){this.saveVersion=version;this.simulation=simulation;}
    }
}
