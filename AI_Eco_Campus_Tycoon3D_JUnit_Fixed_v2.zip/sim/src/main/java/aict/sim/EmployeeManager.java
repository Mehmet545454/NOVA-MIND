package aict.sim;

import java.util.ArrayList;
import java.util.List;

public final class EmployeeManager {
    private List<Employee> employees = new ArrayList<>();
    public HireResult hire(String id, String name, String specialty, int skill, long salaryCents, int deskCapacity, long cashCents) {
        if (employees.size() >= deskCapacity) return new HireResult(false, "Boş masa yok. Önce ofise masa yerleştir.", null);
        Employee employee = new Employee(id,name,specialty,Math.max(1,Math.min(100,skill)),salaryCents);
        employees.add(employee);
        return new HireResult(true, "Çalışan işe alındı.", employee);
    }
    public long monthlyPayrollCents() { return employees.stream().mapToLong(e -> e.monthlySalaryCents).sum(); }
    public List<Employee> all() { return List.copyOf(employees); }
    public int size() { return employees.size(); }
    public Employee find(String id){return employees.stream().filter(e->e.id.equals(id)).findFirst().orElse(null);}
    public boolean assign(String employeeId,String projectId){Employee e=find(employeeId);if(e==null||projectId==null||projectId.isBlank())return false;e.assignedProjectId=projectId;return true;}
    public Employee fire(String employeeId){Employee e=find(employeeId);if(e==null)return null;employees.remove(e);return e;}
    public void monthlyUpdate(){for(Employee e:employees){e.experienceMonths++;e.morale=Math.max(.25,Math.min(1.0,e.morale+(e.assignedProjectId==null?-.02:.01)));}}

    public record HireResult(boolean success, String message, Employee employee) { }
}
