package aict.sim;

/** Fictional competitor using deterministic monthly decisions. */
public final class RivalCompany {
 public String id,name,personality;public long cashCents;public int employees,technology,priceIndex,customers;public boolean bankrupt;
 public RivalCompany(){} public RivalCompany(String i,String n,String p,long cash,int staff,int tech,int price,int clients){id=i;name=n;personality=p;cashCents=cash;employees=staff;technology=tech;priceIndex=price;customers=clients;}
 public void month(long demandIndex,long seed){if(bankrupt)return;long roll=Math.floorMod(seed+id.hashCode()+technology*31L,100);if(personality.equals("yenilikçi")&&cashCents>2_000_000&&roll<45){cashCents-=500_000;technology+=2;}else if(personality.equals("ucuz")){priceIndex=Math.max(55,priceIndex-2);}else if(personality.equals("agresif")&&roll<30){priceIndex=Math.max(60,priceIndex-4);customers+=Math.max(1,(int)(demandIndex/20));}else if(cashCents>500_000&&roll<25){employees++;cashCents-=120_000;}cashCents+=Math.max(0,customers)*Math.max(1000,priceIndex*100L)-employees*80_000L;if(cashCents<0){bankrupt=true;customers=0;}}
}
