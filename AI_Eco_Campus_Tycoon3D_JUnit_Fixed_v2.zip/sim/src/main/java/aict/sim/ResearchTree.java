package aict.sim;

import java.util.LinkedHashSet;
import java.util.Set;

/** Research unlocks are explicit and persisted. Removed legacy branches are sanitized on load. */
public final class ResearchTree {
 public Set<String> unlocked=new LinkedHashSet<>();
 public Set<String> completed=new LinkedHashSet<>();
 public ResearchTree(){unlocked.add("basic_computing");}
 public void removeRetiredBranches(){
  if(unlocked==null)unlocked=new LinkedHashSet<>();
  if(completed==null)completed=new LinkedHashSet<>();
  for(String id:new String[]{"health_tech","medical","space_systems","aerospace","automotive","energy_systems","energy","finance_telecom","cloud_platform","robotics","semiconductor"}){unlocked.remove(id);completed.remove(id);}
 }
 public boolean research(String id,int points){
  removeRetiredBranches();
  if(id==null||id.isBlank()||id.equals("health_tech")||id.equals("space_systems")||id.equals("automotive")||id.equals("energy_systems")||id.equals("finance_telecom")||id.equals("cloud_platform")||id.equals("robotics")||id.equals("semiconductor")||points<1||!unlocked.contains(id)||completed.contains(id))return false;
  completed.add(id);
  switch(id){
   case "basic_computing"->{unlocked.add("ai_training");unlocked.add("server_infrastructure");}
   default->{}
  }
  return true;
 }
}
