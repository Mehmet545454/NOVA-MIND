package aict.sim;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class Catalog {
    private Map<String, HardwareItem> items = new LinkedHashMap<>();
    public void add(HardwareItem item) {
        if (item == null || item.id == null || item.id.isBlank()) throw new IllegalArgumentException("Ürün kimliği boş olamaz.");
        items.putIfAbsent(item.id, item);
    }
    public Optional<HardwareItem> find(String id) { return Optional.ofNullable(items.get(id)); }
    public Collection<HardwareItem> all() { return List.copyOf(items.values()); }
    public List<HardwareItem> byCategory(String category) {
        return items.values().stream().filter(i -> category.equalsIgnoreCase(i.category)).toList();
    }
    public int size() { return items.size(); }

    public static Catalog loadDirectory(Path directory) throws IOException {
        Catalog catalog = new Catalog();
        if (!Files.isDirectory(directory)) return catalog;
        Gson gson = new Gson();
        Type listType = new TypeToken<List<HardwareItem>>(){}.getType();
        try (var files = Files.list(directory)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                List<HardwareItem> loaded = gson.fromJson(Files.readString(file), listType);
                if (loaded != null) loaded.forEach(catalog::add);
            }
        }
        return catalog;
    }
}
