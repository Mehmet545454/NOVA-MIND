package aict.sim;

public final class Economy {
    private long cashCents = 1_000_000L;
    private long monthlyRevenueCents;
    private long monthlyExpenseCents;
    private long electricityAccruedCents;
    private int consecutiveNegativeMonths;
    private Ledger ledger = new Ledger();

    public Economy() { }
    public Economy(long startingCashCents) { cashCents = startingCashCents; }

    public boolean spend(long amountCents, long gameSeconds, String category, String description) {
        if (amountCents < 0) throw new IllegalArgumentException("Harcama negatif olamaz.");
        if (cashCents < amountCents) return false;
        cashCents -= amountCents;
        monthlyExpenseCents += amountCents;
        ledger.add(gameSeconds, category, -amountCents, description);
        return true;
    }

    public void earn(long amountCents, long gameSeconds, String category, String description) {
        if (amountCents < 0) throw new IllegalArgumentException("Gelir negatif olamaz.");
        cashCents += amountCents;
        monthlyRevenueCents += amountCents;
        ledger.add(gameSeconds, category, amountCents, description);
    }

    public void accrueElectricity(long amountCents) { electricityAccruedCents += Math.max(0, amountCents); }

    public MonthResult closeMonth(long gameSeconds, long rentCents, long internetCents, long payrollCents) {
        long power = electricityAccruedCents;
        boolean rentPaid = spend(rentCents, gameSeconds, "Kira", "Ofis aylık kirası");
        boolean internetPaid = spend(internetCents, gameSeconds, "İnternet", "İnternet hizmeti");
        boolean payrollPaid = spend(payrollCents, gameSeconds, "Maaş", "Çalışan maaşları");
        boolean powerPaid = spend(power, gameSeconds, "Elektrik", "Aylık elektrik faturası");
        electricityAccruedCents = 0;
        boolean allPaid = rentPaid && internetPaid && payrollPaid && powerPaid;
        if (allPaid && cashCents >= 0) consecutiveNegativeMonths = 0;
        else consecutiveNegativeMonths++;
        MonthResult result = new MonthResult(rentPaid, internetPaid, payrollPaid, powerPaid,
                monthlyRevenueCents, monthlyExpenseCents, cashCents, consecutiveNegativeMonths);
        monthlyRevenueCents = 0;
        monthlyExpenseCents = 0;
        return result;
    }

    public long getCashCents() { return cashCents; }
    public long getMonthlyRevenueCents() { return monthlyRevenueCents; }
    public long getMonthlyExpenseCents() { return monthlyExpenseCents; }
    public long getElectricityAccruedCents() { return electricityAccruedCents; }
    public int getConsecutiveNegativeMonths() { return consecutiveNegativeMonths; }
    public Ledger getLedger() { return ledger; }
    public boolean isBankrupt() { return consecutiveNegativeMonths >= 2; }
    public record MonthResult(boolean rentPaid, boolean internetPaid, boolean payrollPaid, boolean powerPaid,
                              long revenueCents, long expenseCents, long cashCents, int negativeMonths) { }
}
