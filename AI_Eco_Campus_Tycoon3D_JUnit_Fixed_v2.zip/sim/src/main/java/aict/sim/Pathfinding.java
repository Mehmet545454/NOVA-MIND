package aict.sim;

import java.util.*;

/** Deterministic four-direction A* over the office placement grid. */
public final class Pathfinding {
    public List<Cell> findPath(int width, int depth, boolean[][] blocked, Cell start, Cell goal) {
        if (!inside(width,depth,start) || !inside(width,depth,goal)) return List.of();
        if (isBlocked(blocked,goal)) return List.of();
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingInt(Node::f).thenComparingInt(Node::g).thenComparing(n -> n.cell.x()).thenComparing(n -> n.cell.z()));
        Map<Cell,Integer> cost = new HashMap<>(); Map<Cell,Cell> parent = new HashMap<>();
        open.add(new Node(start,0,manhattan(start,goal))); cost.put(start,0);
        int[][] directions={{1,0},{-1,0},{0,1},{0,-1}};
        while(!open.isEmpty()) {
            Node current=open.poll();
            if(current.cell.equals(goal)) return reconstruct(parent,goal);
            if(current.g != cost.getOrDefault(current.cell,Integer.MAX_VALUE)) continue;
            for(int[] d:directions) {
                Cell next=new Cell(current.cell.x()+d[0],current.cell.z()+d[1]);
                if(!inside(width,depth,next) || isBlocked(blocked,next)) continue;
                int newCost=current.g+1;
                if(newCost<cost.getOrDefault(next,Integer.MAX_VALUE)) {
                    cost.put(next,newCost); parent.put(next,current.cell);
                    open.add(new Node(next,newCost,newCost+manhattan(next,goal)));
                }
            }
        }
        return List.of();
    }
    private static boolean inside(int w,int d,Cell c){return c.x()>=0&&c.z()>=0&&c.x()<w&&c.z()<d;}
    private static boolean isBlocked(boolean[][] b,Cell c){return b!=null&&c.z()<b.length&&c.x()<b[c.z()].length&&b[c.z()][c.x()];}
    private static int manhattan(Cell a,Cell b){return Math.abs(a.x()-b.x())+Math.abs(a.z()-b.z());}
    private static List<Cell> reconstruct(Map<Cell,Cell> p,Cell goal){List<Cell> path=new ArrayList<>();Cell c=goal;path.add(c);while(p.containsKey(c)){c=p.get(c);path.add(c);}Collections.reverse(path);return List.copyOf(path);}
    private record Node(Cell cell,int g,int f){}
    public record Cell(int x,int z){}
}
