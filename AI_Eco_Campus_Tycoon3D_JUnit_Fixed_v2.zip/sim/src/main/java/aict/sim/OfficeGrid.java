package aict.sim;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class OfficeGrid {
    private int width;
    private int depth;
    private List<PlacedItem> items = new ArrayList<>();
    public OfficeGrid() { this(8, 6); }
    public OfficeGrid(int width, int depth) { if (width < 1 || depth < 1) throw new IllegalArgumentException(); this.width=width; this.depth=depth; }
    public boolean canPlace(String itemId, int x, int z, int w, int d, int rotation) {
        if (w < 1 || d < 1 || x < 0 || z < 0) return false;
        int rw = rotation % 2 == 0 ? w : d;
        int rd = rotation % 2 == 0 ? d : w;
        if (x + rw > width || z + rd > depth) return false;
        for (PlacedItem item : items) {
            if (item.id.equals(itemId)) continue;
            int iw = item.rotation % 2 == 0 ? item.width : item.depth;
            int id = item.rotation % 2 == 0 ? item.depth : item.width;
            boolean overlap = x < item.x + iw && x + rw > item.x && z < item.z + id && z + rd > item.z;
            if (overlap) return false;
        }
        return true;
    }
    public boolean place(String itemId, String modelKey, int x, int z, int w, int d, int rotation, long valueCents, String kind) {
        if (!canPlace(itemId,x,z,w,d,rotation)) return false;
        items.add(new PlacedItem(itemId,modelKey,x,z,w,d,rotation,valueCents,kind)); return true;
    }
    public Optional<PlacedItem> remove(String itemId) {
        return items.stream().filter(i -> i.id.equals(itemId)).findFirst().map(i -> { items.remove(i); return i; });
    }
    public List<PlacedItem> items() { return List.copyOf(items); }
    public Optional<PlacedItem> find(String itemId) {
        return items.stream().filter(item -> item.id.equals(itemId)).findFirst();
    }
    public Optional<PlacedItem> at(int x, int z) {
        return items.stream().filter(item -> {
            int rw = item.rotation % 2 == 0 ? item.width : item.depth;
            int rd = item.rotation % 2 == 0 ? item.depth : item.width;
            return x >= item.x && x < item.x + rw && z >= item.z && z < item.z + rd;
        }).findFirst();
    }
    public boolean move(String itemId, int x, int z, int rotation) {
        PlacedItem item = find(itemId).orElse(null);
        if (item == null || !canPlace(itemId, x, z, item.width, item.depth, rotation)) return false;
        items.remove(item);
        items.add(new PlacedItem(item.id, item.modelKey, x, z, item.width, item.depth,
                rotation, item.valueCents, item.kind));
        return true;
    }
    public int deskCapacity() { return (int) items.stream().filter(i -> "desk".equals(i.kind)).count(); }
    /** Expands a saved office without moving or discarding any placed items. */
    public void expandToAtLeast(int minimumWidth, int minimumDepth) {
        if (minimumWidth < 1 || minimumDepth < 1) throw new IllegalArgumentException("Office dimensions must be positive.");
        width = Math.max(width, minimumWidth);
        depth = Math.max(depth, minimumDepth);
    }
    public int width() { return width; }
    public int depth() { return depth; }
    public record PlacedItem(String id, String modelKey, int x, int z, int width, int depth,
                             int rotation, long valueCents, String kind) { }
}
