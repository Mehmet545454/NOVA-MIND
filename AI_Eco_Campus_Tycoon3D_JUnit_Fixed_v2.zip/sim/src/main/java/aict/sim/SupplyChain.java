package aict.sim;

import java.util.ArrayList;import java.util.List;
/** Shipment and warehouse simulation; no external logistics service is required. */
public final class SupplyChain {
 public double warehouseCapacity=500,storedUnits;public List<Shipment> shipments=new ArrayList<>();private int sequence;
 public double inTransitUnits(){return shipments.stream().filter(s->!s.delivered).mapToInt(s->s.units).sum();}
 public boolean consumeStock(int units){if(units<1||storedUnits<units)return false;storedUnits-=units;return true;}
 public Shipment order(String item,int units,int days,long unitCost,double dutyMultiplier){if(item==null||item.isBlank()||units<1||days<1||storedUnits+inTransitUnits()+units>warehouseCapacity)throw new IllegalArgumentException("Sipariş veya depo kapasitesi geçersiz.");long total=Math.round(units*unitCost*Math.max(1,dutyMultiplier));Shipment s=new Shipment("ship-"+(++sequence),item,units,days,total);shipments.add(s);return s;}
 public void advanceDay(){for(Shipment s:shipments)if(!s.delivered){s.daysRemaining--;if(s.daysRemaining<=0){s.delivered=true;storedUnits+=s.units;}}}
 public boolean receive(String shipmentId){Shipment s=shipments.stream().filter(x->x.id.equals(shipmentId)).findFirst().orElse(null);if(s==null||!s.delivered||s.received)return false;s.received=true;return true;}
 public static final class Shipment{public String id,item;public int units,daysRemaining;public long totalCostCents;public boolean delivered,received;public Shipment(){}Shipment(String i,String p,int u,int d,long c){id=i;item=p;units=u;daysRemaining=d;totalCostCents=c;}}
}
