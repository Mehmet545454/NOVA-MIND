package aict.sim;

import java.util.ArrayList;
import java.util.List;

public final class Simulation {
    private int saveVersion = 5;
    private String companyName = "Yeni Teknoloji";
    private String country = "Türkiye";
    private Clock clock = new Clock();
    private Economy economy = new Economy();
    private Rng rng = new Rng(20261114L);
    private OfficeGrid office = new OfficeGrid(16,12);
    private EmployeeManager employeeManager = new EmployeeManager();
    private Inventory inventory = new Inventory();
    private Catalog catalog = new Catalog();
    private List<WorkOrder> workOrders = new ArrayList<>();
    private int computerCount;
    private int employeeSequence;
    private int itemSequence;
    private boolean starterOfficeInitialized;
    private int workSequence;
    private boolean bankruptcy;
    private FacilityResources facility = new FacilityResources();
    private ServerRack serverRack = new ServerRack();
    private WorkloadEngine workloadEngine = new WorkloadEngine();
    private AiLab aiLab = new AiLab();
    private Market market = new Market();
    private List<RivalCompany> rivals = new ArrayList<>();
    private WorldMap world = new WorldMap();
    private Factory factory = new Factory();
    private ResearchTree research = new ResearchTree();
    private int reputation = 65;
    private CorporateFinance finance = new CorporateFinance();
    private SupplyChain supplyChain = new SupplyChain();
    private String lastNotice = "Şirketin hazır. Çalışanlarını işe al ve ilk sözleşmeni al.";

    public Simulation() {
        String[][] names={{"rival_01","Atlas AI","yenilikçi"},{"rival_02","Pioneer Systems","agresif"},{"rival_03","MaviBulut Teknoloji","ucuz"},{"rival_04","Northstar Compute","kurumsal"},{"rival_05","Kuantum Yazılım","yenilikçi"},{"rival_06","Delta Veri","ucuz"},{"rival_07","Orion Robotics","agresif"},{"rival_08","Vertex Cloud","kurumsal"},{"rival_09","Lumen AI","yenilikçi"},{"rival_10","Kuzey Elektronik","ucuz"},{"rival_11","Helix Labs","kurumsal"},{"rival_12","Nova Dynamics","agresif"}};
        for(int i=0;i<names.length;i++)rivals.add(new RivalCompany(names[i][0],names[i][1],names[i][2],2_000_000L+i*150_000L,4+i%5,25+i*2,95+i%15,80+i*13));
        ensureStarterOffice();
    }

    /** Removes retired research branches from older saves (robotics, semiconductor and others). */
    private void sanitizeRetiredTechnologyBranches() {
        if (research == null) research = new ResearchTree();
        research.removeRetiredBranches();
    }

    /** Adds the two included starter desks once, including for older save files. */
    public void ensureStarterOffice() {
        sanitizeRetiredTechnologyBranches();
        if (office == null) office = new OfficeGrid(16, 12);
        // Version 4 campus migration: preserve existing placements and expand older 8x6 saves.
        office.expandToAtLeast(16, 12);
        if (starterOfficeInitialized) return;
        if (office.deskCapacity() == 0) {
            office.place("starter-desk-1", "office.desk", 1, 1, 2, 1, 0, 12_500L, "desk");
            office.place("starter-desk-2", "office.desk", 3, 1, 2, 1, 0, 12_500L, "desk");
        }
        starterOfficeInitialized = true;
        if (lastNotice == null || lastNotice.contains("İlk çalışma masanı yerleştir"))
            lastNotice = "İlk ekibin için iki hazır çalışma masası var.";
    }
    public void advance(double realDeltaSeconds) {
        Clock.AdvanceResult result=clock.advance(realDeltaSeconds);
        for(long d=0; d<result.days(); d++) {
            economy.accrueElectricity(Math.round((120L + computerCount * 55L + serverRack.powerKw()*100.0)*world.current().power));
            progressWorkOrders();
            aiLab.advance(86_400L);
            factory.advance(86_400L);
            supplyChain.advanceDay();
        }
        for(long m=0; m<result.months(); m++) {
            WorldMap.Region region=world.current();
            economy.closeMonth(clock.getGameSeconds(), Math.round(110_000L*region.rent*region.tax), 8_000L,
                    Math.round(employeeManager.monthlyPayrollCents()*region.wage));
            employeeManager.monthlyUpdate();
            long debtDue=finance.monthlyPaymentQuote();
            if(debtDue==0||economy.spend(debtDue,clock.getGameSeconds(),"Kredi","Aylık kredi ödemesi"))finance.applyMonthlyPayment();
            for(RivalCompany rival:rivals)rival.month(100L,rng.nextLong());
            if(!aiLab.published.isEmpty()) {
                int quality=aiLab.published.stream().mapToInt(model->model.quality).max().orElse(50);
                market.simulateMonth(quality,reputation,100,rivals.stream().mapToInt(r->Math.max(0,r.technology-30)).sum()/12,Math.max(100,computerCount*80+serverRack.devices.size()*250));
                if(market.monthlyRecurringRevenueCents>0)economy.earn(market.monthlyRecurringRevenueCents,clock.getGameSeconds(),"Abonelik","AI ürün abonelik geliri");
            }
            int totalMarketCustomers=market.customers+rivals.stream().mapToInt(r->r.customers).sum();
            market.marketShare=totalMarketCustomers==0?0.0:market.customers/(double)totalMarketCustomers;
            if(economy.isBankrupt()) { bankruptcy=true; lastNotice="İflas riski: iki ay üst üste ödeme açığı oluştu."; }
        }
    }
    private void progressWorkOrders() {
        if(employeeManager.size()==0 || computerCount==0) return;
        if(facility.breakerTripped)return;
        int dailyWork=(int)(employeeManager.all().stream().mapToInt(e -> Math.max(1,e.skill/20)).sum()*facility.coolingFactor());
        for(WorkOrder order:workOrders) {
            if(order.completed) continue;
            order.remainingWorkUnits=Math.max(0,order.remainingWorkUnits-dailyWork);
            if(order.remainingWorkUnits==0) {
                order.completed=true;
                economy.earn(order.rewardCents,clock.getGameSeconds(),"Freelance",order.title+" teslim edildi");
                lastNotice=order.title+" tamamlandı. Ödeme hesaba eklendi.";
            }
        }
    }
    public void setCompanyName(String name) { if(name!=null&&!name.isBlank()) companyName=name.trim().substring(0,Math.min(32,name.trim().length())); }
    public String getCompanyName(){return companyName;}
    public String getCountry(){return country;}
    public void setSpeed(int speed){clock.setSpeed(speed);}
    public void pause(){clock.setSpeed(0);}
    public Clock getClock(){return clock;}
    public Economy getEconomy(){return economy;}
    public OfficeGrid getOffice(){return office;}
    public EmployeeManager getEmployeeManager(){return employeeManager;}
    public Inventory getInventory(){return inventory;}
    public Catalog getCatalog(){return catalog;}
    public List<WorkOrder> getWorkOrders(){return List.copyOf(workOrders);}
    public int getComputerCount(){return computerCount;}
    public boolean isBankruptcy(){return bankruptcy;}
    public String getLastNotice(){return lastNotice;}
    public void setLastNotice(String text){lastNotice=text;}
    public boolean moveOfficeItem(String itemId, int x, int z) {
        boolean moved = office.move(itemId, x, z, 0);
        lastNotice = moved ? "Masa yeni konumuna taşındı." : "Bu konum dolu veya ofis sınırının dışında.";
        return moved;
    }

    public boolean placeDesk(int x,int z) {
        if(office.deskCapacity()>=MAX_DESKS){lastNotice="Masa: MAX";return false;}
        long price=nextDeskPriceCents();
        String id="desk-"+(itemSequence+1);
        if(!office.canPlace(id,x,z,2,1,0)){lastNotice="Bu hücre dolu veya ofis sınırının dışında.";return false;}
        if(!economy.spend(price,clock.getGameSeconds(),"Mobilya","Çalışma masası")){lastNotice="Masa için nakit yetersiz.";return false;}
        itemSequence++;
        if(!office.place(id,"office.desk",x,z,2,1,0,price,"desk")) { lastNotice="Yerleşim başarısız; işlem yapılmadı.";return false; }
        lastNotice="Masa yerleştirildi. Çalışan kapasitesi: "+office.deskCapacity()+".";return true;
    }
    // ---- Fixed-size campus expansion: every limit is hard-coded and bought with in-game money. ----
    public static final int MAX_DESKS = 10, MAX_RACK_CABINETS = 4, MAX_WAREHOUSES = 2, MAX_PRODUCTION_LINES = 2, MAX_COOLING_UNITS = 4;
    private static final int[][] DESK_SLOTS = {{1,1},{3,1},{5,1},{1,3},{3,3},{5,3},{9,1},{11,1},{13,1},{11,3}};
    private static final long RACK_PRICE = 120_000L, WAREHOUSE_PRICE = 90_000L, LINE_PRICE = 150_000L, COOLING_PRICE = 80_000L;

    public long nextDeskPriceCents() { return 12_500L + 2_500L * Math.max(0, office.deskCapacity() - 2); }
    public int rackCabinets() { return Math.max(1, Math.min(MAX_RACK_CABINETS, (serverRack.totalUnits - 12) / 10 + 1)); }
    public int warehouseCount() { return Math.max(1, Math.min(MAX_WAREHOUSES, (int) Math.round(supplyChain.warehouseCapacity / 500.0))); }
    public int productionLineCount() { return Math.max(1, Math.min(MAX_PRODUCTION_LINES, factory.level)); }

    /** Buys one desk and puts it in the next free fixed slot; the player never chooses a cell. */
    public boolean buyNextDesk() {
        if (office.deskCapacity() >= MAX_DESKS) { lastNotice = "Masa: MAX"; return false; }
        for (int[] slot : DESK_SLOTS) {
            if (office.canPlace("desk-" + (itemSequence + 1), slot[0], slot[1], 2, 1, 0)) return placeDesk(slot[0], slot[1]);
        }
        lastNotice = "Masa: MAX";
        return false;
    }
    public boolean buyRackCabinet() {
        if (rackCabinets() >= MAX_RACK_CABINETS) { lastNotice = "Sunucu kabini: MAX"; return false; }
        if (!economy.spend(RACK_PRICE, clock.getGameSeconds(), "Veri merkezi", "Yeni sunucu kabini")) { lastNotice = "Kabin için nakit yetersiz."; return false; }
        serverRack.totalUnits += 10; lastNotice = "Yeni sunucu kabini kuruldu."; return true;
    }
    public boolean buyWarehouse() {
        if (warehouseCount() >= MAX_WAREHOUSES) { lastNotice = "Depo: MAX"; return false; }
        if (!economy.spend(WAREHOUSE_PRICE, clock.getGameSeconds(), "Lojistik", "Yeni depo")) { lastNotice = "Depo için nakit yetersiz."; return false; }
        supplyChain.warehouseCapacity += 500; lastNotice = "Yeni depo açıldı."; return true;
    }
    public int coolingUnits() { return Math.max(1, Math.min(MAX_COOLING_UNITS, (int) Math.round(facility.coolingCapacityKw / 6.0))); }
    public boolean buyCoolingUnit() {
        if (coolingUnits() >= MAX_COOLING_UNITS) { lastNotice = "Soğutma: MAX"; return false; }
        if (!economy.spend(COOLING_PRICE, clock.getGameSeconds(), "Veri merkezi", "Yeni soğutma ünitesi")) { lastNotice = "Soğutma için nakit yetersiz."; return false; }
        facility.setCapacity(facility.powerCapacityKw, facility.coolingCapacityKw + 6.0, facility.networkGbps, facility.floorLoadKg);
        lastNotice = "Yeni soğutma ünitesi kuruldu."; return true;
    }
    public boolean buyProductionLine() {
        if (productionLineCount() >= MAX_PRODUCTION_LINES) { lastNotice = "Üretim hattı: MAX"; return false; }
        if (!economy.spend(LINE_PRICE, clock.getGameSeconds(), "Üretim", "Yeni üretim hattı")) { lastNotice = "Üretim hattı için nakit yetersiz."; return false; }
        factory.level++; factory.workers += 2; factory.machineEfficiency = Math.min(100, factory.machineEfficiency + 5);
        lastNotice = "Yeni üretim hattı devreye alındı."; return true;
    }
    public boolean sellDesk(String itemId){OfficeGrid.PlacedItem item=office.items().stream().filter(i->i.id().equals(itemId)).findFirst().orElse(null);if(item==null||!"desk".equals(item.kind()))return false;if(employeeManager.size()>office.deskCapacity()-1){lastNotice="Önce çalışan sayısını azalt; masa kapasitesi yetersiz kalacak.";return false;}office.remove(itemId);economy.earn(item.valueCents()/2,clock.getGameSeconds(),"Mobilya satışı","İkinci el masa satışı");lastNotice="Masa satıldı; ikinci el değeri iade edildi.";return true;}
    public boolean fireEmployee(String employeeId){Employee employee=employeeManager.find(employeeId);if(employee==null)return false;long severance=employee.monthlySalaryCents/2;if(!economy.spend(severance,clock.getGameSeconds(),"İşten çıkarma","Tazminat: "+employee.name))return false;employeeManager.fire(employeeId);lastNotice=employee.name+" işten ayrıldı.";return true;}
    public boolean assignEmployee(String employeeId,String projectId){boolean ok=employeeManager.assign(employeeId,projectId);lastNotice=ok?"Görev atandı.":"Çalışan veya proje bulunamadı.";return ok;}
    public EmployeeManager.HireResult hireEmployee() {
        if(employeeManager.size() >= office.deskCapacity()) {
            lastNotice="Boş masa yok. Önce ofise masa yerleştir.";
            return new EmployeeManager.HireResult(false,lastNotice,null);
        }
        int skill=45+rng.nextInt(36);
        long salary=(70_000L+skill*700L);
        if(!economy.spend(7_500L,clock.getGameSeconds(),"İşe alım","İşe alım ve ekipman hazırlığı"))
            return new EmployeeManager.HireResult(false,"İşe alım gideri için nakit yetersiz.",null);
        EmployeeManager.HireResult result=employeeManager.hire("emp-"+(++employeeSequence),
                randomName(),"Yazılım geliştirme",skill,salary,office.deskCapacity(),economy.getCashCents());
        if(!result.success()) economy.earn(7_500L,clock.getGameSeconds(),"İade","İşe alım iptal edildi");
        lastNotice=result.message(); return result;
    }
    private String randomName(){String[] names={"Deniz Yılmaz","Ece Demir","Mert Kaya","Ada Şahin","Can Arslan","Elif Aydın","Arda Çelik","Duru Koç"};return names[rng.nextInt(names.length)];}

    public void loadCatalog(Catalog source) {
        if(source==null)return;
        for(HardwareItem item:source.all()) catalog.add(item);
    }
    public boolean purchaseHardware(String itemId, boolean used) {
        HardwareItem item=catalog.find(itemId).orElse(null);
        if(item==null){lastNotice="Ürün kataloğunda bulunamadı: "+itemId;return false;}
        long price=item.priceCents(); if(used) price=(long)(price*0.68d);
        if(!economy.spend(price,clock.getGameSeconds(),"Donanım",item.label()+(used?" (ikinci el)":""))){lastNotice="Satın alma için nakit yetersiz.";return false;}
        inventory.add(itemId,1); lastNotice=item.label()+" envantere eklendi.";return true;
    }
    public Compatibility.Report buildComputer(List<String> partIds) {
        List<HardwareItem> parts=new ArrayList<>();
        for(String id:partIds) {
            HardwareItem item=catalog.find(id).orElse(null);
            if(item==null || inventory.quantity(id)<1) return new Compatibility.Report(false,List.of("Eksik parça: "+id));
            parts.add(item);
        }
        Compatibility.Report report=new Compatibility().check(parts);
        if(!report.compatible()){lastNotice=String.join(" ",report.errors());return report;}
        for(String id:partIds) inventory.consume(id,1);
        int performance=parts.stream().mapToInt(i->Math.max(1,i.tier)*8).sum();
        inventory.addComputer(new Inventory.ComputerBuild("Ofis bilgisayarı "+(computerCount+1),List.copyOf(partIds),performance));
        computerCount++; lastNotice="Bilgisayar kuruldu. Performans puanı: "+performance+".";
        return report;
    }
    public boolean buildStarterComputer() {
        String[] ids={"cpu_celeron_g5905","mb_gigabyte_h410m_s2h","ram_kingston_8gb_ddr4","psu_corsair_cv450","case_antec_dp301m","ssd_kingston_a400_240"};
        long total=0; for(String id:ids){HardwareItem i=catalog.find(id).orElse(null);if(i==null){lastNotice="Başlangıç PC parçaları kataloğa yüklenemedi.";return false;}total+=i.priceCents();}
        if(!economy.spend(total,clock.getGameSeconds(),"Donanım","Giriş seviyesi ofis bilgisayarı parçaları")){lastNotice="Başlangıç bilgisayarı için nakit yetersiz.";return false;}
        for(String id:ids)inventory.add(id,1);
        Compatibility.Report report=buildComputer(List.of(ids[0],ids[1],ids[2],ids[3],ids[4]));
        if(!report.compatible()) {
            for(String id:ids) inventory.consume(id,1);
            economy.earn(total,clock.getGameSeconds(),"İade","Uyumsuz başlangıç PC parçaları iadesi");
            return false;
        }
        inventory.consume(ids[5],1);
        lastNotice="PC kuruldu; iş istasyonun hazır."; return true;
    }
    public boolean startFreelanceJob() {
        if(employeeManager.size()==0 || computerCount==0){lastNotice="İş alabilmek için en az bir çalışan ve bilgisayar gerekli.";return false;}
        if(workOrders.stream().anyMatch(w->!w.completed)){lastNotice="Önce aktif işi tamamla.";return false;}
        WorkOrder order=new WorkOrder("work-"+(++workSequence),"Kurumsal yazılım işi",12,180_000L);
        workOrders.add(order);lastNotice="Yeni freelance sözleşmesi alındı. Teslimat oyun zamanı ile ilerliyor.";return true;
    }
    public int getSaveVersion(){return saveVersion;}
    public void setSaveVersion(int v){saveVersion=v;}
    public Rng getRng(){return rng;}
    public FacilityResources getFacility(){return facility;}
    public ServerRack getServerRack(){return serverRack;}
    public AiLab getAiLab(){return aiLab;}
    public Market getMarket(){return market;}
    public List<RivalCompany> getRivals(){return List.copyOf(rivals);}
    public WorldMap getWorld(){return world;}
    public Factory getFactory(){return factory;}
    public ResearchTree getResearch(){sanitizeRetiredTechnologyBranches();return research;}
    public int getReputation(){return reputation;}
    public CorporateFinance getFinance(){return finance;}
    public SupplyChain getSupplyChain(){return supplyChain;}
    public CorporateFinance.Loan takeLoan(long principalCents,double monthlyRate,int termMonths){CorporateFinance.Loan loan=finance.takeLoan(principalCents,monthlyRate,termMonths);economy.earn(principalCents,clock.getGameSeconds(),"Kredi","İşletme kredisi: "+loan.id);lastNotice="Kredi hesaba aktarıldı.";return loan;}
    public CorporateFinance.Investment acceptInvestment(String investor,long amountCents,double equityPercent){CorporateFinance.Investment investment=finance.acceptInvestment(investor,amountCents,equityPercent);economy.earn(amountCents,clock.getGameSeconds(),"Yatırım",investor+" yatırım turu");lastNotice="Yatırım kabul edildi; hisse payı %"+equityPercent;return investment;}
    public long companyValuation(){long annualRevenue=market.monthlyRecurringRevenueCents*12;long assets=computerCount*75_000L+serverRack.devices.size()*250_000L;return finance.valuationCents(annualRevenue,assets,reputation,aiLab.published.size()*10+research.completed.size()*5);}
    public boolean listCompany(){boolean ok=finance.listCompany(companyValuation());lastNotice=ok?"Şirket halka arz edildi (oyun içi).":"Halka arz koşulları sağlanmadı.";return ok;}
    public SupplyChain.Shipment orderShipment(String item,int units,int days,long unitCost,double dutyMultiplier){long total=Math.round(units*unitCost*Math.max(1,dutyMultiplier));if(!economy.spend(total,clock.getGameSeconds(),"Tedarik",item+" sevkiyatı"))throw new IllegalStateException("Sevkiyat için nakit yetersiz.");return supplyChain.order(item,units,days,unitCost,dutyMultiplier);}
    public boolean receiveShipment(String id){SupplyChain.Shipment s=supplyChain.shipments.stream().filter(x->x.id.equals(id)).findFirst().orElse(null);if(s==null||!supplyChain.receive(id)||!supplyChain.consumeStock(s.units))return false;factory.rawMaterials+=s.units;lastNotice="Sevkiyat teslim alındı; hammadde stoğu güncellendi.";return true;}
    public boolean receiveFirstShipment(){SupplyChain.Shipment s=supplyChain.shipments.stream().filter(x->x.delivered&&!x.received).findFirst().orElse(null);return s!=null&&receiveShipment(s.id);}
    public CorporateFinance.Loan takeStarterLoan(){return takeLoan(500_000L,.025,12);}
    public CorporateFinance.Investment takeSeedInvestment(){return acceptInvestment("Seed Capital",1_000_000L,10.0);}


    public CyberIncident.Result runSecurityReview(){return resolveCyberIncident(CyberIncident.Type.SERVICE_DISRUPTION,65,70);}
    public WorkloadEngine.Result evaluateWorkload(double cpu,double gpu,double vram,double ram,double disk,double network,double cooling,int gpuCount){return workloadEngine.evaluate(cpu,gpu,vram,ram,disk,network,cooling,gpuCount);}
    public boolean installServer(String id,String kind,int units,double powerKw,double heatKw){if(!serverRack.install(id,kind,units,powerKw,heatKw)){lastNotice="Rack U kapasitesi yetersiz veya cihaz kimliği tekrar ediyor.";return false;}facility.setLoad(serverRack.powerKw(),serverRack.heatKw(),0,0);if(facility.breakerTripped||facility.thermalThrottle)lastNotice="Sunucu kuruldu ancak güç/soğutma darboğazı oluştu.";else lastNotice="Sunucu rack'e kuruldu.";return true;}
    public AiLab.Dataset createAiDataset(String name,int rows,double quality,long costCents){if(!economy.spend(costCents,clock.getGameSeconds(),"AI Veri",name+" veri seti"))throw new IllegalStateException("Veri seti için nakit yetersiz.");return aiLab.createDataset(name,rows,quality,costCents);}
    public boolean cleanAiDataset(String id,double improvement,long costCents){if(!economy.spend(costCents,clock.getGameSeconds(),"AI Veri Temizleme","Veri seti temizliği"))return false;boolean ok=aiLab.cleanDataset(id,improvement);if(!ok)economy.earn(costCents,clock.getGameSeconds(),"İade","Veri temizleme uygulanamadı");return ok;}
    public AiLab.TrainingJob startAiTrainingFromDataset(String name,String datasetId,long budgetCents,double gpuScore,int staffSkill){AiLab.Dataset dataset=aiLab.findDataset(datasetId);if(dataset==null)throw new IllegalArgumentException("Veri seti bulunamadı.");return startAiTraining(name,budgetCents,gpuScore,Math.max(.1,dataset.quality/100.0),staffSkill);}
    public AiLab.TrainingJob startAiTraining(String name,long budgetCents,double gpuScore,double dataQuality,int staffSkill){if(!economy.spend(budgetCents,clock.getGameSeconds(),"AI Ar-Ge","Model eğitimi: "+name))throw new IllegalStateException("Eğitim bütçesi için nakit yetersiz.");return aiLab.start(name,budgetCents,gpuScore,dataQuality,staffSkill,facility.coolingFactor());}
    public AiLab.AiModel publishAiModel(String jobId,String tier){AiLab.AiModel model=aiLab.publish(jobId,tier);lastNotice=model.name+" yayımlandı.";return model;}
    public AiLab.Evaluation evaluateLatestAiModel(){if(aiLab.jobs.isEmpty())throw new IllegalStateException("Önce eğitim başlat.");AiLab.TrainingJob job=aiLab.jobs.get(aiLab.jobs.size()-1);AiLab.Evaluation result=aiLab.evaluate(job.id,78);lastNotice="Model değerlendirmesi: güvenlik %"+result.safety()+", kalite %"+result.accuracy()+".";return result;}
    public AiLab.AiModel publishLatestAiModel(){if(aiLab.jobs.isEmpty())throw new IllegalStateException("Eğitim işi bulunamadı.");return publishAiModel(aiLab.jobs.get(aiLab.jobs.size()-1).id,"Pro");}
    public CyberIncident.Result resolveCyberIncident(CyberIncident.Type type,int defense,int response){CyberIncident.Result result=new CyberIncident().resolve(type,defense,response,reputation);reputation=Math.max(0,reputation-result.reputationLoss());if(result.serviceImpact()>0)market.satisfaction=Math.max(0,market.satisfaction-result.serviceImpact()*.2);lastNotice=result.report();return result;}
    public boolean moveCompany(String country){if(!world.moveTo(country))return false;this.country=country;lastNotice="Şirket operasyon bölgesi: "+country;return true;}
    public boolean beginProduction(String product,int units,long materialsCost){if(!economy.spend(materialsCost,clock.getGameSeconds(),"Üretim","Hammadde: "+product))return false;boolean ok=factory.start(product,units,materialsCost);if(!ok)economy.earn(materialsCost,clock.getGameSeconds(),"İade","Üretim başlatılamadı");return ok;}
    public boolean completeResearch(String id,int points){boolean ok=research.research(id,points);if(ok)lastNotice="Araştırma tamamlandı: "+id;return ok;}
    public String nextResearch(){return research.unlocked.stream().filter(id->!research.completed.contains(id)).findFirst().orElse("");}
    public boolean sellFactoryGoods(String product,int units,long unitPriceCents){if(!factory.removeFinished(product,units))return false;long revenue=Math.max(0,unitPriceCents)*units;economy.earn(revenue,clock.getGameSeconds(),"Üretim Satışı",product+" x"+units);lastNotice="Üretim satıldı: "+product;return true;}
}
