package aict.sim;

import java.util.LinkedHashMap;import java.util.Map;
/** Regional operating-cost model; figures are game balance multipliers, not live tax advice. */
public final class WorldMap {
 public String currentCountry="Türkiye";public Map<String,Region> regions=new LinkedHashMap<>();
 public WorldMap(){add("Türkiye",1.0,0.85,0.9,0.95,1.0);add("Almanya",1.55,1.2,1.05,1.1,1.15);add("ABD",1.7,1.1,0.95,1.0,1.2);add("Japonya",1.6,1.15,1.1,1.05,1.15);add("Polonya",1.05,0.9,0.95,0.95,1.0);add("Hindistan",0.55,0.75,0.8,0.9,0.9);add("Birleşik Krallık",1.65,1.25,1.1,1.1,1.1);add("Singapur",1.8,1.3,1.2,1.15,1.25);add("Kanada",1.45,0.95,0.9,1.0,1.1);}
 private void add(String n,double wage,double rent,double power,double tax,double logistics){regions.put(n,new Region(n,wage,rent,power,tax,logistics));}
 public boolean moveTo(String country){if(!regions.containsKey(country))return false;currentCountry=country;return true;}
 public String nextRegion(){var names=regions.keySet().stream().toList();int i=names.indexOf(currentCountry);currentCountry=names.get((i+1)%names.size());return currentCountry;}
 public Region current(){return regions.get(currentCountry);}
 public static final class Region{public String name;public double wage,rent,power,tax,logistics;public Region(){}Region(String n,double w,double r,double p,double t,double l){name=n;wage=w;rent=r;power=p;tax=t;logistics=l;}}
}
