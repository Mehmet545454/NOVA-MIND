package aict.sim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Ledger {
    private List<Entry> entries = new ArrayList<>();
    public void add(long gameSeconds, String category, long amountCents, String description) {
        if (amountCents == 0) return;
        entries.add(new Entry(gameSeconds, category, amountCents, description));
    }
    public List<Entry> entries() { return Collections.unmodifiableList(entries); }
    public long sumCents() { return entries.stream().mapToLong(Entry::amountCents).sum(); }
    public long incomeCents() { return entries.stream().filter(e -> e.amountCents() > 0).mapToLong(Entry::amountCents).sum(); }
    public long expenseCents() { return -entries.stream().filter(e -> e.amountCents() < 0).mapToLong(Entry::amountCents).sum(); }
    public record Entry(long gameSeconds, String category, long amountCents, String description) { }
}
