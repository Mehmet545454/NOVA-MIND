package aict.sim;

import java.util.ArrayList;import java.util.List;
/** Loans, equity offers and IPO are in-game mechanics only. */
public final class CorporateFinance {
 public List<Loan> loans=new ArrayList<>();public List<Investment> investments=new ArrayList<>();public boolean listed;public double equitySold;public long shares=1_000_000;
 public Loan takeLoan(long principalCents,double monthlyRate,int termMonths){if(principalCents<=0||monthlyRate<0||termMonths<1)throw new IllegalArgumentException("Kredi koşulları geçersiz.");Loan l=new Loan("loan-"+(loans.size()+1),principalCents,monthlyRate,termMonths);loans.add(l);return l;}
 public long monthlyPaymentQuote(){long total=0;for(Loan l:loans)if(l.remainingCents>0){long interest=Math.round(l.remainingCents*l.monthlyRate);long principal=Math.min(l.remainingCents,Math.max(1,l.principalCents/Math.max(1,l.termMonths)));total+=principal+interest;}return total;}
 public void applyMonthlyPayment(){for(Loan l:loans)if(l.remainingCents>0){long principal=Math.min(l.remainingCents,Math.max(1,l.principalCents/Math.max(1,l.termMonths)));l.remainingCents-=principal;l.monthsPaid++;}}
 public Investment acceptInvestment(String investor,long amountCents,double equityPercent){if(amountCents<=0||equityPercent<=0||equityPercent>=50)throw new IllegalArgumentException("Yatırım koşulları geçersiz.");Investment i=new Investment(investor,amountCents,equityPercent);investments.add(i);equitySold+=equityPercent;return i;}
 public long valuationCents(long annualRevenue,long assets,long reputation,int technology){double multiplier=1.0+Math.max(0,reputation)/100.0+Math.max(0,technology)/200.0;return Math.max(assets,Math.round(Math.max(0,annualRevenue)*multiplier));}
 public boolean listCompany(long valuationCents){if(listed||valuationCents<=0||equitySold>=80)return false;listed=true;return true;}
 public static final class Loan{public String id;public long principalCents,remainingCents;public double monthlyRate;public int termMonths,monthsPaid;public Loan(){}Loan(String i,long p,double r,int t){id=i;principalCents=p;remainingCents=p;monthlyRate=r;termMonths=t;}}
 public static final class Investment{public String investor;public long amountCents;public double equityPercent;public Investment(){}Investment(String n,long a,double e){investor=n;amountCents=a;equityPercent=e;}}
}
