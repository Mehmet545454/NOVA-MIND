package aict.sim;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EconomyTest {
 @Test void ledgerMatchesCashChange(){Economy e=new Economy(100_000);e.spend(25_000,0,"Test","harcama");e.earn(7_500,1,"Test","gelir");assertEquals(82_500,e.getCashCents());assertEquals(-17_500,e.getLedger().sumCents());}
 @Test void refusesOverspend(){Economy e=new Economy(100);assertFalse(e.spend(101,0,"Test","fazla"));assertEquals(100,e.getCashCents());}
 @Test void monthlyCloseResetsMonthlyTotals(){Economy e=new Economy(500_000);e.earn(50_000,0,"Test","gelir");e.closeMonth(1,10_000,2_000,0);assertEquals(0,e.getMonthlyRevenueCents());assertEquals(0,e.getMonthlyExpenseCents());}
}
