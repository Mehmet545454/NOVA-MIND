package aict.sim;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class RivalMarketTest {
 @Test void rivalDecisionIsDeterministicForSameSeed(){RivalCompany a=new RivalCompany("r1","A","ucuz",2000000,5,40,100,100);RivalCompany b=new RivalCompany("r1","A","ucuz",2000000,5,40,100,100);a.month(100,1234);b.month(100,1234);assertEquals(a.cashCents,b.cashCents);assertEquals(a.priceIndex,b.priceIndex);}
 @Test void customerModelRespectsCapacity(){Market m=new Market();m.simulateMonth(90,90,100,0,20);assertTrue(m.customers<=20);assertTrue(m.monthlyRecurringRevenueCents>=0);}
 @Test void abstractCyberIncidentOnlyReturnsNumericImpact(){var r=new CyberIncident().resolve(CyberIncident.Type.SERVICE_DISRUPTION,90,90,70);assertTrue(r.serviceImpact()>=0);assertTrue(r.reputationLoss()>=0);}
}
