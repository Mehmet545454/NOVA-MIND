package aict.sim;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class DeterminismTest {
 @Test void sameSeedProducesSameSequence(){Rng a=new Rng(42),b=new Rng(42);for(int n=0;n<100;n++)assertEquals(a.nextLong(),b.nextLong());}
 @Test void rngStateCanBeRestored(){Rng a=new Rng(99);a.nextLong();long state=a.getState();long expected=a.nextLong();Rng b=new Rng();b.setState(state);assertEquals(expected,b.nextLong());}
}
