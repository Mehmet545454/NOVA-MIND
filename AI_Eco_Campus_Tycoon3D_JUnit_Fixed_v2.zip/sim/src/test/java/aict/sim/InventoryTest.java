package aict.sim;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class InventoryTest {
 @Test void consumeNeverMakesNegativeStock(){Inventory i=new Inventory();i.add("ram",1);assertFalse(i.consume("ram",2));assertEquals(1,i.quantity("ram"));assertTrue(i.consume("ram",1));assertEquals(0,i.quantity("ram"));}
 @Test void gridRejectsOverlappingFurniture(){OfficeGrid g=new OfficeGrid(8,6);assertTrue(g.place("desk1","office.desk",0,0,2,1,0,100,"desk"));assertFalse(g.place("desk2","office.desk",1,0,2,1,0,100,"desk"));assertEquals(1,g.deskCapacity());}
 @Test void gridCanMoveItemWithoutLosingItWhenTargetIsBlocked(){OfficeGrid g=new OfficeGrid(8,6);assertTrue(g.place("desk1","office.desk",0,0,2,1,0,100,"desk"));assertTrue(g.place("desk2","office.desk",3,0,2,1,0,100,"desk"));assertFalse(g.move("desk1",3,0,0));assertEquals(2,g.deskCapacity());assertTrue(g.move("desk1",0,2,0));assertEquals("desk1",g.at(1,2).orElseThrow().id());}
 @Test void newCompanyStartsWithTwoPersistableDesks(){Simulation sim=new Simulation();assertEquals(2,sim.getOffice().deskCapacity());assertTrue(sim.getOffice().find("starter-desk-1").isPresent());assertTrue(sim.getOffice().find("starter-desk-2").isPresent());}
 @Test void starterCampusExpandsOfficeWithoutMovingExistingDesks(){Simulation sim=new Simulation();assertEquals(16,sim.getOffice().width());assertEquals(12,sim.getOffice().depth());assertEquals(1,sim.getOffice().find("starter-desk-1").orElseThrow().x());assertEquals(2,sim.getOffice().deskCapacity());}
 @Test void oldSavedGridCanExpandWithoutLosingFurniture(){OfficeGrid g=new OfficeGrid(8,6);assertTrue(g.place("old-desk","office.desk",2,2,2,1,0,100,"desk"));g.expandToAtLeast(16,12);assertEquals(16,g.width());assertEquals(12,g.depth());assertTrue(g.find("old-desk").isPresent());assertTrue(g.canPlace("new-desk",12,9,2,1,0));}
}
