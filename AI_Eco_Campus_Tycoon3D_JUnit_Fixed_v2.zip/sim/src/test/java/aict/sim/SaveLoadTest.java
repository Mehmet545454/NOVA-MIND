package aict.sim;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;
class SaveLoadTest {
 @TempDir Path temp;
 @Test void roundTripPreservesCompanyAndClock() throws Exception {Simulation s=new Simulation();s.setCompanyName("Nova Labs");s.setSpeed(4);s.advance(.25);SaveManager m=new SaveManager();Path p=temp.resolve("save.json");m.save(p,s);Simulation loaded=m.load(p);assertEquals("Nova Labs",loaded.getCompanyName());assertEquals(s.getClock().getGameSeconds(),loaded.getClock().getGameSeconds());}
 @Test void roundTripPreservesStageTwoToFiveSystems() throws Exception {Simulation s=new Simulation();s.installServer("srv-1","GPU server",2,1.2,1.0);s.takeStarterLoan();s.moveCompany("Almanya");s.orderShipment("materials",5,2,1000,1.1);SaveManager m=new SaveManager();Path p=temp.resolve("extended.json");m.save(p,s);Simulation loaded=m.load(p);assertEquals(1,loaded.getServerRack().devices.size());assertEquals(1,loaded.getFinance().loans.size());assertEquals("Almanya",loaded.getWorld().currentCountry);assertEquals(1,loaded.getSupplyChain().shipments.size());assertEquals(12,loaded.getRivals().size());assertEquals(4,loaded.getSaveVersion());assertEquals(16,loaded.getOffice().width());assertEquals(12,loaded.getOffice().depth());}
}
