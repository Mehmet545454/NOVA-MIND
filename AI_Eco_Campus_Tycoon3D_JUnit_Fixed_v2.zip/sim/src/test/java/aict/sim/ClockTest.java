package aict.sim;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class ClockTest {
    private static void advanceReal(Clock c,double seconds){int n=(int)Math.ceil(seconds/0.25);double part=seconds/n;for(int i=0;i<n;i++)c.advance(part);}
    @Test void oneYearAtNormalSpeedIsEighteenMinutes(){Clock c=new Clock();advanceReal(c,1080);assertEquals(Clock.GAME_SECONDS_PER_YEAR,c.getGameSeconds());assertEquals(2,c.date().year());}
    @Test void oneYearAtEightTimesSpeedIsOneHundredThirtyFiveSeconds(){Clock c=new Clock();c.setSpeed(8);advanceReal(c,135);assertEquals(Clock.GAME_SECONDS_PER_YEAR,c.getGameSeconds());}
    @Test void speedChangesDoNotAlterCalendarFromEqualElapsedGameTime(){Clock a=new Clock();Clock b=new Clock();advanceReal(a,90);b.setSpeed(2);advanceReal(b,45);assertEquals(a.getGameSeconds(),b.getGameSeconds());}
    @Test void monthlyBoundaryIsEmittedOnce(){Clock c=new Clock();long months=0;for(int i=0;i<368;i++)months+=c.advance(0.25).months();assertEquals(1,months);}
    @Test void oneYearEmitsExactlyTwelveMonthBoundaries(){Clock c=new Clock();long months=0;for(int i=0;i<4320;i++)months+=c.advance(0.25).months();assertEquals(12,months);}
    @Test void largeFrameDeltaIsClampedToQuarterSecond(){Clock c=new Clock();c.advance(4.0);assertEquals(7300L,c.getGameSeconds());}
    @Test void pausedClockDoesNotAdvance(){Clock c=new Clock();c.setSpeed(0);c.advance(.25);assertEquals(0,c.getGameSeconds());}
}
