package aict.sim;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CatalogTest {
 @Test void duplicateIdsAreIgnored(){Catalog c=new Catalog();HardwareItem a=new HardwareItem();a.id="one";a.model="A";c.add(a);HardwareItem b=new HardwareItem();b.id="one";b.model="B";c.add(b);assertEquals(1,c.size());assertEquals("A",c.find("one").orElseThrow().model);}
}
