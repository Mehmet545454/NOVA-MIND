package aict.sim;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class ExpansionTest {
 @Test void desksStopAtFixedLimitAndCostMoreEachTime(){Simulation s=new Simulation();assertEquals(2,s.getOffice().deskCapacity());long first=s.nextDeskPriceCents();for(int i=0;i<8;i++)assertTrue(s.buyNextDesk());assertEquals(Simulation.MAX_DESKS,s.getOffice().deskCapacity());assertFalse(s.buyNextDesk());assertTrue(s.nextDeskPriceCents()>first);}
 @Test void rackWarehouseAndLineStopAtFixedLimits(){Simulation s=new Simulation();assertEquals(1,s.rackCabinets());for(int i=0;i<3;i++)assertTrue(s.buyRackCabinet());assertEquals(4,s.rackCabinets());assertFalse(s.buyRackCabinet());assertEquals(42,s.getServerRack().totalUnits);
  assertEquals(1,s.warehouseCount());assertTrue(s.buyWarehouse());assertFalse(s.buyWarehouse());assertEquals(2,s.warehouseCount());
  assertEquals(1,s.productionLineCount());assertTrue(s.buyProductionLine());assertFalse(s.buyProductionLine());assertEquals(2,s.productionLineCount());}
 @Test void coolingStopsAtFixedLimitAndRaisesCapacity(){Simulation s=new Simulation();assertEquals(1,s.coolingUnits());double before=s.getFacility().coolingCapacityKw;for(int i=0;i<3;i++)assertTrue(s.buyCoolingUnit());assertEquals(4,s.coolingUnits());assertFalse(s.buyCoolingUnit());assertEquals("Soğutma: MAX",s.getLastNotice());assertEquals(before+18.0,s.getFacility().coolingCapacityKw,.001);}
 @Test void purchasesNeedCash(){Simulation s=new Simulation();while(s.getEconomy().spend(100_000L,0,"t","t")){}assertFalse(s.buyRackCabinet());assertFalse(s.buyWarehouse());assertEquals(1,s.rackCabinets());}
}
