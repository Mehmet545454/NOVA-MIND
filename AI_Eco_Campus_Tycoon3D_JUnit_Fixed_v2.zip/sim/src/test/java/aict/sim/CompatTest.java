package aict.sim;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
class CompatTest {
 private HardwareItem item(String id,String cat,String socket,String ram,String form,int watts){HardwareItem i=new HardwareItem();i.id=id;i.category=cat;i.specs.put("socket",socket);i.specs.put("ram_type",ram);i.specs.put("form_factor",form);i.specs.put("watt",watts);i.specs.put("required_psu_w",250);return i;}
 @Test void rejectsSocketMismatch(){var cpu=item("cpu","cpu","LGA1200","","",65);var mb=item("mb","motherboard","AM4","DDR4","mATX",0);var ram=item("ram","ram","","DDR4","",0);var psu=item("psu","psu","","","",450);var box=item("box","case","","","mATX",0);var r=new Compatibility().check(List.of(cpu,mb,ram,psu,box));assertFalse(r.compatible());}
 @Test void acceptsCompatibleStarterSet(){var cpu=item("cpu","cpu","LGA1200","","",65);var mb=item("mb","motherboard","LGA1200","DDR4","mATX",0);var ram=item("ram","ram","","DDR4","",0);var psu=item("psu","psu","","","",450);var box=item("box","case","","","mATX",0);assertTrue(new Compatibility().check(List.of(cpu,mb,ram,psu,box)).compatible());}
}
