package aict.desktop;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import aict.core.AictGame;

public final class DesktopLauncher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("AI Eco Campus Tycoon 3D - Developer Preview");
        config.setWindowedMode(1280, 720);
        config.useVsync(true);
        new Lwjgl3Application(new AictGame(), config);
    }
}
